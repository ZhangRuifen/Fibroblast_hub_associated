library(ggplot2)
library(Seurat)
library(tidyverse)
library(monocle3)
library(dplyr)


fibroblast <- readRDS("Fibroblast.rds")
dim(fibroblast)

cds <- monocle3::new_cell_data_set(
  expression_data = SeuratObject::GetAssayData(fibroblast, assay = "RNA", layer = "counts"),
  cell_metadata = fibroblast@meta.data,
  gene_metadata = data.frame(gene_short_name = rownames(fibroblast), 
                             row.names = rownames(fibroblast))
)       
cds <- preprocess_cds(cds, num_dim = 50)
cds <- align_cds(cds, alignment_group = "day")


cds <- reduce_dimension(cds)


cds.embed <- cds@int_colData$reducedDims$UMAP
int.embed <- Embeddings(fibroblast, reduction = "umap")
int.embed <- int.embed[rownames(cds.embed), ]
cds@int_colData$reducedDims$UMAP <- int.embed

plot_cells(cds, reduction_method = "UMAP", color_cells_by = "subCellType")

cds <- cluster_cells(cds, reduction_method = "UMAP")

plot_cells(cds, color_cells_by = "subCellType")

cds@clusters$UMAP$clusters <- fibroblast$seurat_clusters

cds <- learn_graph(cds,use_partition = TRUE)
plot_cells(cds, color_cells_by = "subCellType", label_groups_by_cluster = FALSE, 
           label_leaves = FALSE, label_branch_points = FALSE)


cds <- order_cells(cds)
p<-plot_cells(cds, color_cells_by = "pseudotime", label_cell_groups = FALSE,
              label_leaves = FALSE, label_branch_points = FALSE)
p
ggsave(p,filename = "Pseudotime.pdf",units = "mm",width = 120,height = 100)
colData(cds)$cluster
colData(cds)$partition


library(Seurat)
library(clustree)

obj <- readRDS("./obj.rds")
Fibroblast <- subset(obj, idents = 'Fibroblast')

DefaultAssay(Fibroblast)<-"RNA"
Fibroblast <- NormalizeData(Fibroblast)
Fibroblast <- FindVariableFeatures(Fibroblast)
Fibroblast <- ScaleData(Fibroblast)
Fibroblast <- RunPCA(Fibroblast)

ElbowPlot(Fibroblast, ndims = 50)
pct <- Fibroblast[["pca"]]@stdev / sum(Fibroblast[["pca"]]@stdev) * 100
cumu <- cumsum(pct)
component1 <- which(cumu > 90 & pct < 5)[1] # determine the point where the principal component contributes < 5% of standard deviation and the principal components so far have cumulatively contributed 90% of the standard deviation.
component2 <- sort(which((pct[1:length(pct) - 1] - pct[2:length(pct)]) > 0.1), decreasing = T)[1] + 1 # identify where the percent change in variation between consecutive PCs is less than 0.1%
prin_comp <- min(component1, component2) 

Fibroblast <- IntegrateLayers(object = Fibroblast, method = CCAIntegration, orig.reduction = "pca", new.reduction = "integrated.cca",
                                  verbose = FALSE, k.weight = 30)

Fibroblast <- FindNeighbors(Fibroblast, reduction = "integrated.cca", dims = 1:prin_comp)
Fibroblast <- FindClusters(Fibroblast, resolution = c(0,0.05,0.1,0.15,0.2,0.3,0.4,0.5))
clustree(Fibroblast)

Fibroblast <- RunUMAP(Fibroblast, dims = 1:prin_comp, reduction = "integrated.cca")
DimPlot(Fibroblast, reduction = "umap", group.by = c("RNA_snn_res.0", "RNA_snn_res.0.05","RNA_snn_res.0.1",
                                                         "RNA_snn_res.0.15","RNA_snn_res.0.2","RNA_snn_res.0.3",
                                                         "RNA_snn_res.0.4","RNA_snn_res.0.5"),label = TRUE)
list_genes <- list(
  Trophocytes = c('Cd81', 'Grem1','Ackr4','Pi16','Cd34','C3','Wnt2','Wnt2b'),  # 'Wnt2','Wnt2b',
  Myfibroblasts = c('Acta2','Tagln','Myh11','Actg2'), # Cd34-
  Telocytes = c('Foxl1','Bmp2','Bmp7','Wnt5a','F3','Sox6'),  # Low: Acta2,'Gli1','Cspg4','Bmp3','Adamdec1'
  Fibroblasts = c('Pdgfra','Sfrp1','S100a4','Vim','Des'), #,'Cdh2'
  Pericyte = c('Col1a1','Col4a1','Col4a2','Rgs5','Cspg4'),  # Low: 'Col4a1','Col4a2','Bcam',
  Epithelial = c('Krt8','Krt18','Epcam')
)

Fibroblast<-JoinLayers(Fibroblast)
marker.0.5<-FindAllMarkers(Fibroblast,only.pos = TRUE,logfc.threshold = 0.25)
write.csv(marker.0.5,file = 'marker.0.05.csv')
DotPlot(Fibroblast ,features = list_genes)+RotatedAxis()

p<-DotPlot(FFib, features = genes_to_plot, group.by = "subCellType") +
  scale_color_gradient(low = "grey", high = "#bf0603") +  
  theme(axis.text.x = element_text(angle = 45, hjust = 1)) +coord_flip()

ggsave(plot = p,filename = "./dotplot.pdf", units = "mm",width = 130,height = 180)

FFib@meta.data$subCellType<-NA
FFib@meta.data$subCellType[FFib@meta.data$RNA_snn_res.0.4%in% c(0)]<-'Fibroblast1'
FFib@meta.data$subCellType[FFib@meta.data$RNA_snn_res.0.4%in% c(1)]<-'Trophocyte1'
FFib@meta.data$subCellType[FFib@meta.data$RNA_snn_res.0.4%in% c(2)]<-'Fibroblast2'
FFib@meta.data$subCellType[FFib@meta.data$RNA_snn_res.0.4%in% c(3)]<-'Trophocyte2'
FFib@meta.data$subCellType[FFib@meta.data$RNA_snn_res.0.4%in% c(4)]<-'Myfibroblast'
FFib@meta.data$subCellType[FFib@meta.data$RNA_snn_res.0.4%in% c(5)]<-'Telocyte'
FFib@meta.data$subCellType[FFib@meta.data$RNA_snn_res.0.4%in% c(6)]<-'Pericyte'
FFib@meta.data$subCellType[FFib@meta.data$RNA_snn_res.0.4%in% c(7)]<-'Fibroblast3'

Idents(FFib)<-'subCellType'
cols<-c('#ef476f','#f78c6b','#ffd166','#83d483','#06d6a0','#0cb0a9','#118ab2','#073b4c')
DimPlot(FFib, reduction = "umap", cols = cols,label = FALSE)
saveRDS(FFib,file = "./fibroblast.rds")


library(dplyr)
library(RColorBrewer)
unique(FFib$subCellType)
group<-table(FFib$subCellType,FFib$day)
group<-as.data.frame(group)
head(group)
colnames(group)<-c('subCellType','day','number')
p<-DimPlot(FFib,reduction = 'umap', cols = values)
p
ggsave(plot = p, filename = 'F./fibroblast.Dimplot.pdf', units = 'mm' ,width = 130,height = 100)

p<-ggplot(group, aes(x=number, y=day, fill=subCellType)) +
  geom_bar(stat="identity", position=position_fill()) +
  scale_fill_manual(values = c("Fibroblast1"="#f94144", "Fibroblast2"="#f78c6b","Fibroblast3"="#ffd166", 
                               "Myfibroblast"= "#83d483", "Pericyte"="#06d6a0",      
                               "Telocyte"= "#0cb0a9", "Trophocyte1"="#118ab2","Trophocyte2"="#073b4c")) 
p
ggsave(plot=p,filename="./Fib_propotion.pdf",unit="mm",width=120,height=70)

FFib@meta.data$subCellType<-NA
FFib@meta.data$subCellType[FFib@meta.data$RNA_snn_res.0.4%in% c(0)]<-'Fibroblast1'
FFib@meta.data$subCellType[FFib@meta.data$RNA_snn_res.0.4%in% c(1)]<-'Trophocyte1'
FFib@meta.data$subCellType[FFib@meta.data$RNA_snn_res.0.4%in% c(2)]<-'Fibroblast2'
FFib@meta.data$subCellType[FFib@meta.data$RNA_snn_res.0.4%in% c(3)]<-'Trophocyte2'
FFib@meta.data$subCellType[FFib@meta.data$RNA_snn_res.0.4%in% c(4)]<-'Myfibroblast'
FFib@meta.data$subCellType[FFib@meta.data$RNA_snn_res.0.4%in% c(5)]<-'Telocyte'
FFib@meta.data$subCellType[FFib@meta.data$RNA_snn_res.0.4%in% c(6)]<-'Pericyte'
FFib@meta.data$subCellType[FFib@meta.data$RNA_snn_res.0.4%in% c(7)]<-'Fibroblast3'

Idents(FFib)<-'subCellType'
cols<-c('#ef476f','#f78c6b','#ffd166','#83d483','#06d6a0','#0cb0a9','#118ab2','#073b4c')
DimPlot(FFib, reduction = "umap", cols = cols,label = FALSE)
saveRDS(FFib,file = "./fibroblast.rds")


library(dplyr)
library(RColorBrewer)
unique(FFib$subCellType)
group<-table(FFib$subCellType,FFib$day)
group<-as.data.frame(group)
head(group)
colnames(group)<-c('subCellType','day','number')
p<-DimPlot(FFib,reduction = 'umap', cols = values)
p
ggsave(plot = p, filename = 'F:/Xudan lab/课题二_成纤维细胞/Results/new/1.细胞注释/fibroblast.Dimplot.pdf', units = 'mm' ,width = 130,height = 100)


p<-ggplot(group, aes(x=number, y=day, fill=subCellType)) +
  geom_bar(stat="identity", position=position_fill()) +
  scale_fill_manual(values = c("Fibroblast1"="#f94144", "Fibroblast2"="#f78c6b","Fibroblast3"="#ffd166", 
                               "Myfibroblast"= "#83d483", "Pericyte"="#06d6a0",      
                               "Telocyte"= "#0cb0a9", "Trophocyte1"="#118ab2","Trophocyte2"="#073b4c")) 
p
ggsave(plot=p,filename="./Fib_propotion.pdf",unit="mm",width=120,height=70)

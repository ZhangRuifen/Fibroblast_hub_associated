library(monocle)
library(Seurat)
library(tidyverse)
library(cowplot)


Fibroblast<-readRDS("./Fibroblast.rds")

Fibro<-subset(Fibroblast,idents=c("Fibroblast1","Fibroblast2","Fibroblast3"))

#### 1. Create a CDS object####
expr_matrix = GetAssayData(Fibro, layer = "counts") 
class(expr_matrix)
p_data <- Fibro@meta.data 
head(p_data)
f_data <- data.frame(gene_short_name = row.names(Fibro),row.names = row.names(Fibro))
head(f_data)
pd <- new('AnnotatedDataFrame', data = p_data)
fd <- new('AnnotatedDataFrame', data = f_data)
class(pd)

cds_pre <- newCellDataSet(expr_matrix,
                          phenoData = pd,
                          featureData = fd,
                          expressionFamily = negbinomial.size())

#### 2.Estimated size factor and dispersion ####
cds_pre <- estimateSizeFactors(cds_pre)
cds_pre$Size_Factor %>% head()
cds_pre <- estimateDispersions(cds_pre)
head(dispersionTable(cds_pre))

#### 3.Filter out the low-quality cells ####
cds_pre # 28798 features, 1956 samples 
cds_pre<- detectGenes(cds_pre,min_expr = 0.1) 
print(head(fData(cds_pre)))
expressed_genes <-row.names(subset(fData(cds_pre),num_cells_expressed >=10)) 
length(expressed_genes) # 13826

#### 4.Trajectory defines gene selection ####
diff<-differentialGeneTest(cds_pre[expressed_genes,], fullModelFormulaStr = "~subCellType", cores=1) # 基于指定的细胞亚群分类，对表达基因进行差异分析，找出不同亚群之间显著差异表达的基因
# ~后面是表示对谁做差异分析的变量，理论撒花姑娘可以是p_data的任意列名
head(diff)
dim(diff) # 14826     6
deg<- subset(diff,qval<0.01)
dim(deg) # 3978 6
head(deg)

ordergene<-rownames(deg)
cds_DGS <- setOrderingFilter(cds_pre, ordergene) 
cds_DGS <- reduceDimension(cds_DGS, method = 'DDRTree') 
saveRDS(cds_DGS,file = 'cds_DGS.rds')

cds_DGS <- readRDS('cds_DGS.rds')

cds_DGS <- orderCells(cds_DGS)

plot_cell_trajectory(cds_DGS, color_by = "Pseudotime")


# 可视化——2.以celltype上色
p4<-plot_cell_trajectory(cds_DGS, color_by = "subCellType")
pdf('Pseudotime_celltype.pdf',width = 5,height = 4)
p4
dev.off()

p4<-plot_cell_trajectory(cds_DGS, color_by = "State")
pdf('Pseudotime_state.pdf',width = 5,height = 4)
p4
dev.off()

p4<-plot_complex_cell_trajectory(cds_DGS, color_by = "subCellType")
pdf('tree.pdf',width = 5,height = 4)
p4
dev.off()


pdf('tree.pdf',width = 8,height = 7)
table(cds_DGS$State, cds_DGS$subCellType)
plot(cds_DGS$State, cds_DGS$Pseudotime)
dev.off()

cds_DGS <- orderCells(cds_DGS,root_state =2) # Fibro1,2起始都
p1<-plot_cell_trajectory(cds_DGS, color_by = "Pseudotime")
p2<-plot_cell_trajectory(cds_DGS, color_by = "subCellType")
p3<-plot_cell_trajectory(cds_DGS, color_by = "State")
p4<-plot_cell_trajectory(cds_DGS, color_by = "subCellType") +
  facet_wrap("~day", nrow = 1)


library(ggpubr)
df<-pData(cds_DGS)
view(df)
colors<-c("Fibroblast1"="#f94144", "Fibroblast2"="#83d483","Fibroblast3"= "#0cb0a9")
p5<-ggplot(df,aes(Pseudotime, colour = subCellType, fill= subCellType))+
  geom_density(bw=0.5, linewidth=1,alpha=0.5) + theme_classic2() +
  scale_fill_manual(name='', values = colors)+
  scale_color_manual(name='', values = colors)

pdf('monocle2.pdf', width = 10, height = 5)
p1|p2|p3
p4
p5
dev.off()

#### 6.Search for genes related to the timing ####

Time_diff <- differentialGeneTest(cds_DGS[ordergene,], cores = 1,
                                  fullModelFormulaStr
                                  = "~sm.ns(Pseudotime)")
Time_diff <- Time_diff[,c(5,2,3,4,1,6,7)] #把gene放前面，也可以不改

write.csv(Time_diff, "Time_diff_all.csv", row.names = F)
Time_genes <- Time_diff %>% pull(gene_short_name) %>% as.character()
p=plot_pseudotime_heatmap(cds_DGS[Time_genes,], num_clusters=3, show_rownames=FALSE, return_heatmap=TRUE) 
p
ggsave("Time_heatmapAll.pdf", p, width = 5, height = 10)


genes<-c(c('Cxcl9', 'Cxcl10', 'Cxcl14','Cxcl11',
           'Ccl2', 'Cxcl9','Saa3','Serpina3g',
           'Cxcl8', 'Il11', 'Gbp4', 'Il34',
           'Gbp5', 'Ifi44l', 'Lcn2','Mmp10'))
genes_use <- unique(genes[genes %in% rownames(fData(cds_DGS))])

pdf('genes_branched_pseudotime.pdf',width = 15,height = 10)
plot_genes_branched_pseudotime(cds_DGS[genes],color_by = 'subCellType',ncol = 4)
dev.off()


pdf('genes_in_pseudotime.pdf', width = 15, height = 10)
p <- plot_genes_branched_pseudotime(cds_DGS[genes, ], color_by = 'subCellType', ncol = 4)
p <- p + ggplot2::scale_color_manual(values = colors)
print(p)
dev.off()


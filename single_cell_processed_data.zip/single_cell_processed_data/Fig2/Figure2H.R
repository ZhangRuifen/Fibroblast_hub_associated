library(Seurat)
library(ggplot2)
library(dplyr)
library(pheatmap)

Fibro <- readRDS("./Fibroblast.rds")
Fibro <- subset(Fibro,idents = c("Fibroblast1","Fibroblast2","Fibroblast3","Trophocyte1","Trophocyte2"))

# State 1: 稳态基质型 / matrix-supporting
matrix_state_genes <- c(
  "Fn1","Col1a1","Col1a2","Col6a3","Col4a5",
  "Lamb2","Tnxb","Thbs1","Thbs2","Thbs3",
  "Fgfr1","Fgf2","Tek","Efna5",
  "Myc","Sgk1","Nr4a1","Creb5","Hsp90aa1","Pik3r1"
)


# State 2: defense / inflammatory communication
defense_inflammation_genes <- c(
  "Cxcl10","Tnfsf10","Lcn2","Saa1","Serpina3n","Stat1","Irf7","Icam1","Osmr", #,
  'Ly6e', 'Reg3b', 'Reg3g' , 'Lypd8', 'Lgals4','Ifi44', 'Il1', 'Cxcl9'
)

# State 3: Migration
myeloid_recruit <- c("Rarres2","Il34","Mdk","Robo1","Slamf8","C5ar1","Ccl8","Fgf10","Ptafr","Cxcl14","Ccl2","Ccl7") 

### 2.检查基因集
fibro <- Fibro
gene_sets <- list(
  Matrix_State = matrix_state_genes,
  defense_inflam = defense_inflammation_genes,
  Myeloid_Recruit = myeloid_recruit
)
gene_sets

cluster_col <- "subCellType" 
day_col <- "day" 

fibro$group_id <- paste(fibro@meta.data[[cluster_col]], fibro@meta.data[[day_col]], sep = "_")
table(fibro$group_id)
expr_mat <- GetAssayData(fibro, assay = "RNA", slot = "data")

# 计算每个 group 中各基因集的平均表达量
group_cells <- split(colnames(fibro), fibro$group_id)

gene_set_avg <- sapply(names(gene_sets), function(gs_name) {
  genes_use <- intersect(gene_sets[[gs_name]], rownames(expr_mat))
  
  if (length(genes_use) == 0) {
    return(rep(NA, length(group_cells)))
  }
  
  sapply(group_cells, function(cells_use) {
    sub_mat <- expr_mat[genes_use, cells_use, drop = FALSE]
    mean(sub_mat)
  })
})

gene_set_avg <- as.data.frame(gene_set_avg)
rownames(gene_set_avg) <- names(group_cells)

# 整理group顺序
meta_group <- fibro@meta.data %>%
  dplyr::select(group_id, cluster = all_of(cluster_col), day = all_of(day_col)) %>%
  distinct()

meta_group$day <- factor(meta_group$day, levels = c("day 0","day 1","day 3","day 5","day 7"))

meta_group <- meta_group %>%
  arrange(cluster, day)

gene_set_avg <- gene_set_avg[meta_group$group_id, , drop = FALSE]

#### 可视化
annotation_col <- data.frame(
  Day = meta_group$day,
  Cluster = meta_group$cluster
)
rownames(annotation_col) <- meta_group$group_id

pheatmap(
  t(as.matrix(gene_set_avg)),
  #scale = "row",
  cluster_rows = FALSE,
  cluster_cols = FALSE,
  annotation_col = annotation_col,
  annotation_colors = annotation_colors,
  border_color = NA,
  angle_col = 45,show_colnames = FALSE,
  main = "Average expression of gene sets"
)


#---------------------------
# 8. 自定义颜色
#---------------------------
cluster_colors <- c(
  "Fibroblast1" = "#f94144",
  "Fibroblast2" = "#f78c6b",
  "Fibroblast3" = "#ffd166",
  #"Myfibroblast" = "#83d483",
  #"Pericyte" = "#06d6a0",
  #"Telocyte" = "#0cb0a9",
  "Trophocyte1" = "#118ab2",
  "Trophocyte2" = "#073b4c"
)

# cell_colors_fill <- c(
#   "day 0" = "#ff595e",
#   "day 1" = "#ffca3a",
#   "day 3" = "#8ac926",
#   "day 5" = "#1982c4",
#   "day 7" = "#6a4c93"
# )
cell_colors_fill <- c(
  "day 0" = "#A8D8B9",
  "day 1" = "#F3E5AB",
  "day 3" = "#FFD1D1",
  "day 5" = "#E0F2F1",
  "day 7" = "#9EA1D4"
)


annotation_colors <- list(
  Day = cell_colors_fill,
  Cluster = cluster_colors
)

#---------------------------
# 9. 绘制热图
#---------------------------
pdf('1no_scale.Matrix_IFN.lipid_Defense.pdf',width = 12,height = 3.5)
pheatmap(
  t(as.matrix(gene_set_avg)),
  #scale = "row",
  cluster_rows = FALSE,
  cluster_cols = FALSE,
  annotation_col = annotation_col,
  annotation_colors = annotation_colors,
  border_color = NA,
  angle_col = 45,show_colnames = FALSE,
  main = "Average expression of gene sets"
)
dev.off()




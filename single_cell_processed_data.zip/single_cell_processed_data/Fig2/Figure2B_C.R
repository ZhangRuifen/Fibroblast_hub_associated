library(dplyr)
library(ggplot2)
library(dplyr)
library(ggpubr)
library(viridis)
library(hrbrthemes)
library("KEGGREST")
library(hrbrthemes)
library(org.Mm.eg.db)
library(tidytext)
library(KEGGREST)

fibro<-readRDS("./Fibroblast.rds")

### --------------- GO 通路打分 -------------------
# GO:0030198  extracellular matrix organization
# GO:0050727  regulation of inflammatory response
# GO:0042742  defense response to bacterium
# GO:0002526  acute inflammatory response
# GO:0006953  acute-phase response

acute_genes <- AnnotationDbi::select(
  org.Mm.eg.db,
  keys = "GO:0030198",
  columns = c("SYMBOL"),
  keytype = "GOALL"
)
acute_genes <- unique(acute_genes$SYMBOL)
acute_genes
length(acute_genes)

present_matrix <- intersect(acute_genes, rownames(fibro))
length(present_matrix)

DefaultAssay(fibro)<-"RNA"
fibro<-AddModuleScore(object = fibro,features = list(present_matrix),name = 'ECM')
colnames(fibro@meta.data)

data<-FetchData(fibro,vars = c("day","ECM1","subCellType"))

data$day <- factor(data$day, levels = c("day 0", "day 1", "day 3", "day 5", "day 7"))
comparisons <- list(
  c("day 1", "day 0"), c("day 3", "day 0"), c("day 5", "day 0"), c("day 7", "day 0"))
cols = c("#ff595e", "#ffca3a", "#8ac926", "#1982c4", "#6a4c93")
cols_dark = c(
  "#cc0000",  
  "#d4a700",  
  "#5c8c1a",  
  "#005c99", 
  "#4a3566"  
)

library(ggpubr)
colnames(data)
p<-ggplot(data, aes(x = day, y = ECM1, fill = day, color = day)) +
  geom_boxplot(outlier.shape = NA) + 
  scale_fill_manual(values = cols) +  
  scale_color_manual(values = cols_dark) + 
  theme_minimal() +
  theme(
    legend.position = "none",  
    plot.title = element_text(size = 11, face = "bold", hjust = 0.5), 
    axis.text.x = element_text(angle = 45, hjust = 1), 
    panel.grid.major = element_line(),  
    panel.grid.minor = element_blank(), 
    axis.line = element_line(color = "black", linewidth = 0.5) 
  ) +
  ggtitle("extracellular matrix organization") +
  xlab("") + 
  ylab("Feature Value") + 
  stat_compare_means(
    method = "wilcox.test", 
    label = "p.signif", 
    comparisons = comparisons,  
    hide.ns = TRUE 
  )
p
ggsave(plot = p,filename = "extracellular matrix organization.pdf",width = 3.5,height = 4)


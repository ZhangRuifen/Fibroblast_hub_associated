
Fibro<-readRDS('Fibroblast.rds')

Idents(Fibro)<-'day'
day1 <- FindMarkers(Fibro, ident.1 = "day 1",ident.2 = "day 0", min.pct = 0.1,only.pos=FALSE,test.use = 'wilcox')
day3 <- FindMarkers(Fibro, ident.1 = "day 3",ident.2 = "day 0", min.pct = 0.1,only.pos=FALSE,test.use = 'wilcox')
day5 <- FindMarkers(Fibro, ident.1 = "day 5",ident.2 = "day 0", min.pct = 0.1,only.pos=FALSE,test.use = 'wilcox')
day7 <- FindMarkers(Fibro, ident.1 = "day 7",ident.2 = "day 0", min.pct = 0.1,only.pos=FALSE,test.use = 'wilcox')
write.csv(day1,file = "day1_day0.csv")
write.csv(day3,file = "day3_day0.csv")
write.csv(day5,file = "day5_day0.csv")
write.csv(day7,file = "day7_day0.csv")

library(org.Mm.eg.db)
library(ggplot2)
library(clusterProfiler)
library(dplyr)
library(forcats)

a<-list.files()
dir<-paste('./',a,sep = '')
n <- length(dir)

for(i in 1:4){
  data<-read.csv(file = dir[i])
  fil_df<-data[data$p_val_adj<0.05 & data$avg_log2FC>1,]

  id <- bitr(fil_df$X,
             fromType = "SYMBOL",
             toType = "ENTREZID",
             OrgDb = "org.Mm.eg.db",
             drop = FALSE)

  KEGG <- enrichKEGG(
    id$ENTREZID,
    organism = "mmu")
  temp<-try(KEGG<-setReadable(KEGG,OrgDb = org.Mm.eg.db,keyType = 'ENTREZID'),silent=FALSE)
  if('try-error' %in% class(temp))         
  {
    temp <- NA                           
  }
  GO <- enrichGO(
    id$ENTREZID,
    OrgDb = org.Mm.eg.db,
    ont = 'ALL',readable = TRUE)
  

  kegg<-paste('KEGG_up',a[i], sep = ".")
  kegg_filename<-paste("./",kegg,sep = '')
  go<-paste('GO_up',a[i], sep = ".")
  go_filename<-paste('./',go,sep = '')
  write.csv(KEGG, file = kegg_filename)
  write.csv(GO, file = go_filename)
}


for(i in 1:4){
  data<-read.csv(file = dir[i])
  fil_df<-data[data$p_val_adj<0.05 & data$avg_log2FC< -1,]

  id <- bitr(fil_df$X,
             fromType = "SYMBOL",
             toType = "ENTREZID",
             OrgDb = "org.Mm.eg.db",
             drop = FALSE)
  KEGG <- enrichKEGG(
    id$ENTREZID,
    organism = "mmu")
  temp<-try(KEGG<-setReadable(KEGG,OrgDb = org.Mm.eg.db,keyType = 'ENTREZID'),silent=FALSE)
  if('try-error' %in% class(temp))    
  {
    temp <- NA                      
  }
  GO <- enrichGO(
    id$ENTREZID,
    OrgDb = org.Mm.eg.db,
    ont = 'ALL',readable = TRUE)

  kegg<-paste('KEGG_down',a[i], sep = ".")
  kegg_filename<-paste("./",kegg,sep = '')
  go<-paste('GO_down',a[i], sep = ".")
  go_filename<-paste('./',go,sep = '')
  write.csv(KEGG, file = kegg_filename)
  write.csv(GO, file = go_filename)
}

# 2.绘图
setwd("./")
a<-list.files()
dir<-paste('./',a,sep = '')
n <- length(dir)
dir[1]

Goblet0_d1<-read.csv(dir[2])
Goblet0_d2<-read.csv(dir[3])
Goblet0_d3<-read.csv(dir[4])
Goblet0_d4<-read.csv(dir[5])
Goblet0_d5<-read.csv(dir[6])
Goblet0_d6<-read.csv(dir[7])
Goblet0_d7<-read.csv(dir[8])
Goblet0_d8<-read.csv(dir[9])

Goblet0_d1<-read.csv(dir[10])
Goblet0_d2<-read.csv(dir[11])
Goblet0_d3<-read.csv(dir[12])
Goblet0_d4<-read.csv(dir[13])
Goblet0_d5<-read.csv(dir[14])
Goblet0_d6<-read.csv(dir[15])
Goblet0_d7<-read.csv(dir[16])


Goblet0_d1$day<-"day1_day0.down"
Goblet0_d2$day<-"day3_day0.down"
Goblet0_d3$day<-"day5_day0.down"
Goblet0_d4$day<-"day7_day0.down"
Goblet0_d5$day<-"day1_day0.up"
Goblet0_d6$day<-"day3_day0.up"
Goblet0_d7$day<-"day5_day0.up"
Goblet0_d8$day<-"day7_day0.up"


Goblet0_d1<-Goblet0_d1[1:10,]
Goblet0_d2<-Goblet0_d2[1:10,]
Goblet0_d3<-Goblet0_d3[1:10,]
Goblet0_d4<-Goblet0_d4[1:10,]
Goblet0_d5<-Goblet0_d5[1:10,]
Goblet0_d6<-Goblet0_d6[1:10,]
Goblet0_d7<-Goblet0_d7[1:10,]
Goblet0_d8<-Goblet0_d8[1:10,]

all<-rbind(Goblet0_d1,Goblet0_d2)
all<-rbind(all,Goblet0_d3)
all<-rbind(all,Goblet0_d4)
all<-rbind(all,Goblet0_d5)
all<-rbind(all,Goblet0_d6)
all<-rbind(all,Goblet0_d7)
all<-rbind(all,Goblet0_d8)

specific_order<-c('day1_day0.down','day3_day0.down','day5_day0.down','day7_day0.down',
                  'day1_day0.up',
                  'day3_day0.up','day5_day0.up','day7_day0.up')
all$day <- factor(all$day, levels = specific_order, ordered = TRUE) 

all$Description<-factor(all$Description,levels = unique(all$Description))


# GO富集绘图
ggplot(all, aes(day, Description)) +
  geom_point(aes(color= -log(p.adjust), size=Count), shape = 16)+theme_bw()+ 
  theme(panel.grid = element_blank(),
        axis.text.x=element_text(angle=45,hjust = 0.5,vjust=0.5))+
  scale_color_gradient(low='#f0e7d8',high='#a63a50')+
  labs(x=NULL,y=NULL)+guides(size=guide_legend(order=1))+ggtitle('Fibroblast.GO')

# KEGG富集绘图
all$Description <- sub(" - Mus musculus \\(house mouse\\)", "", all$Description)
all<-na.omit(all)
all$Description<-factor(all$Description,levels = unique(all$Description))
specific_order<-c('day1_day0.down','day3_day0.down','day5_day0.down','day7_day0.down',
                  #'day1_day0.up',
                  'day3_day0.up','day5_day0.up','day7_day0.up')

all$day <- factor(all$day, levels = specific_order, ordered = TRUE) 

ggplot(all, aes(day, Description)) +
  geom_point(aes(color= -log(p.adjust), size=Count), shape = 17)+theme_bw()+ 
  theme(panel.grid = element_blank(),
        axis.text.x=element_text(angle=45,hjust = 0.5,vjust=0.5))+
  scale_color_gradient(low='#d3f3f1',high='#e9b7ce')+
  labs(x=NULL,y=NULL)+guides(size=guide_legend(order=1))+ggtitle('Fibroblast.KEGG')


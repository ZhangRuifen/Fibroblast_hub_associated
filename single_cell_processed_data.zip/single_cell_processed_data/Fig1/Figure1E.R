#!/usr/bin/env Rscript

suppressPackageStartupMessages({
  required_packages <- c("ggplot2", "dplyr", "tidyr", "grid")
  missing_packages <- required_packages[!vapply(required_packages, requireNamespace, logical(1), quietly = TRUE)]
  if (length(missing_packages) > 0) {
    stop("Missing required R packages: ", paste(missing_packages, collapse = ", "))
  }
  library(ggplot2)
  library(dplyr)
  library(tidyr)
  library(grid)
})

args <- commandArgs(trailingOnly = TRUE)
project_dir <- if (length(args) >= 1) normalizePath(args[[1]], winslash = "/", mustWork = TRUE) else normalizePath(getwd(), winslash = "/", mustWork = TRUE)

table_dir <- file.path(project_dir, "Connectome", "tables")
output_dir <- file.path(project_dir, "Connectome", "high_confidence_uninfected_infected_scatter")
dir.create(output_dir, recursive = TRUE, showWarnings = FALSE)

days <- c(0, 1, 3, 5, 7)

min_percent <- 0.25

cell_colors <- c(
  "Stem/TA" = "#bf0603",
  "Progenitor_CC" = "#f06152",
  "CC_1" = "#FF7F00",
  "CC_2" = "#FB9A99",
  "Goblets" = "#fddbc8",
  "Macrophage" = "#6A3D9A",
  "Plasma" = "#33A02C",
  "B_cells" = "#76D7C4",
  "T_cells" = "#B2DF8A",
  "Neutrophil" = "#CAB2D6",
  "Fibroblast" = "#1F78B4",
  "EEC" = "#A6CEE3",
  "Endothelial" = "#B15928"
)
cell_type_levels <- names(cell_colors)

required_cols <- c("source", "target", "mode", "weight_norm", "percent.source", "percent.target", "day")
read_day_file <- function(day_number) {
  path <- file.path(table_dir, sprintf("connectome_filtered_intercellular_day_%s.csv", day_number))
  if (!file.exists(path)) stop("Missing input file: ", path)
  df <- read.csv(path, stringsAsFactors = FALSE, check.names = FALSE)
  missing_cols <- setdiff(required_cols, colnames(df))
  if (length(missing_cols) > 0) stop("Missing columns in ", path, ": ", paste(missing_cols, collapse = ", "))
  expected_day <- paste("day", day_number)
  observed_days <- unique(df$day)
  if (!all(observed_days == expected_day)) {
    stop("Day mismatch in ", path, ": expected ", expected_day, ", observed ", paste(observed_days, collapse = "; "))
  }
  df$day_number <- day_number
  df
}

edges <- bind_rows(lapply(days, read_day_file)) %>%
  filter(
    .data$source != .data$target,
    .data$mode %in% selected_modes,
    is.finite(.data$weight_norm), .data$weight_norm > 0,
    is.finite(.data$percent.source), .data$percent.source >= min_percent,
    is.finite(.data$percent.target), .data$percent.target >= min_percent
  )

all_cells <- cell_type_levels[cell_type_levels %in% sort(unique(c(edges$source, edges$target)))]
complete_grid <- expand.grid(day_number = days, cell_type = all_cells, stringsAsFactors = FALSE)

outgoing <- edges %>%
  group_by(.data$day_number, cell_type = .data$source) %>%
  summarise(outgoing_strength = sum(.data$weight_norm, na.rm = TRUE), outgoing_links = n(), .groups = "drop")

incoming <- edges %>%
  group_by(.data$day_number, cell_type = .data$target) %>%
  summarise(incoming_strength = sum(.data$weight_norm, na.rm = TRUE), incoming_links = n(), .groups = "drop")

daily <- complete_grid %>%
  left_join(outgoing, by = c("day_number", "cell_type")) %>%
  left_join(incoming, by = c("day_number", "cell_type")) %>%
  mutate(
    outgoing_strength = replace_na(.data$outgoing_strength, 0),
    incoming_strength = replace_na(.data$incoming_strength, 0),
    outgoing_links = replace_na(.data$outgoing_links, 0),
    incoming_links = replace_na(.data$incoming_links, 0),
    total_strength = .data$outgoing_strength + .data$incoming_strength,
    total_links = .data$outgoing_links + .data$incoming_links,
    day = paste("day", .data$day_number),
    group = ifelse(.data$day_number == 0, "Uninfected", "Infected")
  ) %>%
  group_by(.data$day_number) %>%
  mutate(
    raw_outgoing_rank = rank(-.data$outgoing_strength, ties.method = "min"),
    raw_incoming_rank = rank(-.data$incoming_strength, ties.method = "min"),
    raw_total_rank = rank(-.data$total_strength, ties.method = "min")
  ) %>%
  ungroup()

baseline <- daily %>%
  filter(.data$day_number == 0) %>%
  select(cell_type, base_outgoing = outgoing_strength, base_incoming = incoming_strength, base_total = total_strength)

daily <- daily %>%
  left_join(baseline, by = "cell_type") %>%
  mutate(
    outgoing_fold_vs_day0 = ifelse(.data$base_outgoing > 0, .data$outgoing_strength / .data$base_outgoing, NA_real_),
    incoming_fold_vs_day0 = ifelse(.data$base_incoming > 0, .data$incoming_strength / .data$base_incoming, NA_real_),
    total_fold_vs_day0 = ifelse(.data$base_total > 0, .data$total_strength / .data$base_total, NA_real_)
  )

grouped <- daily %>%
  group_by(.data$group, .data$cell_type) %>%
  summarise(
    n_days = n(),
    days = paste(.data$day, collapse = "; "),
    outgoing_strength = mean(.data$outgoing_strength, na.rm = TRUE),
    incoming_strength = mean(.data$incoming_strength, na.rm = TRUE),
    total_strength = mean(.data$total_strength, na.rm = TRUE),
    total_links = mean(.data$total_links, na.rm = TRUE),
    outgoing_links = mean(.data$outgoing_links, na.rm = TRUE),
    incoming_links = mean(.data$incoming_links, na.rm = TRUE),
    .groups = "drop"
  ) %>%
  mutate(group = factor(.data$group, levels = c("Uninfected", "Infected")))

group_baseline <- grouped %>%
  filter(.data$group == "Uninfected") %>%
  select(cell_type, group_base_outgoing = outgoing_strength, group_base_incoming = incoming_strength, group_base_total = total_strength)

grouped <- grouped %>%
  left_join(group_baseline, by = "cell_type") %>%
  mutate(
    outgoing_fold_vs_uninfected = ifelse(.data$group_base_outgoing > 0, .data$outgoing_strength / .data$group_base_outgoing, NA_real_),
    incoming_fold_vs_uninfected = ifelse(.data$group_base_incoming > 0, .data$incoming_strength / .data$group_base_incoming, NA_real_),
    total_fold_vs_uninfected = ifelse(.data$group_base_total > 0, .data$total_strength / .data$group_base_total, NA_real_)
  ) %>%
  group_by(.data$group) %>%
  mutate(
    outgoing_rank = rank(-.data$outgoing_strength, ties.method = "min"),
    incoming_rank = rank(-.data$incoming_strength, ties.method = "min"),
    total_rank = rank(-.data$total_strength, ties.method = "min")
  ) %>%
  ungroup()

fib_daily <- daily %>% filter(.data$cell_type == "Fibroblast")
fib_group <- grouped %>% filter(.data$cell_type == "Fibroblast")

plot_df <- grouped %>%
  mutate(
    label = ifelse(.data$cell_type == "Fibroblast", paste0("Fibroblast\nout rank ", .data$outgoing_rank, ", total rank ", .data$total_rank), .data$cell_type)
  )

x_limit <- c(0, max(plot_df$outgoing_strength, na.rm = TRUE) * 1.18)
y_limit <- c(0, max(plot_df$incoming_strength, na.rm = TRUE) * 1.22)

scatter <- ggplot(plot_df, aes(x = outgoing_strength, y = incoming_strength)) +
  geom_point(aes(size = total_strength, fill = cell_type), shape = 21, color = "grey20", stroke = 0.25, alpha = 0.92) +
  geom_text(aes(label = label), size = 2.8, check_overlap = TRUE, vjust = -0.85, color = "grey15") +
  facet_wrap(~ group, nrow = 1) +
  scale_fill_manual(values = cell_colors, breaks = cell_type_levels, drop = FALSE) +
  scale_size_continuous(range = c(3.2, 14), name = "Total strength") +
  coord_cartesian(xlim = x_limit, ylim = y_limit, clip = "off") +
  labs(
    title = "high-confidence signaling role scatter grouped by infection status",
    subtitle = "CellChat-style plot: x = outgoing strength, y = incoming strength, bubble size = total strength.; percent.source/target >= 0.25.",
    x = "Outgoing signaling strength (sum(weight_norm))",
    y = "Incoming signaling strength (sum(weight_norm))",
    fill = "Cell type",
    caption = "Uninfected = day0. Infected = mean of day1/day3/day5/day7"
  ) +
  theme_classic(base_size = 11) +
  theme(
    plot.title = element_text(face = "bold", size = 13),
    plot.subtitle = element_text(size = 9, color = "grey25"),
    strip.background = element_rect(fill = "grey95", color = "grey55", linewidth = 0.3),
    strip.text = element_text(face = "bold", size = 11),
    legend.position = "right",
    plot.caption = element_text(size = 8, color = "grey35", hjust = 0)
  )

fib_trajectory <- fib_group %>%
  mutate(
    group_label = as.character(.data$group),
    point_label = sprintf("%s\nout %.2fx / in %.2fx\nout rank %s / total rank %s", .data$group_label, .data$outgoing_fold_vs_uninfected, .data$incoming_fold_vs_uninfected, .data$outgoing_rank, .data$total_rank)
  )

pdf_file <- file.path(output_dir, "connectome_high_confidence_uninfected_infected_cellchat_style_scatter.pdf")
pdf(pdf_file, width = 11, height = 6.6, useDingbats = FALSE)
print(scatter)
print(trajectory)
dev.off()

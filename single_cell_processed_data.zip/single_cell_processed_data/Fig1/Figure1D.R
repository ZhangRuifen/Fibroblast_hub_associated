#!/usr/bin/env Rscript

options(stringsAsFactors = FALSE, warn = 1)

required_packages <- c("ggplot2")
missing_packages <- required_packages[!vapply(required_packages, requireNamespace, logical(1), quietly = TRUE)]
if (length(missing_packages) > 0L) {
  stop("Missing required R packages: ", paste(missing_packages, collapse = ", "), call. = FALSE)
}

library(ggplot2)

args <- commandArgs(trailingOnly = TRUE)
input_dir <- if (length(args) >= 1L && nzchar(args[1])) args[1] else getwd()

day_levels <- c("d0", "d1", "d3", "d5", "d7")
day_labels <- c("d0" = "Day 0", "d1" = "Day 1", "d3" = "Day 3", "d5" = "Day 5", "d7" = "Day 7")
net_lr_files <- setNames(paste0(day_levels, "_net_lr.csv"), day_levels)
fibroblast_label <- "Fibroblast"
post_infection_days <- c("d1", "d3", "d5", "d7")

cell_colors <- c(
  "Stem/TA" = "#bf0603",
  "Progenitor_CC" = "#f06152",
  "CC_1" = "#FF7F00",
  "CC_2" = "#FB9A99",
  "Goblets" = "#fddbc8",
  "Macrophage" = "#6A3D9A",
  "Plasma" = "#33A02C",
  "B_cells" = "#76D7C4",
  "T_cells" = "#B2DF8A",
  "Neutrophil" = "#CAB2D6",
  "Fibroblast" = "#1F78B4",
  "EEC" = "#A6CEE3",
  "Endothelial" = "#B15928"
)
plot_cells <- setdiff(names(cell_colors), fibroblast_label)

ink <- "#202124"
muted <- "#6B7280"
edge_incoming_colour <- "#374151"
edge_outgoing_colour <- "#1F78B4"

stopf <- function(...) {
  stop(sprintf(...), call. = FALSE)
}

resolve_base_dir <- function(path) {
  path <- normalizePath(path, winslash = "/", mustWork = TRUE)
  if (all(file.exists(file.path(path, net_lr_files)))) {
    return(path)
  }
  nested_path <- file.path(path, "CellChat")
  if (all(file.exists(file.path(nested_path, net_lr_files)))) {
    return(normalizePath(nested_path, winslash = "/", mustWork = TRUE))
  }
  stopf("Could not locate all required d*_net_lr.csv files from: %s", path)
}

require_columns <- function(columns, required, file_label) {
  missing <- setdiff(required, columns)
  if (length(missing) > 0L) {
    stopf("%s missing required columns: %s. Available columns: %s", file_label, paste(missing, collapse = ", "), paste(columns, collapse = ", "))
  }
}

read_net_lr <- function(path, day_id) {
  file_label <- basename(path)
  df <- read.csv(path, check.names = FALSE, stringsAsFactors = FALSE)
  names(df) <- trimws(names(df))
  required <- c("source", "target", "ligand", "receptor", "prob", "pval", "interaction_name", "interaction_name_2", "pathway_name", "annotation", "evidence")
  require_columns(names(df), required, file_label)
  if (nrow(df) == 0L) {
    stopf("%s has no rows.", file_label)
  }

  prob <- suppressWarnings(as.numeric(df[["prob"]]))
  if (any(is.na(prob) & !is.na(df[["prob"]]))) {
    stopf("%s column prob contains values that cannot be converted to numeric.", file_label)
  }
  if (any(!is.finite(prob))) {
    stopf("%s column prob contains missing or non-finite values.", file_label)
  }
  if (any(prob < 0)) {
    stopf("%s column prob contains negative values.", file_label)
  }

  data.frame(
    day = day_id,
    source = trimws(as.character(df[["source"]])),
    target = trimws(as.character(df[["target"]])),
    prob = prob,
    stringsAsFactors = FALSE
  )
}

aggregate_source_target <- function(df) {
  prob_sum <- aggregate(prob ~ day + source + target, data = df, FUN = sum)
  names(prob_sum)[names(prob_sum) == "prob"] <- "prob_sum"
  lr_count <- aggregate(prob ~ day + source + target, data = df, FUN = length)
  names(lr_count)[names(lr_count) == "prob"] <- "lr_count"
  merge(prob_sum, lr_count, by = c("day", "source", "target"), all = TRUE, sort = FALSE)
}

build_fibroblast_edges <- function(aggregated_df) {
  incoming <- aggregated_df[aggregated_df$target == fibroblast_label & aggregated_df$source != fibroblast_label, , drop = FALSE]
  incoming$direction <- "Incoming to Fibroblast"
  outgoing <- aggregated_df[aggregated_df$source == fibroblast_label & aggregated_df$target != fibroblast_label, , drop = FALSE]
  outgoing$direction <- "Fibroblast outgoing"
  edges <- rbind(incoming, outgoing)
  if (nrow(edges) == 0L) {
    stop("No Fibroblast-centered non-self edges were found.", call. = FALSE)
  }
  edges$day <- factor(edges$day, levels = day_levels)
  edges$day_label <- unname(day_labels[as.character(edges$day)])
  edges <- edges[order(edges$day, edges$direction, edges$source, edges$target), , drop = FALSE]
  edges
}

make_daily_nodes <- function() {
  x_positions <- seq(-3.7, 3.7, length.out = length(plot_cells))
  top_nodes <- data.frame(
    node_id = paste0("incoming_", plot_cells),
    cell_type = plot_cells,
    section = "Incoming sources",
    x = x_positions,
    y = 1.25,
    label_y = 1.58,
    label_angle = 35,
    stringsAsFactors = FALSE
  )
  middle_node <- data.frame(
    node_id = fibroblast_label,
    cell_type = fibroblast_label,
    section = "Fibroblast",
    x = 0,
    y = 0,
    label_y = 0,
    label_angle = 0,
    stringsAsFactors = FALSE
  )
  bottom_nodes <- data.frame(
    node_id = paste0("outgoing_", plot_cells),
    cell_type = plot_cells,
    section = "Outgoing targets",
    x = x_positions,
    y = -1.25,
    label_y = -1.65,
    label_angle = -35,
    stringsAsFactors = FALSE
  )
  nodes <- rbind(top_nodes, middle_node, bottom_nodes)
  nodes$cell_type <- factor(nodes$cell_type, levels = names(cell_colors))
  nodes
}

make_daily_plot_edges <- function(day_edges, nodes) {
  top_x <- setNames(nodes$x[nodes$section == "Incoming sources"], as.character(nodes$cell_type[nodes$section == "Incoming sources"]))
  bottom_x <- setNames(nodes$x[nodes$section == "Outgoing targets"], as.character(nodes$cell_type[nodes$section == "Outgoing targets"]))

  incoming <- day_edges[day_edges$direction == "Incoming to Fibroblast", , drop = FALSE]
  if (nrow(incoming) > 0L) {
    incoming$x <- unname(top_x[incoming$source])
    incoming$y <- 1.08
    incoming$xend <- 0
    incoming$yend <- 0.20
    incoming$edge_colour <- edge_incoming_colour
  }

  outgoing <- day_edges[day_edges$direction == "Fibroblast outgoing", , drop = FALSE]
  if (nrow(outgoing) > 0L) {
    outgoing$x <- 0
    outgoing$y <- -0.20
    outgoing$xend <- unname(bottom_x[outgoing$target])
    outgoing$yend <- -1.08
    outgoing$edge_colour <- edge_outgoing_colour
  }
  rbind(incoming, outgoing)
}

make_daily_network_plot <- function(day_id, edges_df, global_edge_max) {
  nodes <- make_daily_nodes()
  day_edges <- edges_df[as.character(edges_df$day) == day_id, , drop = FALSE]
  plot_edges <- make_daily_plot_edges(day_edges, nodes)
  incoming_edges <- plot_edges[plot_edges$direction == "Incoming to Fibroblast", , drop = FALSE]
  outgoing_edges <- plot_edges[plot_edges$direction == "Fibroblast outgoing", , drop = FALSE]
  title_text <- paste0("Fibroblast-centered LR probability network - ", day_labels[[day_id]])

  ggplot() +
    geom_curve(
      data = incoming_edges,
      aes(x = x, y = y, xend = xend, yend = yend, linewidth = prob_sum),
      curvature = -0.12,
      colour = edge_incoming_colour,
      alpha = 0.72,
      lineend = "round",
      arrow = grid::arrow(length = grid::unit(0.08, "inches"), type = "closed")
    ) +
    geom_curve(
      data = outgoing_edges,
      aes(x = x, y = y, xend = xend, yend = yend, linewidth = prob_sum),
      curvature = 0.12,
      colour = edge_outgoing_colour,
      alpha = 0.72,
      lineend = "round",
      arrow = grid::arrow(length = grid::unit(0.08, "inches"), type = "closed")
    ) +
    geom_point(
      data = nodes,
      aes(x = x, y = y, fill = cell_type),
      shape = 21,
      colour = ink,
      stroke = 0.35,
      size = 7.0,
      show.legend = FALSE
    ) +
    geom_text(
      data = nodes,
      aes(x = x, y = label_y, label = cell_type, angle = label_angle),
      size = 2.1,
      colour = ink,
      lineheight = 0.9
    ) +
    annotate("text", x = -4.55, y = 1.86, label = "Cells -> Fibroblast", hjust = 0, size = 2.9, fontface = "bold", colour = ink) +
    annotate("text", x = -4.55, y = 0.20, label = "Fibroblast", hjust = 0, size = 2.9, fontface = "bold", colour = ink) +
    annotate("text", x = -4.55, y = -1.86, label = "Fibroblast -> Cells", hjust = 0, size = 2.9, fontface = "bold", colour = ink) +
    scale_fill_manual(values = cell_colors, limits = names(cell_colors), drop = FALSE) +
    scale_linewidth_continuous(name = "sum(prob)", limits = c(0, global_edge_max), range = c(0.18, 2.8)) +
    coord_cartesian(xlim = c(-4.75, 4.75), ylim = c(-2.05, 2.05), clip = "off") +
    labs(
      title = title_text,
      subtitle = "Edges are source-target sum(prob) across ligand-receptor rows | Fibroblast self-loop excluded",
      x = NULL,
      y = NULL
    ) +
    theme_void(base_size = 9, base_family = "sans") +
    theme(
      plot.title = element_text(face = "bold", colour = ink, size = 10.5, hjust = 0),
      plot.subtitle = element_text(colour = muted, size = 7.5, hjust = 0, margin = margin(t = 2, b = 3)),
      legend.position = "right",
      legend.title = element_text(size = 7.5, colour = ink, face = "bold"),
      legend.text = element_text(size = 6.8, colour = ink),
      plot.margin = margin(5, 5, 5, 5)
    )
}

build_comparison_edges <- function(fibroblast_edges) {
  build_direction <- function(direction_label) {
    if (direction_label == "Incoming to Fibroblast") {
      observed <- fibroblast_edges[fibroblast_edges$direction == direction_label, c("day", "source", "prob_sum"), drop = FALSE]
      names(observed)[names(observed) == "source"] <- "partner"
    } else {
      observed <- fibroblast_edges[fibroblast_edges$direction == direction_label, c("day", "target", "prob_sum"), drop = FALSE]
      names(observed)[names(observed) == "target"] <- "partner"
    }

    full_grid <- expand.grid(day = day_levels, partner = plot_cells, stringsAsFactors = FALSE)
    full_df <- merge(full_grid, observed, by = c("day", "partner"), all.x = TRUE, sort = FALSE)
    full_df$prob_sum[is.na(full_df$prob_sum)] <- 0

    uninfected <- full_df[full_df$day == "d0", c("partner", "prob_sum"), drop = FALSE]
    uninfected$condition <- "Day0 uninfected"
    infected <- aggregate(prob_sum ~ partner, data = full_df[full_df$day %in% post_infection_days, , drop = FALSE], FUN = mean)
    infected$condition <- "Post-infection mean"

    direction_df <- rbind(uninfected, infected)
    direction_df$direction <- direction_label
    direction_df$day_basis <- ifelse(direction_df$condition == "Day0 uninfected", "d0", paste(post_infection_days, collapse = ","))
    if (direction_label == "Incoming to Fibroblast") {
      direction_df$source <- direction_df$partner
      direction_df$target <- fibroblast_label
    } else {
      direction_df$source <- fibroblast_label
      direction_df$target <- direction_df$partner
    }
    direction_df$cell_type <- direction_df$partner
    direction_df[, c("condition", "day_basis", "direction", "source", "target", "cell_type", "prob_sum")]
  }

  comparison <- rbind(
    build_direction("Incoming to Fibroblast"),
    build_direction("Fibroblast outgoing")
  )
  comparison$condition <- factor(comparison$condition, levels = c("Day0 uninfected", "Post-infection mean"))
  comparison$direction <- factor(comparison$direction, levels = c("Incoming to Fibroblast", "Fibroblast outgoing"))
  comparison <- comparison[order(comparison$condition, comparison$direction, match(comparison$cell_type, plot_cells)), , drop = FALSE]
  comparison$condition <- as.character(comparison$condition)
  comparison$direction <- as.character(comparison$direction)
  comparison
}

add_direction_visual_weights <- function(df, linewidth_min = 0.45, linewidth_max = 3.25) {
  original_prob_sum <- df$prob_sum
  df$visual_scale_max <- ave(df$prob_sum, df$direction, FUN = function(x) {
    max_x <- max(x, na.rm = TRUE)
    ifelse(is.finite(max_x) && max_x > 0, max_x, 1)
  })
  df$visual_weight <- ifelse(df$visual_scale_max > 0, df$prob_sum / df$visual_scale_max, 0)
  df$visual_linewidth <- linewidth_min + df$visual_weight * (linewidth_max - linewidth_min)
  df$visual_scale_note <- ifelse(
    df$direction == "Incoming to Fibroblast",
    "Incoming linewidth scaled within incoming edges only",
    "Outgoing linewidth scaled within outgoing edges only"
  )
  if (!identical(original_prob_sum, df$prob_sum)) {
    stop("Visual linewidth scaling changed raw prob_sum values.", call. = FALSE)
  }
  df
}

format_prob_label <- function(x) {
  formatC(x, format = "e", digits = 2)
}

build_day_direction_summary <- function(edges_df) {
  directions <- c("Incoming to Fibroblast", "Fibroblast outgoing")
  full_grid <- expand.grid(day = day_levels, direction = directions, stringsAsFactors = FALSE)
  daily_totals <- aggregate(prob_sum ~ day + direction, data = edges_df, FUN = sum)
  daily_totals$day <- as.character(daily_totals$day)
  summary_df <- merge(full_grid, daily_totals, by = c("day", "direction"), all.x = TRUE, sort = FALSE)
  summary_df$prob_sum[is.na(summary_df$prob_sum)] <- 0
  summary_df$day <- factor(summary_df$day, levels = day_levels)
  summary_df$day_label <- factor(unname(day_labels[as.character(summary_df$day)]), levels = unname(day_labels[day_levels]))
  summary_df$d0_total <- NA_real_
  for (direction_label in directions) {
    idx <- summary_df$direction == direction_label
    d0_total <- summary_df$prob_sum[idx & as.character(summary_df$day) == "d0"]
    d0_total <- if (length(d0_total) == 1L && is.finite(d0_total) && d0_total > 0) d0_total else NA_real_
    summary_df$d0_total[idx] <- d0_total
  }
  summary_df$fold_change_vs_d0 <- ifelse(
    is.finite(summary_df$d0_total) & summary_df$d0_total > 0,
    summary_df$prob_sum / summary_df$d0_total,
    NA_real_
  )
  summary_df$value_label <- format_prob_label(summary_df$prob_sum)
  summary_df$fold_label <- ifelse(
    is.finite(summary_df$fold_change_vs_d0),
    paste0("x", formatC(summary_df$fold_change_vs_d0, format = "f", digits = 2)),
    "xNA"
  )
  summary_df$plot_label <- paste(summary_df$value_label, summary_df$fold_label, sep = " ")
  summary_df <- summary_df[order(summary_df$direction, summary_df$day), , drop = FALSE]
  summary_df
}

make_day_direction_summary_plot <- function(summary_df) {
  direction_colours <- c("Incoming to Fibroblast" = edge_incoming_colour, "Fibroblast outgoing" = edge_outgoing_colour)

  ggplot(summary_df, aes(x = day_label, y = prob_sum, group = direction, fill = direction, colour = direction)) +
    geom_col(width = 0.58, alpha = 0.70, show.legend = FALSE) +
    geom_line(linewidth = 0.7, show.legend = FALSE) +
    geom_point(shape = 21, size = 2.8, stroke = 0.35, colour = ink, show.legend = FALSE) +
    geom_text(aes(label = paste(value_label, fold_label, sep = "\n")), vjust = -0.35, size = 2.25, colour = ink, show.legend = FALSE) +
    facet_wrap(~ direction, scales = "free_y", nrow = 2) +
    scale_fill_manual(values = direction_colours, limits = names(direction_colours), drop = FALSE) +
    scale_colour_manual(values = direction_colours, limits = names(direction_colours), drop = FALSE) +
    scale_y_continuous(labels = function(x) formatC(x, format = "e", digits = 1), expand = expansion(mult = c(0, 0.22))) +
    labs(
      title = "Fibroblast incoming/outgoing LR probability totals by day",
      subtitle = "Raw total sum(prob) by day and direction; labels show raw total and fold change vs Day 0 | facet y-axes are free for visibility",
      x = NULL,
      y = "Raw total sum(prob)"
    ) +
    theme_minimal(base_size = 9, base_family = "sans") +
    theme(
      plot.title = element_text(face = "bold", colour = ink, size = 11, hjust = 0),
      plot.subtitle = element_text(colour = muted, size = 8, hjust = 0, margin = margin(t = 2, b = 8)),
      axis.text.x = element_text(colour = ink, size = 8),
      axis.text.y = element_text(colour = muted, size = 7.5),
      axis.title.y = element_text(colour = ink, size = 8.5, face = "bold", margin = margin(r = 6)),
      strip.text = element_text(face = "bold", colour = ink, size = 9),
      panel.grid.major.x = element_blank(),
      panel.grid.minor = element_blank(),
      plot.margin = margin(8, 8, 8, 8)
    )
}

make_daily_enhanced_network_plot <- function(day_id, edges_df) {
  required_visual_cols <- c("visual_weight", "visual_linewidth", "visual_scale_max", "visual_scale_note")
  if (!all(required_visual_cols %in% names(edges_df))) {
    stop("Enhanced daily plotting data are missing visual linewidth columns.", call. = FALSE)
  }
  nodes <- make_daily_nodes()
  day_edges <- edges_df[as.character(edges_df$day) == day_id, , drop = FALSE]
  plot_edges <- make_daily_plot_edges(day_edges, nodes)
  incoming_edges <- plot_edges[plot_edges$direction == "Incoming to Fibroblast", , drop = FALSE]
  outgoing_edges <- plot_edges[plot_edges$direction == "Fibroblast outgoing", , drop = FALSE]
  title_text <- paste0("Enhanced Fibroblast LR probability network - ", day_labels[[day_id]])

  ggplot() +
    geom_curve(
      data = incoming_edges,
      aes(x = x, y = y, xend = xend, yend = yend, linewidth = visual_linewidth),
      curvature = -0.12,
      colour = edge_incoming_colour,
      alpha = 0.82,
      lineend = "round",
      arrow = grid::arrow(length = grid::unit(0.08, "inches"), type = "closed")
    ) +
    geom_curve(
      data = outgoing_edges,
      aes(x = x, y = y, xend = xend, yend = yend, linewidth = visual_linewidth),
      curvature = 0.12,
      colour = edge_outgoing_colour,
      alpha = 0.78,
      lineend = "round",
      arrow = grid::arrow(length = grid::unit(0.08, "inches"), type = "closed")
    ) +
    geom_point(
      data = nodes,
      aes(x = x, y = y, fill = cell_type),
      shape = 21,
      colour = ink,
      stroke = 0.35,
      size = 7.0,
      show.legend = FALSE
    ) +
    geom_text(
      data = nodes,
      aes(x = x, y = label_y, label = cell_type, angle = label_angle),
      size = 2.1,
      colour = ink,
      lineheight = 0.9
    ) +
    annotate("text", x = -4.55, y = 1.86, label = "Cells -> Fibroblast", hjust = 0, size = 2.9, fontface = "bold", colour = edge_incoming_colour) +
    annotate("text", x = -4.55, y = 0.20, label = "Fibroblast", hjust = 0, size = 2.9, fontface = "bold", colour = ink) +
    annotate("text", x = -4.55, y = -1.86, label = "Fibroblast -> Cells", hjust = 0, size = 2.9, fontface = "bold", colour = edge_outgoing_colour) +
    scale_fill_manual(values = cell_colors, limits = names(cell_colors), drop = FALSE) +
    scale_linewidth_identity(guide = "none") +
    coord_cartesian(xlim = c(-4.75, 4.75), ylim = c(-2.05, 2.05), clip = "off") +
    labs(
      title = title_text,
      subtitle = "Raw prob_sum unchanged; linewidth visually scaled separately within incoming/outgoing directions across all days | compare same direction only",
      x = NULL,
      y = NULL
    ) +
    theme_void(base_size = 9, base_family = "sans") +
    theme(
      plot.title = element_text(face = "bold", colour = ink, size = 10.5, hjust = 0),
      plot.subtitle = element_text(colour = muted, size = 7.5, hjust = 0, margin = margin(t = 2, b = 3)),
      plot.margin = margin(5, 5, 5, 5)
    )
}

make_comparison_plot <- function(comparison_edges) {
  required_visual_cols <- c("visual_weight", "visual_linewidth", "visual_scale_max", "visual_scale_note")
  if (!all(required_visual_cols %in% names(comparison_edges))) {
    stop("Comparison plotting data are missing visual linewidth columns.", call. = FALSE)
  }
  conditions <- c("Day0 uninfected", "Post-infection mean")
  condition_centres <- c("Day0 uninfected" = -5.2, "Post-infection mean" = 5.2)
  cell_offsets <- seq(-3.7, 3.7, length.out = length(plot_cells))

  top_nodes <- do.call(rbind, lapply(conditions, function(condition) {
    data.frame(
      condition = condition,
      cell_type = plot_cells,
      section = "Incoming sources",
      x = condition_centres[[condition]] + cell_offsets,
      y = 1.35,
      label_y = 1.70,
      label_angle = 35,
      stringsAsFactors = FALSE
    )
  }))
  fibroblast_nodes <- data.frame(
    condition = conditions,
    cell_type = fibroblast_label,
    section = "Fibroblast",
    x = unname(condition_centres[conditions]),
    y = 0,
    label_y = 0,
    label_angle = 0,
    stringsAsFactors = FALSE
  )
  bottom_nodes <- do.call(rbind, lapply(conditions, function(condition) {
    data.frame(
      condition = condition,
      cell_type = plot_cells,
      section = "Outgoing targets",
      x = condition_centres[[condition]] + cell_offsets,
      y = -1.35,
      label_y = -1.78,
      label_angle = -35,
      stringsAsFactors = FALSE
    )
  }))
  nodes <- rbind(top_nodes, fibroblast_nodes, bottom_nodes)
  nodes$cell_type <- factor(nodes$cell_type, levels = names(cell_colors))

  edge_df <- comparison_edges[comparison_edges$prob_sum > 0, , drop = FALSE]
  edge_df$x <- NA_real_
  edge_df$y <- NA_real_
  edge_df$xend <- NA_real_
  edge_df$yend <- NA_real_
  edge_df$edge_colour <- ifelse(edge_df$direction == "Incoming to Fibroblast", edge_incoming_colour, edge_outgoing_colour)
  for (condition in conditions) {
    condition_idx <- edge_df$condition == condition
    cell_x <- setNames(condition_centres[[condition]] + cell_offsets, plot_cells)
    incoming_idx <- condition_idx & edge_df$direction == "Incoming to Fibroblast"
    outgoing_idx <- condition_idx & edge_df$direction == "Fibroblast outgoing"
    edge_df$x[incoming_idx] <- unname(cell_x[edge_df$source[incoming_idx]])
    edge_df$y[incoming_idx] <- 1.20
    edge_df$xend[incoming_idx] <- condition_centres[[condition]]
    edge_df$yend[incoming_idx] <- 0.18
    edge_df$x[outgoing_idx] <- condition_centres[[condition]]
    edge_df$y[outgoing_idx] <- -0.18
    edge_df$xend[outgoing_idx] <- unname(cell_x[edge_df$target[outgoing_idx]])
    edge_df$yend[outgoing_idx] <- -1.20
  }
  incoming_edges <- edge_df[edge_df$direction == "Incoming to Fibroblast", , drop = FALSE]
  outgoing_edges <- edge_df[edge_df$direction == "Fibroblast outgoing", , drop = FALSE]

  ggplot() +
    geom_curve(
      data = incoming_edges,
      aes(x = x, y = y, xend = xend, yend = yend, linewidth = visual_linewidth),
      curvature = -0.10,
      colour = edge_incoming_colour,
      alpha = 0.82,
      lineend = "round",
      arrow = grid::arrow(length = grid::unit(0.08, "inches"), type = "closed")
    ) +
    geom_curve(
      data = outgoing_edges,
      aes(x = x, y = y, xend = xend, yend = yend, linewidth = visual_linewidth),
      curvature = 0.10,
      colour = edge_outgoing_colour,
      alpha = 0.74,
      lineend = "round",
      arrow = grid::arrow(length = grid::unit(0.08, "inches"), type = "closed")
    ) +
    geom_point(
      data = nodes,
      aes(x = x, y = y, fill = cell_type),
      shape = 21,
      colour = ink,
      stroke = 0.35,
      size = 7.1,
      show.legend = FALSE
    ) +
    geom_text(
      data = nodes,
      aes(x = x, y = label_y, label = cell_type, angle = label_angle),
      size = 2.05,
      colour = ink,
      lineheight = 0.9
    ) +
    annotate("text", x = condition_centres[["Day0 uninfected"]], y = 2.15, label = "Day0 uninfected", fontface = "bold", size = 3.3, colour = ink) +
    annotate("text", x = condition_centres[["Post-infection mean"]], y = 2.15, label = "Infected mean (d1/d3/d5/d7)", fontface = "bold", size = 3.3, colour = ink) +
    annotate("text", x = condition_centres[["Day0 uninfected"]] - 4.45, y = 1.82, label = "Cells -> Fibroblast", hjust = 0, size = 2.6, fontface = "bold", colour = edge_incoming_colour) +
    annotate("text", x = condition_centres[["Post-infection mean"]] - 4.45, y = 1.82, label = "Cells -> Fibroblast", hjust = 0, size = 2.6, fontface = "bold", colour = edge_incoming_colour) +
    annotate("text", x = condition_centres[["Day0 uninfected"]] - 4.45, y = -2.02, label = "Fibroblast -> Cells", hjust = 0, size = 2.6, fontface = "bold", colour = edge_outgoing_colour) +
    annotate("text", x = condition_centres[["Post-infection mean"]] - 4.45, y = -2.02, label = "Fibroblast -> Cells", hjust = 0, size = 2.6, fontface = "bold", colour = edge_outgoing_colour) +
    annotate("text", x = 0, y = -2.30, label = "Visual note: edge widths are scaled separately within incoming and outgoing directions; compare widths within the same direction only.", size = 2.35, colour = muted) +
    geom_vline(xintercept = 0, linetype = "dashed", linewidth = 0.25, colour = "#D1D5DB") +
    scale_fill_manual(values = cell_colors, limits = names(cell_colors), drop = FALSE) +
    scale_linewidth_identity(guide = "none") +
    coord_cartesian(xlim = c(-9.7, 9.7), ylim = c(-2.42, 2.30), clip = "off") +
    labs(
      title = "Fibroblast LR probability network: uninfected vs infected mean",
      subtitle = "Raw prob_sum unchanged; network linewidth visually scaled separately within incoming and outgoing directions | self-loop excluded",
      x = NULL,
      y = NULL
    ) +
    theme_void(base_size = 9, base_family = "sans") +
    theme(
      plot.title = element_text(face = "bold", colour = ink, size = 11, hjust = 0),
      plot.subtitle = element_text(colour = muted, size = 8, hjust = 0, margin = margin(t = 2, b = 4)),
      legend.position = "right",
      legend.title = element_text(size = 8, colour = ink, face = "bold"),
      legend.text = element_text(size = 7, colour = ink),
      plot.margin = margin(6, 6, 6, 6)
    )
}

make_incoming_comparison_plot <- function(comparison_edges) {
  incoming_df <- comparison_edges[comparison_edges$direction == "Incoming to Fibroblast", , drop = FALSE]
  if (nrow(incoming_df) == 0L) {
    stop("No incoming comparison edges available for incoming-only plot.", call. = FALSE)
  }

  day0 <- incoming_df[incoming_df$condition == "Day0 uninfected", c("cell_type", "prob_sum"), drop = FALSE]
  infected <- incoming_df[incoming_df$condition == "Post-infection mean", c("cell_type", "prob_sum"), drop = FALSE]
  names(day0)[names(day0) == "prob_sum"] <- "day0_prob_sum"
  names(infected)[names(infected) == "prob_sum"] <- "infected_prob_sum"
  incoming_wide <- merge(day0, infected, by = "cell_type", all = TRUE, sort = FALSE)
  incoming_wide$day0_prob_sum[is.na(incoming_wide$day0_prob_sum)] <- 0
  incoming_wide$infected_prob_sum[is.na(incoming_wide$infected_prob_sum)] <- 0
  incoming_wide$delta <- incoming_wide$infected_prob_sum - incoming_wide$day0_prob_sum
  incoming_wide$max_prob <- pmax(incoming_wide$day0_prob_sum, incoming_wide$infected_prob_sum)
  incoming_wide$delta_label <- paste0("Delta=", format_prob_label(incoming_wide$delta))

  cell_levels <- incoming_wide$cell_type[order(incoming_wide$delta, match(incoming_wide$cell_type, plot_cells))]
  incoming_wide$cell_type <- factor(incoming_wide$cell_type, levels = cell_levels)
  incoming_df$cell_type <- factor(incoming_df$cell_type, levels = cell_levels)
  incoming_df$value_label <- format_prob_label(incoming_df$prob_sum)

  incoming_x_max <- max(incoming_wide$max_prob, na.rm = TRUE)
  incoming_x_max <- ifelse(is.finite(incoming_x_max) && incoming_x_max > 0, incoming_x_max, 1)
  incoming_wide$label_x <- incoming_wide$max_prob + incoming_x_max * 0.04

  condition_colours <- c("Day0 uninfected" = "#4B5563", "Post-infection mean" = "#D55E00")

  ggplot() +
    geom_segment(
      data = incoming_wide,
      aes(x = day0_prob_sum, xend = infected_prob_sum, y = cell_type, yend = cell_type),
      colour = "#D1D5DB",
      linewidth = 0.55,
      lineend = "round"
    ) +
    geom_point(
      data = incoming_df,
      aes(x = prob_sum, y = cell_type, fill = condition),
      shape = 21,
      colour = ink,
      stroke = 0.28,
      size = 3.0
    ) +
    geom_text(
      data = incoming_df,
      aes(x = prob_sum, y = cell_type, label = value_label, colour = condition),
      nudge_y = 0.22,
      size = 2.25,
      show.legend = FALSE
    ) +
    geom_text(
      data = incoming_wide,
      aes(x = label_x, y = cell_type, label = delta_label),
      hjust = 0,
      size = 2.35,
      colour = muted
    ) +
    scale_fill_manual(values = condition_colours, limits = names(condition_colours), drop = FALSE) +
    scale_colour_manual(values = condition_colours, limits = names(condition_colours), drop = FALSE) +
    scale_x_continuous(
      labels = function(x) formatC(x, format = "e", digits = 1),
      expand = expansion(mult = c(0.02, 0.24))
    ) +
    labs(
      title = "Incoming LR probability to Fibroblast: uninfected vs infected mean",
      subtitle = "Raw incoming prob_sum values only; infected is mean of d1/d3/d5/d7 after zero-fill; no normalization",
      x = "Raw incoming mean/sum(prob)",
      y = NULL,
      fill = NULL
    ) +
    theme_minimal(base_size = 9, base_family = "sans") +
    theme(
      plot.title = element_text(face = "bold", colour = ink, size = 11, hjust = 0),
      plot.subtitle = element_text(colour = muted, size = 8, hjust = 0, margin = margin(t = 2, b = 6)),
      axis.text.y = element_text(colour = ink, size = 8),
      axis.text.x = element_text(colour = muted, size = 7.5),
      axis.title.x = element_text(colour = ink, size = 8.5, face = "bold", margin = margin(t = 6)),
      panel.grid.major.y = element_blank(),
      panel.grid.minor = element_blank(),
      legend.position = "top",
      legend.text = element_text(size = 8, colour = ink),
      plot.margin = margin(7, 20, 7, 8)
    )
}

base_dir <- resolve_base_dir(input_dir)
output_dir <- if (length(args) >= 2L && nzchar(args[2])) normalizePath(args[2], winslash = "/", mustWork = FALSE) else file.path(base_dir, "output_new")
dir.create(output_dir, recursive = TRUE, showWarnings = FALSE)


comparison_pdf_path <- file.path(output_dir, "fibroblast_lr_network_uninfected_vs_infected.pdf")
daily_edges_csv_path <- file.path(output_dir, "fibroblast_lr_network_by_day_edges.csv")
day_direction_summary_csv_path <- file.path(output_dir, "fibroblast_lr_network_by_day_direction_summary.csv")
comparison_csv_path <- file.path(output_dir, "fibroblast_lr_network_day0_uninfected_vs_infected_mean.csv")

pdf_width <- 8.0
pdf_height <- 10.5
enhanced_day_pdf_width <- 8.0
enhanced_day_pdf_height <- 10.5
comparison_pdf_width <- 12.0
comparison_pdf_height <- 8.5

net_data <- do.call(rbind, lapply(day_levels, function(day_id) {
  read_net_lr(file.path(base_dir, net_lr_files[[day_id]]), day_id)
}))

unknown_cells <- setdiff(unique(c(net_data$source, net_data$target)), names(cell_colors))
if (length(unknown_cells) > 0L) {
  stopf("Missing colors for cell types found in net_lr files: %s", paste(unknown_cells, collapse = ", "))
}
if (!any(net_data$source == fibroblast_label) && !any(net_data$target == fibroblast_label)) {
  stopf("No %s rows found in source or target columns.", fibroblast_label)
}

source_target_edges <- aggregate_source_target(net_data)
fibroblast_edges <- build_fibroblast_edges(source_target_edges)
fibroblast_edges_for_enhanced <- add_direction_visual_weights(fibroblast_edges)
if (!identical(fibroblast_edges$prob_sum, fibroblast_edges_for_enhanced$prob_sum)) {
  stop("Enhanced daily visual scaling changed raw prob_sum values.", call. = FALSE)
}
comparison_edges <- build_comparison_edges(fibroblast_edges)
comparison_edges_for_plot <- add_direction_visual_weights(comparison_edges)
if (!identical(comparison_edges$prob_sum, comparison_edges_for_plot$prob_sum)) {
  stop("Comparison visual scaling changed raw prob_sum values.", call. = FALSE)
}
required_visual_cols <- c("visual_weight", "visual_linewidth", "visual_scale_max", "visual_scale_note")
if (!all(required_visual_cols %in% names(comparison_edges_for_plot)) || !all(required_visual_cols %in% names(fibroblast_edges_for_enhanced))) {
  stop("Visual scaling columns are missing after add_direction_visual_weights().", call. = FALSE)
}
day_direction_summary <- build_day_direction_summary(fibroblast_edges)

self_loop_rows <- source_target_edges[source_target_edges$source == fibroblast_label & source_target_edges$target == fibroblast_label, , drop = FALSE]
non_self_ok <- !any(fibroblast_edges$source == fibroblast_label & fibroblast_edges$target == fibroblast_label)
daily_edge_max <- max(fibroblast_edges$prob_sum, na.rm = TRUE)
comparison_edge_max <- max(comparison_edges$prob_sum, na.rm = TRUE)
daily_edge_max <- ifelse(is.finite(daily_edge_max) && daily_edge_max > 0, daily_edge_max, 1)
comparison_edge_max <- ifelse(is.finite(comparison_edge_max) && comparison_edge_max > 0, comparison_edge_max, 1)
daily_incoming_scale_max <- max(fibroblast_edges$prob_sum[fibroblast_edges$direction == "Incoming to Fibroblast"], na.rm = TRUE)
daily_outgoing_scale_max <- max(fibroblast_edges$prob_sum[fibroblast_edges$direction == "Fibroblast outgoing"], na.rm = TRUE)
daily_incoming_scale_max <- ifelse(is.finite(daily_incoming_scale_max) && daily_incoming_scale_max > 0, daily_incoming_scale_max, 1)
daily_outgoing_scale_max <- ifelse(is.finite(daily_outgoing_scale_max) && daily_outgoing_scale_max > 0, daily_outgoing_scale_max, 1)
comparison_incoming_scale_max <- max(comparison_edges$prob_sum[comparison_edges$direction == "Incoming to Fibroblast"], na.rm = TRUE)
comparison_outgoing_scale_max <- max(comparison_edges$prob_sum[comparison_edges$direction == "Fibroblast outgoing"], na.rm = TRUE)
comparison_incoming_scale_max <- ifelse(is.finite(comparison_incoming_scale_max) && comparison_incoming_scale_max > 0, comparison_incoming_scale_max, 1)
comparison_outgoing_scale_max <- ifelse(is.finite(comparison_outgoing_scale_max) && comparison_outgoing_scale_max > 0, comparison_outgoing_scale_max, 1)
daily_visual_policy <- "Raw prob_sum is unchanged in CSV; enhanced day-wise network linewidths are visually scaled separately within incoming and outgoing directions across all days. Compare widths within the same direction only."
comparison_visual_policy <- "Raw prob_sum is unchanged in CSV; comparison network linewidths are visually scaled separately within incoming and outgoing directions. Compare widths within the same direction only."

write.csv(fibroblast_edges, daily_edges_csv_path, row.names = FALSE)
write.csv(day_direction_summary, day_direction_summary_csv_path, row.names = FALSE)
write.csv(comparison_edges, comparison_csv_path, row.names = FALSE)

pdf(comparison_pdf_path, width = comparison_pdf_width, height = comparison_pdf_height, useDingbats = FALSE, family = "sans", onefile = TRUE)
print(make_comparison_plot(comparison_edges_for_plot))
print(make_incoming_comparison_plot(comparison_edges))
dev.off()

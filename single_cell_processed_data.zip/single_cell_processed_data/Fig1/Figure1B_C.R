library(CellChat)
install.packages(c("devtools", "remotes", "BiocManager")) 
BiocManager::install(c("SingleCellExperiment", "SummarizedExperiment", "GenomicRanges", "rGREAT", "scran", "scater", "Rtsne", "igraph"))
library(SingleCellExperiment)
library(SummarizedExperiment)
library(GenomicRanges)
library(rGREAT)
library(scran)
library(scater)
library(Rtsne)
library(igraph)
library(patchwork)

install.packages('NMF')
devtools::install_github("jokergoo/circlize")
devtools::install_github("jokergoo/ComplexHeatmap")


#### Figure1B ####
DefaultAssay(obj_new_annotation)
obj_new_annotation<-JoinLayers(obj_new_annotation)
obj.list<-SplitObject(obj_new_annotation,split.by = 'day')
data.input = obj.list[["day 1"]]@assays[["RNA"]]@layers[["data"]]
labels <- Idents(obj.list[["day 1"]])
meta <- data.frame(labels = labels, row.names = names(labels)) 

CellChat <- createCellChat(object = obj.list[["day 1"]], group.by = "ident", assay = "RNA")
groupSize <- as.numeric(table(CellChat@idents)) 

CellChatDB <- CellChatDB.mouse
showDatabaseCategory(CellChatDB)
CellChatDB.use <- CellChatDB # simply use the default CellChatDB
CellChat@DB <- CellChatDB.use

CellChat <- subsetData(CellChat) # This step is necessary even if using the whole database
CellChat <- identifyOverExpressedGenes(CellChat)  
CellChat <- identifyOverExpressedInteractions(CellChat)

CellChat <- computeCommunProb(CellChat, population.size = TRUE) 
CellChat <- filterCommunication(CellChat, min.cells = 10) 

df.net <- subsetCommunication(cellchat) 
write.csv(df.net, "d7_net_lr.csv")


CellChat <- computeCommunProbPathway(CellChat) 
head(CellChat@net)
head(CellChat@netP)

CellChat <- aggregateNet(CellChat)

groupSize <- as.numeric(table(CellChat@idents))

par(mfrow = c(1,2), xpd=TRUE) 
netVisual_circle(CellChat@net$count, vertex.weight = groupSize,
                 weight.scale = T, label.edge= F,
                 title.name = "Number of interactions")
netVisual_circle(CellChat@net$weight, vertex.weight = groupSize,
                 weight.scale = T, label.edge= F,
                 title.name = "Interaction weights/strength")
dev.off()

mat <- CellChat@net$weight
mat<- as.data.frame(mat)
par(mfrow = c(3,5), mar = c(2, 2, 2, 2), xpd=TRUE)
for (i in 1:nrow(mat)) 
    {
  mat2 <- matrix(0, nrow = nrow(mat), ncol = ncol(mat), dimnames = dimnames(mat))
  mat2<- as.data.frame(mat2)
  mat2[i, ] <- mat[i, ]
  mat2 <- as.matrix(mat2)
  netVisual_circle(mat2, vertex.weight = groupSize,
                   weight.scale = T, edge.weight.max = max(mat),
                   title.name = rownames(mat)[i])
  }
dev.off()
getwd()


getwd()
groupSize <- as.numeric(table(cellchat_d1@idents))
netVisual_circle(cellchat_d1@net$weight, vertex.weight = groupSize,
                 weight.scale = T, label.edge= F,
                 title.name = paste0("Interaction weights/strength - ", names(object.list)[i]),
                 targets.use = 'T_cells')
current_cell_order <- colnames(cellchat_d1@net[["weight"]])
new_index <- match(new_cell_order, current_cell_order) 


object.list <- list(d0 = cellchat_d0, d1 = cellchat_d1,d3 = cellchat_d3, d5 = cellchat_d5,d7 = cellchat_d7)


new_cell_order <- c( "B_cells", "Plasma","Neutrophil", "Stem/TA","Progenitor_CC",
                     "CC_1", "CC_2", "Goblets", "EEC", "Endothelial",
                     "Fibroblast", "Macrophage","T_cells")  

for(i in 1:5){

  current_cell_order <- colnames(object.list[[i]]@net[["weight"]])

  new_index <- match(new_cell_order, current_cell_order) 

  weight_matrix <- object.list[[i]]@net[["weight"]]

  sorted_weight_matrix <- weight_matrix[new_index, new_index]

  object.list[[i]]@net[["weight"]] <- sorted_weight_matrix
  
  object.list[[i]]@meta$CellType <- factor(object.list[[i]]@meta$CellType, 
                                           levels = new_cell_order)
}


#### Figure1C ####
cellchat_d0 <- readRDS("./cellchat_d0.rds")
cellchat_d1 <- readRDS("./cellchat_d1.rds")
cellchat_d3 <- readRDS("./cellchat_d3.rds")
cellchat_d5 <- readRDS("./cellchat_d5.rds")
cellchat_d7 <- readRDS("./cellchat_d7.rds")

object.list <- list(d0 = cellchat_d0, d1 = cellchat_d1,d3 = cellchat_d3, d5 = cellchat_d5,d7 = cellchat_d7)
cellchat <- mergeCellChat(object.list, add.names = names(object.list))
cellchat

weight_d0<-cellchat_d0@net$weight
weight_d1<-cellchat_d1@net$weight
weight_d3<-cellchat_d3@net$weight
weight_d5<-cellchat_d5@net$weight
weight_d7<-cellchat_d7@net$weight
weight_list<-list(weight_d0,weight_d1,weight_d3,weight_d5,weight_d7)
names(weight_list)<-c("day 0","day 1","day 3","day 5","day 7")

palette_receiver <- c("Stem/TA" = "#bf0603", "Progenitor_CC" = "#f06152", "CC_1" = "#FF7F00", 
                        "CC_2" = "#FB9A99", "Goblets" = "#fddbc8", "Macrophage" = "#6A3D9A", 
                        "Plasma" = "#33A02C", "B_cells" = "#76D7C4", "T_cells" = "#B2DF8A", 
                        "Neutrophil" = "#CAB2D6", "Fibroblast" = "#1F78B4", 
                        "EEC" = "#A6CEE3", "Endothelial" = "#B15928")

receivers<-c("CC_1","Progenitor_CC","Stem/TA","CC_2","Macrophage","Goblets","Plasma",
           "EEC","T_cells","Fibroblast","B_cells","Endothelial","Neutrophil")

in_df <- lapply(names(weight_list), function(day_name){
  W <- weight_list[[day_name]]
  if (is.null(W)) return(NULL)
  
  W <- as.matrix(W)

  diag(W) <- 0  
  
  recv_use <- intersect(receivers, colnames(W))
  if (length(recv_use) == 0) return(NULL)
  
  in_strength <- colSums(W[, recv_use, drop = FALSE], na.rm = TRUE)
  
  data.frame(
    day = day_name,
    receiver = names(in_strength),
    incoming_strength = as.numeric(in_strength),
    row.names = NULL
  )
}) %>% dplyr::bind_rows()


in_df$receiver <- factor(in_df$receiver, levels = names(palette_receiver))
days <- levels(factor(in_df$day, levels = c("day 0","day 1","day 3","day 5","day 7")))

plots <- lapply(days, function(d){
  df <- in_df %>% filter(day == d) %>%
    arrange(desc(incoming_strength)) %>%
    mutate(receiver = factor(receiver, levels = receiver))  # 此处按当日降序重排
  
  ggplot(df, aes(x = receiver, y = incoming_strength, fill = receiver)) +
    geom_col() +
    scale_fill_manual(values = palette_receiver, guide = "none") +
    labs(x = NULL, y = "Outgoing interaction strength (sum to others)",
         title = paste0(d, " — outgoing strength (sorted desc)")) +
    theme_minimal(base_size = 13) +
    theme(axis.text.x = element_text(angle = 45, hjust = 1))
})

colors <- c("Stem/TA"="#bf0603",  "Progenitor_CC"="#f06152","CC_1"="#FF7F00","CC_2"="#FB9A99","Goblets"="#fddbc8",
            "Macrophage"="#6A3D9A","Plasma"="#33A02C","B_cells"="#76D7C4","T_cells"="#B2DF8A","Neutrophil"="#CAB2D6",
            "Fibroblast"="#1F78B4","EEC"="#A6CEE3","Endothelial"="#B15928")


day<- c("day 0","day 1","day 3","day 5","day 7")
Fibroblast_incoming<- list()
for (i in 1:5) {

  cellchat_filtered <- as.matrix(weight_list[[i]])
  diag(cellchat_filtered) <- NA  
  
  col_sums <- colSums(cellchat_filtered, na.rm = TRUE)
  
  total_strength <- sum(cellchat_filtered, na.rm = TRUE)
  
  ratio_df <- data.frame(
    Cell_Type = rownames(weight_d1),
    Col_sums = col_sums,
    Total_Strength_Ratio = col_sums / total_strength,
    row.names = NULL
  )
  ratio_df$day<- day[i]
  
  Fibroblast_incoming[[i]]<- ratio_df[ratio_df$Cell_Type %in% "Fibroblast",]
}
Fibroblast_incoming
Fibroblast_incoming.all<-do.call(rbind,Fibroblast_incoming)
df<-Fibroblast_incoming.all
colnames(df)

cols = c("#ff595e", "#ffca3a", "#8ac926", "#1982c4", "#6a4c93")

p <- ggplot(df, aes(x = day, y = Total_Strength_Ratio, fill = day)) +
  geom_col(width = 0.6) +
  scale_fill_manual(values = cols) +
  scale_y_continuous(
    #breaks = c(0,0.05, 0.1, 0.15, 0.2, 0.25, 0.3, 0.35)  # 👈 设置Y轴刻度
  ) +
  labs(
    title = "The weight ratio of Fibroblast (Receiver)",
    x = "day",
    y = "ratio of weight",
    fill = "day"
  ) +
  theme_minimal() +
  theme(
    axis.text.x = element_text(angle = 45, hjust = 1, size = 10),
    plot.title = element_text(hjust = 0.5, size = 12, face = "bold"),
    legend.position = "none",
    axis.line = element_line(color = "black", linewidth = 0.5) 
  )
p
ggsave(plot = p,filename = "The weight ratio of Fibroblast_incoming.pdf", width = 4, height = 4)


#!/usr/bin/env Rscript

suppressPackageStartupMessages({
  pkgs <- c("dplyr", "tidyr", "ggplot2", "igraph", "gridExtra", "grid")
  missing <- pkgs[!vapply(pkgs, requireNamespace, logical(1), quietly = TRUE)]
  if (length(missing) > 0) stop("Missing packages: ", paste(missing, collapse = ", "))
  library(dplyr)
  library(tidyr)
  library(ggplot2)
  library(igraph)
  library(gridExtra)
  library(grid)
})

args <- commandArgs(trailingOnly = TRUE)
project_dir <- if (length(args) >= 1) normalizePath(args[[1]], winslash = "/", mustWork = TRUE) else normalizePath(getwd(), winslash = "/", mustWork = TRUE)
tables_dir <- file.path(project_dir, "Connectome", "tables")
out_dir <- file.path(project_dir, "Connectome")
dir.create(out_dir, recursive = TRUE, showWarnings = FALSE)

expected_days <- c("day 0", "day 1", "day 3", "day 5", "day 7")
day_numbers <- c(0, 1, 3, 5, 7)
thresholds <- c(0.10, 0.20, 0.25, 0.30, 0.40, 0.50)
aggregations <- c("sum_post_days", "mean_post_days")
primary_threshold <- 0.25
primary_aggregation <- "sum_post_days"

cell_colors <- c(
  "Stem/TA" = "#bf0603", "Progenitor_CC" = "#f06152", "CC_1" = "#FF7F00",
  "CC_2" = "#FB9A99", "Goblets" = "#fddbc8", "Macrophage" = "#6A3D9A",
  "Plasma" = "#33A02C", "B_cells" = "#76D7C4", "T_cells" = "#B2DF8A",
  "Neutrophil" = "#CAB2D6", "Fibroblast" = "#1F78B4", "EEC" = "#A6CEE3",
  "Endothelial" = "#B15928"
)
cell_types <- names(cell_colors)

read_day <- function(day_num, day_label) {
  f <- file.path(tables_dir, sprintf("connectome_filtered_intercellular_day_%s.csv", day_num))
  if (!file.exists(f)) stop("Missing input: ", f)
  d <- read.csv(f, stringsAsFactors = FALSE, check.names = FALSE)
  required <- c("source", "target", "mode", "weight_norm", "percent.source", "percent.target", "day")
  missing <- setdiff(required, colnames(d))
  if (length(missing) > 0) stop("Missing columns in ", f, ": ", paste(missing, collapse = ", "))
  if (!all(unique(d$day) == day_label)) stop("Day mismatch in ", f)
  d$day_number <- day_num
  d
}

all_edges <- bind_rows(Map(read_day, day_numbers, expected_days))
all_edges <- all_edges %>%
  mutate(
    weight_norm = as.numeric(.data$weight_norm),
    percent.source = as.numeric(.data$percent.source),
    percent.target = as.numeric(.data$percent.target)
  )

rank_desc <- function(x) rank(-x, ties.method = "min", na.last = "keep")

make_group_edges <- function(edges, threshold, aggregation) {
  filtered <- edges %>%
    filter(
      .data$mode == mode_use,
      .data$source != .data$target,
      is.finite(.data$weight_norm), .data$weight_norm > 0,
      is.finite(.data$percent.source), is.finite(.data$percent.target),
      .data$percent.source >= threshold,
      .data$percent.target >= threshold
    )
  if (nrow(filtered) == 0) return(list(lr_edges = filtered, grouped = filtered %>% select(source, target) %>% mutate(group = character(), weight = numeric())))
  if (aggregation == "sum_post_days") {
    filtered <- filtered %>% mutate(group = ifelse(.data$day_number == 0, "Uninfected", "Infected"))
    grouped <- filtered %>%
      group_by(.data$group, .data$source, .data$target) %>%
      summarise(weight = sum(.data$weight_norm, na.rm = TRUE), n_lr_edges = n(), .groups = "drop")
  } else {
    day_edge <- filtered %>%
      group_by(.data$day_number, .data$source, .data$target) %>%
      summarise(day_weight = sum(.data$weight_norm, na.rm = TRUE), .groups = "drop") %>%
      mutate(group = ifelse(.data$day_number == 0, "Uninfected", "Infected"))
    grouped <- day_edge %>%
      group_by(.data$group, .data$source, .data$target) %>%
      summarise(weight = ifelse(unique(.data$group) == "Uninfected", sum(.data$day_weight), mean(.data$day_weight)), n_lr_edges = n(), .groups = "drop")
  }
  list(lr_edges = filtered, grouped = grouped %>% filter(.data$weight > 0))
}

compute_group_centrality <- function(grouped_edges, threshold, aggregation) {
  rows <- list()
  for (grp in c("Uninfected", "Infected")) {
    g_edges <- grouped_edges %>% filter(.data$group == grp)
    vertices <- data.frame(name = cell_types, stringsAsFactors = FALSE)
    if (nrow(g_edges) == 0) {
      rows[[grp]] <- data.frame(group = grp, cell_type = cell_types, outgoing_strength = 0, incoming_strength = 0, total_strength = 0, pagerank = NA_real_, hub_score = NA_real_, authority_score = NA_real_, betweenness = NA_real_, out_closeness = NA_real_, in_closeness = NA_real_)
      next
    }
    graph <- graph_from_data_frame(g_edges %>% select(from = .data$source, to = .data$target, weight = .data$weight), directed = TRUE, vertices = vertices)
    E(graph)$distance <- 1 / (E(graph)$weight + 1e-6)
    out_strength <- strength(graph, mode = "out", weights = E(graph)$weight)
    in_strength <- strength(graph, mode = "in", weights = E(graph)$weight)
    total_strength <- out_strength + in_strength
    pr <- page_rank(graph, directed = TRUE, weights = E(graph)$weight)$vector
    hs <- hub_score(graph, weights = E(graph)$weight)$vector
    as <- authority_score(graph, weights = E(graph)$weight)$vector
    btw <- betweenness(graph, directed = TRUE, weights = E(graph)$distance, normalized = TRUE)
    out_close <- closeness(graph, mode = "out", weights = E(graph)$distance, normalized = TRUE)
    in_close <- closeness(graph, mode = "in", weights = E(graph)$distance, normalized = TRUE)
    rows[[grp]] <- data.frame(
      group = grp,
      cell_type = names(out_strength),
      outgoing_strength = as.numeric(out_strength),
      incoming_strength = as.numeric(in_strength),
      total_strength = as.numeric(total_strength),
      pagerank = as.numeric(pr[names(out_strength)]),
      hub_score = as.numeric(hs[names(out_strength)]),
      authority_score = as.numeric(as[names(out_strength)]),
      betweenness = as.numeric(btw[names(out_strength)]),
      out_closeness = as.numeric(out_close[names(out_strength)]),
      in_closeness = as.numeric(in_close[names(out_strength)]),
      stringsAsFactors = FALSE
    )
  }
  bind_rows(rows) %>%
    group_by(.data$group) %>%
    mutate(
      outgoing_rank = rank_desc(.data$outgoing_strength),
      incoming_rank = rank_desc(.data$incoming_strength),
      total_rank = rank_desc(.data$total_strength),
      pagerank_rank = rank_desc(.data$pagerank),
      hub_rank = rank_desc(.data$hub_score),
      authority_rank = rank_desc(.data$authority_score),
      betweenness_rank = rank_desc(.data$betweenness),
      out_closeness_rank = rank_desc(.data$out_closeness),
      in_closeness_rank = rank_desc(.data$in_closeness),
      threshold = threshold,
      aggregation = aggregation,
      mode = mode_use
    ) %>%
    ungroup()
}

screen_rows <- list()
centrality_rows <- list()
for (thr in thresholds) {
  for (agg in aggregations) {
    ge <- make_group_edges(all_edges, thr, agg)
    cent <- compute_group_centrality(ge$grouped, thr, agg)
    centrality_rows[[paste(thr, agg, sep = "_")]] <- cent
    fib <- cent %>% filter(.data$cell_type == "Fibroblast")
    fib_u <- fib %>% filter(.data$group == "Uninfected")
    fib_i <- fib %>% filter(.data$group == "Infected")
    screen_rows[[paste(thr, agg, sep = "_")]] <- data.frame(
      mode = mode_use,
      threshold = thr,
      aggregation = agg,
      n_lr_edges = nrow(ge$lr_edges),
      n_grouped_edges = nrow(ge$grouped),
      outgoing_fold = fib_i$outgoing_strength / fib_u$outgoing_strength,
      incoming_fold = fib_i$incoming_strength / fib_u$incoming_strength,
      total_fold = fib_i$total_strength / fib_u$total_strength,
      pagerank_delta = fib_i$pagerank - fib_u$pagerank,
      hub_delta = fib_i$hub_score - fib_u$hub_score,
      authority_delta = fib_i$authority_score - fib_u$authority_score,
      betweenness_delta = fib_i$betweenness - fib_u$betweenness,
      out_closeness_fold = fib_i$out_closeness / fib_u$out_closeness,
      in_closeness_fold = fib_i$in_closeness / fib_u$in_closeness,
      infected_outgoing_rank = fib_i$outgoing_rank,
      infected_incoming_rank = fib_i$incoming_rank,
      infected_total_rank = fib_i$total_rank,
      infected_pagerank_rank = fib_i$pagerank_rank,
      infected_hub_rank = fib_i$hub_rank,
      infected_authority_rank = fib_i$authority_rank,
      infected_betweenness_rank = fib_i$betweenness_rank,
      infected_out_closeness_rank = fib_i$out_closeness_rank,
      infected_in_closeness_rank = fib_i$in_closeness_rank,
      output_supported = fib_i$outgoing_strength / fib_u$outgoing_strength >= 1.1 && fib_i$outgoing_rank == 1 && fib_i$hub_rank == 1,
      input_strength_supported = fib_i$incoming_strength / fib_u$incoming_strength >= 1.1,
      receiver_rank1_supported = fib_i$incoming_rank == 1 && fib_i$authority_rank == 1 && fib_i$pagerank_rank == 1,
      sender_rank1_supported = fib_i$outgoing_rank == 1 && fib_i$total_rank == 1 && fib_i$hub_rank == 1,
      stringsAsFactors = FALSE
    )
  }
}

screen <- bind_rows(screen_rows) %>%
  mutate(
    support_score = as.integer(.data$output_supported) + as.integer(.data$input_strength_supported) + as.integer(.data$sender_rank1_supported) + as.integer(.data$receiver_rank1_supported),
    claim_tier = case_when(
      .data$sender_rank1_supported & .data$input_strength_supported & .data$receiver_rank1_supported ~ "sender_and_receiver_rank1_supported",
      .data$sender_rank1_supported & .data$input_strength_supported ~ "sender_and_input_strength_supported",
      .data$sender_rank1_supported ~ "sender_supported_only",
      TRUE ~ "not_supported"
    )
  ) %>% arrange(desc(.data$support_score), desc(.data$n_lr_edges), .data$threshold)

all_cent <- bind_rows(centrality_rows)
selected <- screen %>% filter(.data$threshold == primary_threshold, .data$aggregation == primary_aggregation) %>% slice(1)
if (nrow(selected) == 0) selected <- screen %>% slice(1)
selected_cent <- all_cent %>% filter(.data$threshold == selected$threshold, .data$aggregation == selected$aggregation)

metric_order <- c("outgoing_strength", "incoming_strength", "total_strength", "hub_score", "authority_score", "pagerank", "betweenness", "out_closeness", "in_closeness")
metric_labels <- c(outgoing_strength = "Outgoing", incoming_strength = "Incoming", total_strength = "Total", hub_score = "HITS hub", authority_score = "HITS authority", pagerank = "PageRank", betweenness = "Betweenness", out_closeness = "Out-closeness", in_closeness = "In-closeness")
rank_cols <- c(outgoing_strength = "outgoing_rank", incoming_strength = "incoming_rank", total_strength = "total_rank", hub_score = "hub_rank", authority_score = "authority_rank", pagerank = "pagerank_rank", betweenness = "betweenness_rank", out_closeness = "out_closeness_rank", in_closeness = "in_closeness_rank")

selected_long <- bind_rows(lapply(metric_order, function(m) {
  data.frame(group = selected_cent$group, cell_type = selected_cent$cell_type, metric = m, metric_label = metric_labels[m], value = selected_cent[[m]], rank = selected_cent[[rank_cols[m]]], is_fibroblast = selected_cent$cell_type == "Fibroblast", stringsAsFactors = FALSE)
}))
selected_long$metric_label <- factor(selected_long$metric_label, levels = metric_labels[metric_order])
selected_long$metric_class <- ifelse(selected_long$metric %in% c("incoming_strength", "authority_score", "pagerank", "in_closeness"), "Receiver/input or prestige", ifelse(selected_long$metric == "betweenness", "Bridge", "Sender/output hub"))
selected_long$group <- factor(selected_long$group, levels = c("Uninfected", "Infected"))

p1_data <- selected_long %>%
  mutate(
    metric_label = factor(metric_label, levels = rev(metric_labels[metric_order])),
    metric_class = factor(metric_class, levels = c("Sender/output hub", "Bridge", "Receiver/input or prestige"))
  )

p1 <- ggplot(p1_data, aes(x = group, y = metric_label)) +
  geom_point(aes(size = value), shape = 21, fill = "#D7D7D7", color = "white", stroke = 0.25, alpha = 0.9) +
  geom_point(data = p2_data %>% filter(is_fibroblast), aes(size = value), shape = 21, fill = "#1F78B4", color = "#1F78B4", stroke = 0.2, alpha = 0.95) +
  geom_text(data = p2_data %>% filter(is_fibroblast), aes(label = paste0("r", rank)), nudge_x = 0.18, size = 2.35, color = "#1F78B4") +
  facet_grid(metric_class ~ ., scales = "free_y", space = "free_y") +
  scale_size_continuous(range = c(1.2, 7.8), breaks = waiver()) +
  labs(
    title = "Selected CXCL graph centrality",
    subtitle = sprintf("threshold %.2f; %s", selected$threshold, selected$aggregation),
    x = NULL, y = NULL, size = "Value"
  ) +
  theme_classic(base_size = 8.5) +
  theme(
    plot.title = element_text(face = "bold", size = 10.5),
    plot.subtitle = element_text(size = 7.5, color = "grey35"),
    axis.text = element_text(size = 7.6, color = "grey20"),
    strip.background = element_rect(fill = "#F2F2F2", color = "grey70", linewidth = 0.25),
    strip.text = element_text(face = "bold", size = 7.4),
    legend.position = "right",
    legend.title = element_text(size = 7),
    legend.text = element_text(size = 6.5),
    legend.key.size = unit(0.25, "cm"),
    panel.spacing.y = unit(0.08, "cm"),
    plot.margin = margin(4, 5, 2, 4)
  )

pdf_file <- file.path(out_dir, "Fibroblast selected graph centrality.pdf")
pdf(pdf_file, width = 6.8, height = 4.8, useDingbats = FALSE)
grid.newpage(); grid.draw(ggplotGrob(p21))
dev.off()

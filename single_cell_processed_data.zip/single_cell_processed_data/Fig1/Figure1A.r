
library(RColorBrewer)
library(Seurat)
library(tidyverse)
library(mascarade)
library(data.table)

obj_new_annotation <- readRDS('obj.rds')

# A.Epithelial(5个): CC_1,Stem/TA,CC_2,Goblets,Progenitor_CC  
"#EBAEA9","#EBCC96","#CBE5DE","#EED0E0","#CB95BB"
# B.Immune(5个): Macrophage,Plasma,B_cells,T_cells,Neutrophil
"#95A6DA","#BFA6C9","#F5E0BA","#AED0DF","#89B780",
# C.Stromal(1个): Fibroblast
"#F5D8D0"
# D.Others(3个): EEC,Endothelial,Adipocyte
"#83B4EF","#7EC0C3"

Idents(obj_new_annotation)<- obj_new_annotation$CellType

new_order <- c("Stem/TA","Progenitor_CC","CC_1","CC_2","Goblets",
               "Macrophage","Plasma","B_cells","T_cells","Neutrophil",
               "Fibroblast","EEC","Endothelial")
colors <- c( "#bf0603","#f06152","#FF7F00","#FB9A99","#fddbc8",
             "#6A3D9A","#33A02C","#76D7C4","#B2DF8A","#CAB2D6",
             "#1F78B4","#A6CEE3","#B15928")

obj_new_annotation$seurat_clusters <- factor(Idents(obj_new_annotation), levels = new_order) # 将最新顺序放到“Seurat_Cluster”中
Idents(obj_new_annotation) <- obj_new_annotation$seurat_clusters
DimPlot(obj_new_annotation,cols = colors)



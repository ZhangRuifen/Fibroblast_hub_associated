
library(Seurat)
library(dplyr)
library(tidyr)
library(ggplot2)
library(UCell)
library(rstatix)

unique(Idents(Fib))

Fib$fib_subtype <- as.character(Idents(Fib))

complement_production_mouse <- c(
  "C3",
  "C1ra", "C1rb", "C1s1",
  "C2", "C4b",
  "Cfb", "Cfd", "Cfp",
  "C5", "C6", "C7", "C8b", "C9"
)

complement_production_mouse <- c("C3","C1rb", "C2","Cfb", "Cfd")

inflammatory_chemokine_mouse <- c(
  "Il6", "Ccl2", "Cxcl14", "Il34", "Ccl8",
  "Ccl7", "Cxcl1", "Cxcl10", "Ccl19", "Il33"
)

gene_sets_raw <- list(
  Complement_production = complement_production_mouse,
  Inflammatory_chemokine = inflammatory_chemokine_mouse
)

all_genes <- rownames(Fib)

gene_sets_use <- lapply(gene_sets_raw, function(x) {
  intersect(x, all_genes)
})

gene_sets_missing <- lapply(gene_sets_raw, function(x) {
  setdiff(x, all_genes)
})

gene_sets_use
gene_sets_missing

### 1.UCell打分
Fib <- AddModuleScore_UCell(
  Fib,
  features = gene_sets_use,
  assay = "RNA"
)
### 2.AddmoduleScore打分
Fib <- AddModuleScore(
  object = Fib,
  features = list(gene_sets_use$Complement_production),
  assay = "RNA",
  name = "Complement_AMS"
)

Fib <- AddModuleScore(
  object = Fib,
  features = list(gene_sets_use$Inflammatory_chemokine),
  assay = "RNA",
  name = "Inflammatory_AMS"
)

# 整理day 信息
plot_df <- Fib@meta.data %>%
  as.data.frame() %>%
  mutate(
    cell = rownames(.),
    day_num = as.numeric(gsub("[^0-9]", "", day)),
    day_label = paste0("d", day_num),
    fib_subtype = factor(
      fib_subtype,
      levels = c("Fibroblast1", "Fibroblast2", "Trophocyte1")
    ),
    day_label = factor(
      day_label,
      levels = c("d0", "d1", "d3", "d5")
    )
  )

score_df <- plot_df %>%
  select(
    cell, fib_subtype, day, day_num, day_label,
    Complement_production_UCell,
    Inflammatory_chemokine_UCell,
    Complement_AMS1,
    Inflammatory_AMS1
  ) %>%
  pivot_longer(
    cols = c(
      Complement_production_UCell,
      Inflammatory_chemokine_UCell,
      Complement_AMS1,
      Inflammatory_AMS1
    ),
    names_to = "score_name",
    values_to = "score"
  ) %>%
  mutate(
    method = case_when(
      grepl("AMS", score_name) ~ "AddModuleScore"
    ),
    signature = case_when(
      grepl("Complement", score_name) ~ "Complement production",
      grepl("Inflammatory", score_name) ~ "Inflammatory / chemokine"
    )
  )

summary_df <- score_df %>%
  group_by(method, signature, fib_subtype, day_num, day_label) %>%
  summarise(
    mean_score = mean(score, na.rm = TRUE),
    median_score = median(score, na.rm = TRUE),
    sem = sd(score, na.rm = TRUE) / sqrt(n()),
    n = n(),
    .groups = "drop"
  )

fib_colors <- c(
  "Fibroblast1" = "#f94144",
  "Fibroblast2" = "#f78c6b",
  "Trophocyte1" = "#118ab2"
)

summary_df_norm_plot <- summary_df_norm %>%
  mutate(
    day_label = factor(
      paste0("d", day_num),
      levels = c("d0", "d1", "d3", "d5", "d7")
    ),
    day_index = as.numeric(day_label)
  )

colnames(summary_df_norm_plot)
unique(summary_df_norm_plot$method)
p_delta_smooth <- summary_df_norm_plot %>%
  filter(method == "AddModuleScore") %>%
  ggplot(aes(
    x = day_index,
    y = mean_score_delta_d0,
    color = fib_subtype,
    group = fib_subtype
  )) +
  geom_hline(
    yintercept = 0,
    linetype = "dashed",
    color = "grey60"
  ) +
  geom_point(size = 3) +
  geom_smooth(
    method = "loess",
    formula = y ~ x,
    se = FALSE,
    span = 0.9,
    linewidth = 1.2
  ) +
  facet_wrap(~signature, scales = "free_y", nrow = 1) +
  scale_color_manual(values = fib_colors) +
  scale_x_continuous(
    breaks = 1:5,
    labels = c("d0", "d1", "d3", "d5", "d7"),
    expand = expansion(mult = c(0.05, 0.05))
  ) +
  theme_classic() +
  theme(
    strip.text = element_text(size = 12, face = "bold"),
    legend.title = element_blank(),
    axis.text.x = element_text(size = 10),
    axis.text.y = element_text(size = 10)
  ) +
  labs(
    x = "Day after infection",
    y = "Change relative to d0",
    title = "Normalized fibroblast subtype program dynamics"
  )

p_delta_smooth

ggsave(p_delta_smooth,file = 'dynamic.Addmodule_d0_baseline.pdf',width = 8,height = 3.5)
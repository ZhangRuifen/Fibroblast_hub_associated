library(Seurat)
library(UCell)
library(dplyr)
library(tidyr)
library(ggplot2)
library(ggpubr)
library(patchwork)
library(tibble)

## =========================
## 0. 基本设置
## =========================
ff <- readRDS("F:/Xudan lab/课题二_成纤维细胞/Results/new/fibroblast.rds")

Fib12 <- subset(ff, idents = c("Fibroblast1", "Fibroblast2", "Trophocyte1"))
DefaultAssay(Fib12) <- "RNA"

cluster_col <- "subCellType"
day_col <- "day"
target_clusters <- c("Fibroblast1", "Fibroblast2", "Trophocyte1")
target_days <- c("day 0", "day 1", "day 3", "day 5")

day_color_map <- c(
  "day0" = "#1f55a3",
  "day1" = "#d46c07",
  "day3" = "#9e2020",
  "day5" = "#1f7f1f"
)

day_label_map <- c(
  "day0" = "day 0",
  "day1" = "day 1",
  "day3" = "day 3",
  "day5" = "day 5"
)

day_comparisons <- list(
  c("day 1", "day 0"),
  c("day 3", "day 0"),
  c("day 5", "day 0")

fib3_obj <- Fib12

## =========================
## 1. 定义基因集
## =========================
immune_recruit_activate <- c(
  "Ccl2", "Ccl7", "Ccl8",
  "Cxcl1", "Cxcl10",
  "Ccl19",
  "Il6", "Il33",
  "Cxcl14", "Il34"
)

complement_production_mouse <- c(
  "C3",
  "C1ra", "C1rb", "C1s1",
  "C2", "C4b",
  "Cfb", "Cfd", "Cfp",
  "C5", "C6", "C7", "C8b", "C9"
)
sig_list_raw <- list(
  ImmuneRecruitActivate = immune_recruit_activate,
  MyeloidRecruitInstruction = complement_production_mouse
)

## =========================
## 2. 检查基因是否存在
## =========================
check_signatures <- function(obj, sig_list) {
  all_genes <- rownames(obj)

  present <- lapply(sig_list, function(gs) intersect(gs, all_genes))
  missing <- lapply(names(sig_list), function(nm) setdiff(sig_list[[nm]], all_genes))
  names(missing) <- names(sig_list)

  cat("===== Present genes =====\n")
  print(present)
  cat("\n===== Missing genes =====\n")
  print(missing)

  present <- present[sapply(present, length) >= 3]

  list(present = present, missing = missing)
}

sig_checked <- check_signatures(fib3_obj, sig_list_raw)
sig_list <- sig_checked$present

## =========================
## 3. UCell
## =========================
fib3_obj <- AddModuleScore_UCell(
  obj = fib3_obj,
  features = sig_list,
  assay = "RNA",
  slot = "counts",
  name = "_UCell",
  ncores = 1
)

## =========================
## 4. AddModuleScore
## =========================
for (nm in names(sig_list)) {
  fib3_obj <- AddModuleScore(
    object = fib3_obj,
    features = list(sig_list[[nm]]),
    assay = "RNA",
    slot = "data",
    name = paste0(nm, "_AMS"),
    seed = 1,
    search = FALSE
  )
}

## =========================
## 5. 提取数据
## =========================
score_cols <- c(
  cluster_col,
  day_col,
  "ImmuneRecruitActivate_UCell",
  "complement_production_mouse_UCell",
  "ImmuneRecruitActivate_AMS1",
  "complement_production_mouse_AMS1"
)

plot_df <- FetchData(fib3_obj, vars = score_cols)
colnames(plot_df)[1:2] <- c("cluster", "day")

plot_df <- plot_df %>%
  mutate(
    cluster = factor(as.character(cluster), levels = target_clusters),
    day = factor(as.character(day), levels = target_days)
  ) %>%
  filter(!is.na(cluster), !is.na(day)) %>%
  mutate(
    day_label = factor(as.character(day), levels = target_days),
    day_key = factor(gsub("\\s+", "", as.character(day)), levels = names(day_color_map))
  )

## =========================
## 6. 绘图函数
## =========================
calc_plot_limits <- function(values) {
  values <- values[is.finite(values)]
  if (length(values) == 0) {
    return(list(ylim = c(0, 1), label_y = c(0.7, 0.8, 0.9, 1.0)))
  }

  y_min <- min(values)
  y_max <- max(values)
  y_span <- y_max - y_min

  if (y_span == 0) {
    y_span <- max(abs(y_max), 1) * 0.2
    y_min <- y_min - y_span
    y_max <- y_max + y_span
  }

  padding <- max(y_span * 0.08, 0.02)
  label_y <- y_max + seq(padding, by = padding, length.out = length(day_comparisons))
  ylim <- c(y_min, y_max + padding * (length(day_comparisons) + 1.5))

  list(ylim = ylim, label_y = label_y)
}

make_score_plot <- function(data, score_col, y_lab, title_text, limits_info) {
  ggplot(
    data,
    aes(x = day_label, y = .data[[score_col]], fill = day_key)
  ) +
    geom_boxplot(
      outlier.shape = NA,
      width = 0.62,
      linewidth = 0.55,
      alpha = 0.8,
      color = "black"
    ) +
    stat_compare_means(
      comparisons = day_comparisons,
      method = "wilcox.test",
      method.args = list(exact = FALSE),
      label = "p.signif",
      label.y = limits_info$label_y,
      size = 4
    ) +
    facet_wrap(~cluster, nrow = 1, scales = "fixed") +
    scale_fill_manual(values = day_color_map, labels = day_label_map, drop = FALSE) +
    coord_cartesian(ylim = limits_info$ylim, clip = "off") +
    labs(
      x = NULL,
      y = y_lab,
      title = title_text
    ) +
    theme_classic(base_size = 13) +
    theme(
      legend.position = "none",
      axis.text.x = element_text(color = "black"),
      axis.text.y = element_text(color = "black"),
      axis.title = element_text(color = "black"),
      plot.title = element_text(hjust = 0.5, face = "bold"),
      strip.background = element_rect(fill = "white", color = "black", linewidth = 0.8),
      strip.text = element_text(color = "black", face = "bold"),
      panel.border = element_rect(color = "black", fill = NA, linewidth = 0.8),
      axis.line = element_line(color = "black", linewidth = 0.6),
      panel.spacing = grid::unit(0.8, "lines"),
      plot.margin = margin(10, 14, 10, 10)
    )
}

save_plot_safely <- function(filename, plot_obj, width, height) {
  tryCatch(
    ggsave(filename, plot_obj, width = width, height = height),
    error = function(e) {
      file_info <- tools::file_path_sans_ext(filename)
      ext <- tools::file_ext(filename)
      fallback_file <- paste0(file_info, "_updated.", ext)
      ggsave(fallback_file, plot_obj, width = width, height = height)
      message("无法覆盖 ", filename, "，已改存为 ", fallback_file)
    }
  )
}

## =========================
## 7. UCell
## =========================
ucell_limits <- calc_plot_limits(c(
  plot_df$ImmuneRecruitActivate_UCell,
  plot_df$MyeloidRecruitInstruction_UCell
))

p1 <- make_score_plot(
  data = plot_df,
  score_col = "ImmuneRecruitActivate_UCell",
  y_lab = "UCell score",
  title_text = "Immune recruitment + activation score",
  limits_info = ucell_limits
)

p2 <- make_score_plot(
  data = plot_df,
  score_col = "MyeloidRecruitInstruction_UCell",
  y_lab = "UCell score",
  title_text = "Myeloid recruitment / instruction score",
  limits_info = ucell_limits
)

p_ucell <- p1 + p2
save_plot_safely("Fibro3_UCell_scores.pdf", p_ucell, width = 15.5, height = 4.2)

## =========================
## 8. AddModuleScore
## =========================
ams_limits <- calc_plot_limits(c(
  plot_df$ImmuneRecruitActivate_AMS1,
  plot_df$MyeloidRecruitInstruction_AMS1
))

p3 <- make_score_plot(
  data = plot_df,
  score_col = "ImmuneRecruitActivate_AMS1",
  y_lab = "AddModuleScore",
  title_text = "Immune recruitment + activation score (validation)",
  limits_info = ams_limits
)

p4 <- make_score_plot(
  data = plot_df,
  score_col = "MyeloidRecruitInstruction_AMS1",
  y_lab = "AddModuleScore",
  title_text = "Myeloid recruitment / instruction score (validation)",
  limits_info = ams_limits
)

p_ams <- p3 + p4
save_plot_safely("Fibro3_AddModuleScore_scores.pdf", p_ams, width = 15.5, height = 4.2)


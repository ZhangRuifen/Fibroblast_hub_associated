cellchat_d0 <- readRDS("./cellchat_d0.rds")
cellchat_d1 <- readRDS("./cellchat_d1.rds")
cellchat_d3 <- readRDS("./cellchat_d3.rds")
cellchat_d5 <- readRDS("./cellchat_d5.rds")

# population = TRUE
object.list <- list(d0 = cellchat_d0, d1 = cellchat_d1,d3 = cellchat_d3, d5 = cellchat_d5)

pdf('Fibroblast_outgoing.pdf', width = 16,height = 4)
weight.max <- getMaxWeight(object.list, attribute = c("idents","count"))
par(mfrow = c(1,5), xpd=TRUE)
for (i in 1:length(object.list)) {
  groupSize <- as.numeric(table(object.list[[i]]@idents))
  netVisual_circle(object.list[[i]]@net$weight, weight.scale = T, #label.edge= T, 
                   vertex.weight = groupSize, arrow.size = 1,
                   title.name = paste0("Interaction weights/strength - ", names(object.list)[i])
                   ,sources.use = 'Fibroblast'
                   )
}
dev.off()

get_fibro_outgoing_prop <- function(weight_mat, sender = "Fibroblast") {
  v <- weight_mat[sender, ] 
  v <- v[names(v) != sender]   
  
  total <- sum(v)  
  if (total == 0) {
    return(rep(NA, length(v)))
  }
  
  prop <- v / total  
  return(prop)
}

weight_d0<-cellchat_d0@net$weight
weight_d1<-cellchat_d1@net$weight
weight_d3<-cellchat_d3@net$weight
weight_d5<-cellchat_d5@net$weight


prop_d0 <- get_fibro_outgoing_prop(weight_d0)
prop_d1 <- get_fibro_outgoing_prop(weight_d1)
prop_d3 <- get_fibro_outgoing_prop(weight_d3)
prop_d5 <- get_fibro_outgoing_prop(weight_d5)


df_prop <- data.frame(
  celltype = names(prop_d0),
  d0 = prop_d0,
  d1 = prop_d1,
  d3 = prop_d3,
  d5 = prop_d5,
  row.names = NULL
)

library(dplyr)
library(tidyr)
library(ggplot2)

df_diff <- df_prop %>%
  mutate(
    d1_vs_d0 = d1 - d0,
    d3_vs_d0 = d3 - d0,
    d5_vs_d0 = d5 - d0
  )
df_diff

colnames(df_diff)
df_diff_long <- df_diff %>%
  dplyr::select(celltype, d1_vs_d0, d3_vs_d0, d5_vs_d0) %>%
  tidyr::pivot_longer(
    cols = -celltype,
    names_to = "day", 
    values_to = "diff"  
  )

df_diff_long$day <- factor(
  df_diff_long$day,
  levels = c("d1_vs_d0", "d3_vs_d0", "d5_vs_d0"),
  labels = c("day 1 - day 0", "day 3 - day 0", "day 5 - day 0")
)

df_diff_long

cell_order <- df_diff_long %>%
  group_by(celltype) %>%
  summarise(max_abs_diff = max(abs(diff), na.rm = TRUE), .groups = "drop") %>%
  arrange(desc(max_abs_diff)) %>%
  pull(celltype)

df_diff_long$celltype <- factor(df_diff_long$celltype, levels = cell_order)

day_colors <- c(
  "day 1 - day 0" = "#ffca3a",
  "day 3 - day 0" = "#8ac926",
  "day 5 - day 0" = "#1982c4"
)

p_diff <- ggplot(df_diff_long, aes(x = celltype, y = diff, fill = day)) +
  geom_col(
    position = position_dodge(width = 0.8),
    width = 0.7,
    color = "black",
    linewidth = 0.15
  ) +
  geom_hline(yintercept = 0, linetype = "dashed", color = "black", linewidth = 0.4) +
  scale_fill_manual(values = day_colors) +
  theme_classic(base_size = 13) +
  labs(
    x = NULL,
    y = "Change in proportion of outgoing communication\n(relative to day 0)",
    fill = "Day",
    title = "Redistribution of Fibroblast outgoing communication after infection"
  ) +
  theme(
    axis.text.x = element_text(angle = 35, hjust = 1, size = 10),
    axis.text.y = element_text(size = 11),
    axis.title.y = element_text(size = 12),
    legend.title = element_text(size = 11),
    legend.text = element_text(size = 10)
  )

p_diff
ggsave(p_diff,file = 'Fibroblast_outgoing.pdf',width = 8,height = 4)











#!/usr/bin/env Rscript

suppressPackageStartupMessages({
  library(ggplot2)
})

target_cell <- "Macrophage"
fibro_senders <- c(
  "Fibroblast1",
  "Fibroblast2",
  "Fibroblast3",
  "Myfibroblast",
  "Pericyte",
  "Telocyte",
  "Trophocyte1",
  "Trophocyte2"
)
pathway_groups <- list(
  Chemokine = c("CCL", "CXCL", "CHEMERIN"),
  Inflammation = c("TNF", "IL1", "IL6", "OSM", "MIF", "CSF", "BAFF", "TWEAK", "Prostaglandin", "CysLTs"),
  Complement = c("COMPLEMENT")
)
selected_pathways <- unique(unlist(pathway_groups, use.names = FALSE))
output_dir <- "output"

if (!dir.exists(output_dir)) {
  dir.create(output_dir, recursive = TRUE)
}

extract_day_label <- function(path) {
  file_name <- basename(path)
  hit <- regmatches(file_name, regexpr("day[[:space:]]*[0-9]+", file_name, ignore.case = TRUE))
  if (length(hit) == 0 || identical(hit, character(0)) || hit == "") {
    return(tools::file_path_sans_ext(file_name))
  }
  day_num <- regmatches(hit, regexpr("[0-9]+", hit))
  paste("Day", day_num)
}

extract_day_number <- function(label) {
  num <- regmatches(label, regexpr("[0-9]+", label))
  if (length(num) == 0 || identical(num, character(0)) || num == "") {
    return(Inf)
  }
  as.numeric(num)
}

extract_pathway_prob_array <- function(cellchat_obj, file) {
  if (!isS4(cellchat_obj) || !"net" %in% slotNames(cellchat_obj)) {
    stop("RDS is not a CellChat-like S4 object with a net slot: ", file)
  }
  if (!"netP" %in% slotNames(cellchat_obj)) {
    stop("RDS is not a CellChat-like S4 object with a netP slot: ", file)
  }

  netP <- slot(cellchat_obj, "netP")
  if (!"prob" %in% names(netP)) {
    stop("CellChat netP slot does not contain a pathway probability array: ", file)
  }

  prob <- netP$prob
  if (is.null(dim(prob)) || length(dim(prob)) != 3) {
    stop("CellChat netP$prob is not a 3D sender x receiver x pathway array: ", file)
  }
  prob_dimnames <- dimnames(prob)
  if (is.null(prob_dimnames[[1]]) || is.null(prob_dimnames[[2]]) || is.null(prob_dimnames[[3]])) {
    stop("CellChat netP$prob must have sender, receiver, and pathway names: ", file)
  }

  prob
}

rds_files <- list.files(pattern = "[.]rds$", ignore.case = TRUE, full.names = TRUE)
rds_files <- rds_files[grepl("CellChat", basename(rds_files), ignore.case = TRUE)]

if (length(rds_files) == 0) {
  stop("No CellChat RDS files found in the working directory.")
}

day_labels <- vapply(rds_files, extract_day_label, character(1))
file_order <- order(vapply(day_labels, extract_day_number, numeric(1)), day_labels)
rds_files <- rds_files[file_order]
day_labels <- day_labels[file_order]
keep_days <- vapply(day_labels, extract_day_number, numeric(1)) != 7
rds_files <- rds_files[keep_days]
day_labels <- day_labels[keep_days]

pathway_arrays <- lapply(rds_files, function(file) {
  obj <- readRDS(file)
  extract_pathway_prob_array(obj, file)
})

source_by_file <- lapply(pathway_arrays, function(prob) {
  prob_dimnames <- dimnames(prob)
  target_matches <- prob_dimnames[[2]] == target_cell
  if (!any(target_matches)) {
    target_matches <- grepl("Macro", prob_dimnames[[2]], ignore.case = TRUE)
  }
  if (sum(target_matches) != 1) {
    stop("Could not uniquely identify target macrophage column in one matrix. Columns: ",
         paste(prob_dimnames[[2]], collapse = ", "))
  }
  setdiff(prob_dimnames[[1]], prob_dimnames[[2]][target_matches])
})

available_sources <- unique(unlist(source_by_file, use.names = FALSE))
missing_requested <- setdiff(fibro_senders, available_sources)
if (length(missing_requested) > 0) {
  warning("Requested sender(s) not found in any CellChat object: ",
          paste(missing_requested, collapse = ", "))
}

source_order <- fibro_senders
strength_matrix <- matrix(
  NA_real_,
  nrow = length(source_order),
  ncol = length(day_labels),
  dimnames = list(source_order, day_labels)
)

selected_pathways_by_day <- vector("list", length(pathway_arrays))
names(selected_pathways_by_day) <- day_labels

for (i in seq_along(pathway_arrays)) {
  prob <- pathway_arrays[[i]]
  prob_dimnames <- dimnames(prob)
  target_name <- prob_dimnames[[2]][prob_dimnames[[2]] == target_cell]
  if (length(target_name) == 0) {
    target_name <- prob_dimnames[[2]][grepl("Macro", prob_dimnames[[2]], ignore.case = TRUE)]
  }

  present_pathways <- intersect(selected_pathways, prob_dimnames[[3]])
  selected_pathways_by_day[[i]] <- present_pathways
  if (length(present_pathways) == 0) {
    next
  }

  sources <- intersect(source_order, prob_dimnames[[1]])
  sources <- setdiff(sources, target_name)
  pathway_signal <- prob[sources, target_name[1], present_pathways, drop = FALSE]
  strength_matrix[sources, day_labels[i]] <- rowSums(pathway_signal, na.rm = TRUE)
}

wide_table <- data.frame(Fibroblast_subtype = rownames(strength_matrix), strength_matrix, check.names = FALSE)
write.csv(wide_table, file.path(output_dir, "fibroblast_to_macrophage_strength_wide.csv"), row.names = FALSE)

long_table <- data.frame(
  Fibroblast_subtype = rep(rownames(strength_matrix), times = ncol(strength_matrix)),
  Day = rep(colnames(strength_matrix), each = nrow(strength_matrix)),
  Strength = as.vector(strength_matrix),
  stringsAsFactors = FALSE
)
long_table$Fibroblast_subtype <- factor(long_table$Fibroblast_subtype, levels = rev(fibro_senders))
long_table$Day <- factor(long_table$Day, levels = colnames(strength_matrix))
write.csv(long_table, file.path(output_dir, "fibroblast_to_macrophage_strength_long.csv"), row.names = FALSE)

selected_pathway_table <- do.call(rbind, lapply(names(pathway_groups), function(group_name) {
  data.frame(
    Functional_group = group_name,
    Pathway = pathway_groups[[group_name]],
    stringsAsFactors = FALSE
  )
}))
selected_pathway_table$Detected_in_days <- vapply(selected_pathway_table$Pathway, function(pathway) {
  detected_days <- names(selected_pathways_by_day)[vapply(selected_pathways_by_day, function(day_pathways) {
    pathway %in% day_pathways
  }, logical(1))]
  paste(detected_days, collapse = ";")
}, character(1))
write.csv(selected_pathway_table, file.path(output_dir, "selected_functional_pathways.csv"), row.names = FALSE)

plot_width <- 4.8
plot_height <- 4.6
finite_strength <- long_table$Strength[is.finite(long_table$Strength)]

baseline_strength <- strength_matrix[, baseline_day]
baseline_strength[is.na(baseline_strength)] <- 0
difference_matrix <- sweep(strength_matrix[, post_days, drop = FALSE], 1, baseline_strength, "-")
difference_wide_table <- data.frame(Fibroblast_subtype = rownames(difference_matrix), difference_matrix, check.names = FALSE)
write.csv(difference_wide_table, file.path(output_dir, "fibroblast_to_macrophage_strength_difference_vs_day0_wide.csv"), row.names = FALSE)

difference_long_table <- data.frame(
  Fibroblast_subtype = rep(rownames(difference_matrix), times = ncol(difference_matrix)),
  Day = rep(colnames(difference_matrix), each = nrow(difference_matrix)),
  Difference = as.vector(difference_matrix),
  stringsAsFactors = FALSE
)
difference_long_table$Fibroblast_subtype <- factor(difference_long_table$Fibroblast_subtype, levels = rev(fibro_senders))
difference_long_table$Day <- factor(difference_long_table$Day, levels = colnames(difference_matrix))

difference_plot <- ggplot(difference_long_table, aes(x = Day, y = Fibroblast_subtype, fill = Difference)) +
  geom_tile(color = "#f0f0f0", linewidth = 0.25) +
  scale_fill_gradientn(
    colours = colorRampPalette(c("#2166AC", "white", "#B2182B"))(100),
    limits = c(-max(abs(difference_long_table$Difference), na.rm = TRUE),
               max(abs(difference_long_table$Difference), na.rm = TRUE)),
    na.value = "#d9d9d9",
    name = "Delta\nstrength"
  ) +
  labs(
    title = NULL,
    x = NULL,
    y = NULL
  ) +
  theme_classic(base_size = 8, base_family = "Arial") +
  theme(
    axis.line = element_blank(),
    axis.ticks = element_blank(),
    axis.text = element_text(color = "black"),
    axis.text.x = element_text(angle = 45, hjust = 1, vjust = 1, size = 8),
    axis.text.y = element_text(size = 8),
    legend.title = element_text(size = 8),
    legend.text = element_text(size = 7),
    legend.key.height = unit(0.45, "cm"),
    legend.key.width = unit(0.2, "cm"),
    plot.margin = margin(4, 4, 4, 4),
    panel.grid = element_blank(),
    plot.background = element_rect(fill = "white", color = NA)
  )

ggsave(file.path(output_dir, "fibroblast_to_macrophage_strength_difference_vs_day0_heatmap.pdf"), difference_plot,
       width = plot_width, height = plot_height, device = cairo_pdf)

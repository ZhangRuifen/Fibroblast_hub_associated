#### 20260401 统计fibroblast向CC1,CC2,Macrophage发出了什么信号？ ####

library(CellChat)
library(dplyr)
library(tidyr)
library(ggplot2)
library(pheatmap)
library(stringr)
library(forcats)
library(scales)

cellchat_d0 <- readRDS("./cellchat_d0.rds")
cellchat_d1 <- readRDS("./cellchat_d1.rds")
cellchat_d3 <- readRDS("./cellchat_d3.rds")
cellchat_d5 <- readRDS("./cellchat_d5.rds")
cellchat_d7 <- readRDS("./cellchat_d7.rds")

# population = TRUE
cellchat_list <- list(
  d0 = cellchat_d0,
  d1 = cellchat_d1,
  d3 = cellchat_d3,
  d5 = cellchat_d5,
  d7 = cellchat_d7
)
cellchat <- mergeCellChat(cellchat_list, add.names = names(cellchat_list))
cellchat

cell_colors_fill <- c(
  "day 0" = "#ff595e",
  "day 1" = "#ffca3a",
  "day 3" = "#8ac926",
  "day 5" = "#1982c4",
  "day 7" = "#6a4c93"
)

levels(cellchat_d0@idents)

extract_outgoing_from_sender <- function(cellchat_obj, day, sender = "Fibroblast",
                                         targets = c("CC_1", "CC_2", "Macrophage"),
                                         p_thresh = 0.05) {
  df <- subsetCommunication(
    object = cellchat_obj,
    sources.use = sender,
    targets.use = targets,
    thresh = p_thresh
  )
  
  if (is.null(df) || nrow(df) == 0) {
    return(data.frame(
      source = character(),
      target = character(),
      ligand = character(),
      receptor = character(),
      interaction_name = character(),
      interaction_name_2 = character(),
      pathway_name = character(),
      prob = numeric(),
      pval = numeric(),
      day = character(),
      stringsAsFactors = FALSE
    ))
  }
  
  df$day <- day
  return(df)
}

comm_out_all <- bind_rows(
  lapply(names(cellchat_list), function(day) {
    extract_outgoing_from_sender(
      cellchat_obj = cellchat_list[[day]],
      day = day,
      sender = "Fibroblast",
      targets = c("CC_1", "CC_2", "Macrophage"),
      p_thresh = 0.05
    )
  })
)
unique(comm_out_all$target)

comm_out_all$day <- factor(
  comm_out_all$day,
  levels = c("d0", "d1", "d3", "d5", "d7"),
  labels = c("day 0", "day 1", "day 3", "day 5", "day 7")
)

colnames(comm_out_all)
head(comm_out_all[, c("source", "target", "interaction_name_2", "pathway_name", "prob", "day")])

pathway_all_df <- comm_out_all %>%
  group_by(target, day, pathway_name) %>%
  summarise(prob_sum = sum(prob, na.rm = TRUE), .groups = "drop")

pathways_for_heatmap <- c(
  # ECM / adhesion
  "COLLAGEN", "LAMININ", "FN1", "THBS", "TENASCIN",
  
  # inflammatory / immune
  "APP", "COMPLEMENT", "MIF", "GALECTIN", "CCL", "CXCL", "ICAM",
  
  # growth / regeneration
  "BMP", "IGF", "WNT", #"TGFb", "EGF",
  
  # stromal support / survival
  "GAS", "ANGPTL"
)

pathway_heat_df <- pathway_all_df %>%
  filter(pathway_name %in% pathways_for_heatmap)

pathway_heat_mat_df <- pathway_heat_df %>%
  mutate(col_id = paste(target, day, sep = "_")) %>%
  dplyr::select(pathway_name, col_id, prob_sum) %>%
  pivot_wider(names_from = col_id, values_from = prob_sum, values_fill = 0)

pathway_heat_mat <- as.data.frame(pathway_heat_mat_df)
rownames(pathway_heat_mat) <- pathway_heat_mat$pathway_name
pathway_heat_mat$pathway_name <- NULL
pathway_heat_mat <- as.matrix(pathway_heat_mat)

desired_cols_all <- c(
  "CC_1_day 0", "CC_1_day 1", "CC_1_day 3", "CC_1_day 5", "CC_1_day 7",
  "CC_2_day 0", "CC_2_day 1", "CC_2_day 3", "CC_2_day 5", "CC_2_day 7",
  "Macrophage_day 0", "Macrophage_day 1", "Macrophage_day 3", "Macrophage_day 5", "Macrophage_day 7"
)
desired_cols_all <- desired_cols_all[desired_cols_all %in% colnames(pathway_heat_mat)]
pathway_heat_mat <- pathway_heat_mat[, desired_cols_all, drop = FALSE]

pathway_order <- c(
  "COLLAGEN", "LAMININ", "FN1", "THBS", "TENASCIN",
  "BMP", "IGF", "WNT", #"TGFb", "EGF",
  "GAS", "ANGPTL",
  "APP", "COMPLEMENT", "MIF", "GALECTIN", "CCL", "CXCL","ICAM"
)

pathway_order <- pathway_order[pathway_order %in% rownames(pathway_heat_mat)]
pathway_heat_mat <- pathway_heat_mat[pathway_order, , drop = FALSE]

annotation_col <- data.frame(
  Target = c(
    rep("CC_1", 5),
    rep("CC_2", 5),
    rep("Macrophage", 5)
  ),
  Day = rep(c("day 0", "day 1", "day 3", "day 5", "day 7"), 3)
)

rownames(annotation_col) <- colnames(pathway_heat_mat)

annotation_colors <- list(
  Target = c(
    "CC_1" = "#FF7F00", 
    "CC_2" = "#FB9A99", 
    "Macrophage" = "#6A3D9A"
  ),
  Day = c(
    "day 0" = "#ff595e",
    "day 1" = "#ffca3a",
    "day 3" = "#8ac926",
    "day 5" = "#1982c4",
    "day 7" = "#6a4c93"
  )
)

p<-pheatmap(
  pathway_heat_mat,
  scale = "row",
  cluster_rows = FALSE,
  cluster_cols = FALSE,
  annotation_col = annotation_col,
  annotation_colors = annotation_colors,
  border_color = NA,
  color = colorRampPalette(c("#2166AC", "white", "#B2182B"))(100),
  fontsize_row = 11,
  fontsize_col = 9,
  angle_col = 45,
  main = "Fibroblast outgoing signaling to DCC, PCC and Macrophage"
)
p
ggsave(p,file = 'Heatmap_传入.scale.pdf',width = 7,height = 5)

##### 2.绘制所有pathway的分组barplot图 ---------------------------------------
# 输出一个总图：展示Fibroblast到CC1,CC2,Macrophage的功能模块变化
# 每个靶细胞一个小面板
# 1）定义功能分类
pathway_category_map_all <- c(
  # ---------------------------
  # 1. ECM remodeling / adhesion
  # ---------------------------
  "COLLAGEN"  = "ECM_Remodeling_Adhesion",
  "LAMININ"   = "ECM_Remodeling_Adhesion",
  "FN1"       = "ECM_Remodeling_Adhesion",
  "THBS"      = "ECM_Remodeling_Adhesion",
  "TENASCIN"  = "ECM_Remodeling_Adhesion",
  "HSPG"      = "ECM_Remodeling_Adhesion",
  "PERIOSTIN" = "ECM_Remodeling_Adhesion",
  "ICAM"      = "ECM_Remodeling_Adhesion",
  "JAM"       = "ECM_Remodeling_Adhesion",
  "NECTIN"    = "ECM_Remodeling_Adhesion",
  "NCAM"      = "ECM_Remodeling_Adhesion",
  "EPHA"      = "ECM_Remodeling_Adhesion",
  
  # ---------------------------
  # 2. Inflammatory / immune activation
  # ---------------------------
  "APP"        = "Inflammatory_Immune_Activation",
  "COMPLEMENT" = "Inflammatory_Immune_Activation",
  "MIF"        = "Inflammatory_Immune_Activation",
  "GALECTIN"   = "Inflammatory_Immune_Activation",
  "GRN"        = "Inflammatory_Immune_Activation",
  "ANNEXIN"    = "Inflammatory_Immune_Activation",
  "CSF"        = "Inflammatory_Immune_Activation",
  "CHEMERIN"   = "Inflammatory_Immune_Activation",
  "TWEAK"      = "Inflammatory_Immune_Activation",
  "BAFF"       = "Inflammatory_Immune_Activation",
  "CCL"        = "Inflammatory_Immune_Activation",
  "CXCL"       = "Inflammatory_Immune_Activation",
  
  # ---------------------------
  # 3. Growth / regeneration
  # ---------------------------
  "BMP"   = "Growth_Regeneration",
  "IGF"   = "Growth_Regeneration",
  "WNT"   = "Growth_Regeneration",
  "ncWNT" = "Growth_Regeneration",
  "TGFb"  = "Growth_Regeneration",
  "EGF"   = "Growth_Regeneration",
  "MK"    = "Growth_Regeneration",
  
  # ---------------------------
  # 4. Stromal survival / metabolic support
  # ---------------------------
  "ANGPTL"   = "Stromal_Survival_Metabolic",
  "GAS"      = "Stromal_Survival_Metabolic",
  "PROS"     = "Stromal_Survival_Metabolic",
  "VISFATIN" = "Stromal_Survival_Metabolic",
  
  # ---------------------------
  # 5. Epithelial homeostasis / secreted regulation
  # ---------------------------
  "GUCA" = "Epithelial_Homeostasis_Secreted"
)

category_all_df <- pathway_all_df %>%
  mutate(category = pathway_category_map_all[pathway_name])

category_all_df %>%
  filter(is.na(category)) %>%
  distinct(pathway_name) %>%
  arrange(pathway_name)

category_all_df <- category_all_df %>%
  filter(!is.na(category)) %>%
  group_by(target, day, category) %>%
  summarise(prob_sum = sum(prob_sum, na.rm = TRUE), .groups = "drop")

category_all_df$target <- factor(
  category_all_df$target,
  levels = c("CC_1", "CC_2", "Macrophage")
)

category_all_df$day <- factor(
  category_all_df$day,
  levels = c("day 0", "day 1", "day 3", "day 5", "day 7")
)

category_all_df$category <- factor(
  category_all_df$category,
  levels = c(
    "Inflammatory_Immune_Activation",
    "Growth_Regeneration",
    "ECM_Remodeling_Adhesion",
    "Stromal_Survival_Metabolic",
    "Epithelial_Homeostasis_Secreted"
  )
)

category_all_df$category_label <- recode(
  category_all_df$category,
  "Inflammatory_Immune_Activation" = "Inflammatory /\nImmune activation",
  "Growth_Regeneration" = "Growth /\nRegeneration",
  "ECM_Remodeling_Adhesion" = "ECM remodeling /\nAdhesion",
  "Stromal_Survival_Metabolic" = "Stromal survival /\nMetabolic",
  "Epithelial_Homeostasis_Secreted" = "Epithelial homeostasis /\nSecreted"
)

category_all_df$category_label <- factor(
  category_all_df$category_label,
  levels = c(
    "Inflammatory /\nImmune activation",
    "Growth /\nRegeneration",
    "ECM remodeling /\nAdhesion",
    "Stromal survival /\nMetabolic",
    "Epithelial homeostasis /\nSecreted"
  )
)

cell_colors_fill <- c(
  "day 0" = "#ff595e",
  "day 1" = "#ffca3a",
  "day 3" = "#8ac926",
  "day 5" = "#1982c4",
  "day 7" = "#6a4c93"
)

pairLR.use <- extractEnrichedLR(cellchat_d1, signaling = c("ncWNT","WNT","TENASCIN","THBS","MK",
                                                           "GALECTIN","LAMININ","ICAM","FN1","BMP",
                                                           "COLLAGEN","CSF","CCL","CXCL","COMPLEMENT"))
pairLR.use1<-pairLR.use[c(43,41,186,182,194,189,212,
                          4,9,12,15,17,25,32,36,92,76,52,93,100,108,168,177,141,173,137),] %>% as.data.frame()
colnames(pairLR.use1)<-colnames(pairLR.use)

pdf('bubble.pdf',width = 6,height = 5)
netVisual_bubble(cellchat, 
                 sources.use = 'Fibroblast', targets.use = c('DCC','PCC','Macrophage'),  
                 comparison = c(1,2,3,4,5),
                 max.dataset = 2,
                 pairLR.use = pairLR.use1, 
                 title.name = "Increased signaling in d1",angle.x = 45,
                 remove.isolate = TRUE)
dev.off()






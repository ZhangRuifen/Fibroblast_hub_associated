library(CellChat)
library(dplyr)
library(tidyr)
library(ggplot2)
library(forcats)
library(stringr)
library(scales)

# 1）读取合并的CellChat对象
cellchat_d0 <- readRDS("./day 0_CellChat.rds")
cellchat_d1 <- readRDS("./day 1_CellChat.rds")
cellchat_d3 <- readRDS("./day 3_CellChat.rds")
cellchat_d5 <- readRDS("./day 5_CellChat.rds")
cellchat_d7 <- readRDS("./day 7_CellChat.rds")

cellchat_sub_list <- list(d0 = cellchat_d0, d1 = cellchat_d1,d3 = cellchat_d3, d5 = cellchat_d5)
cellchat <- mergeCellChat(cellchat_sub_list, add.names = names(cellchat_sub_list))
cellchat

fibro_subtypes <- c('Fibroblast1','Fibroblast2','Trophocyte1')

macro_subtypes <- c('Mac_Irf7', 'Mac_Klf2', 'Mac_Cd14', 'Mac_Cd163', 'Mono_Ly6c2', 'Mono_Ccr2','Mono_Lcn2')

day_levels <- c("d0", "d1", "d3", "d5")
day_labels <- c("day 0", "day 1", "day 3", "day 5")

extract_fibro_to_macro_comm <- function(cellchat_obj, day,
                                        fibro_subtypes,
                                        macro_subtypes,
                                        p_thresh = 0.05) {
  df <- subsetCommunication(
    object = cellchat_obj,
    sources.use = fibro_subtypes,
    targets.use = macro_subtypes,
    thresh = p_thresh
  )
  
  if (is.null(df) || nrow(df) == 0) {
    return(data.frame(
      source = character(),
      target = character(),
      interaction_name = character(),
      interaction_name_2 = character(),
      pathway_name = character(),
      prob = numeric(),
      pval = numeric(),
      day = character(),
      stringsAsFactors = FALSE
    ))
  }
  
  df$day <- day
  return(df)
}

comm_fibro_macro <- bind_rows(
  lapply(names(cellchat_sub_list), function(day) {
    extract_fibro_to_macro_comm(
      cellchat_obj = cellchat_sub_list[[day]],
      day = day,
      fibro_subtypes = fibro_subtypes,
      macro_subtypes = macro_subtypes,
      p_thresh = 0.05
    )
  })
)

comm_fibro_macro$day <- factor(comm_fibro_macro$day, levels = day_levels, labels = day_labels)
comm_fibro_macro$source <- factor(comm_fibro_macro$source, levels = fibro_subtypes)
comm_fibro_macro$target <- factor(comm_fibro_macro$target, levels = macro_subtypes)

head(comm_fibro_macro[, c("source", "target", "interaction_name_2", "pathway_name", "prob", "day")])

pair_df <- comm_fibro_macro %>%
  group_by(day, source, target) %>%
  summarise(
    prob_sum = sum(prob, na.rm = TRUE),
    pair_n = n_distinct(interaction_name_2),
    .groups = "drop"
  ) %>%
  mutate(pair = paste(source, "->", target))

# 为了防止缺失组合在图里消失，补齐所有组合‘
pair_df <- pair_df %>%
  complete(
    day = factor(day_labels, levels = day_labels),
    source = factor(fibro_subtypes, levels = fibro_subtypes),
    target = factor(macro_subtypes, levels = macro_subtypes),
    fill = list(prob_sum = 0, pair_n = 0)
  ) %>%
  mutate(pair = paste(source, "->", target))

if (!requireNamespace("ggalluvial", quietly = TRUE)) {
  stop("Package 'ggalluvial' is required for the sankey plot. Please run install.packages('ggalluvial') first.")
}

fibro_colors <- c(
  "Fibroblast1" = "#f94144",
  "Fibroblast2" = "#f78c6b",
  "Fibroblast3" = "#ffd166",
  "Myfibroblast" = "#83d483",
  "Pericyte" = "#06d6a0",
  "Telocyte" = "#0cb0a9",
  "Trophocyte1" = "#118ab2",
  "Trophocyte2" = "#073b4c"
)

celltype_colors <- c(
  "Mac_Klf2" = "#bcbd22",
  "Mac_Cd14" = "#aec7e8",
  "Mac_Irf7" = "#ff9896",
  "Mac_Cd163" = "#98df8a",
  "Mono_Ccr2" = "#ffbb78",
  "Mono_Ly6c2" = "#c5b0d5",
  "Mono_Lcn2" = "#17becf"
)

sankey_day_labels <- c("day 0", "day 1", "day 3", "day 5")
lighten_color <- function(color, amount = 0.45) {
  rgb_vals <- grDevices::col2rgb(color)
  lighter_vals <- round(rgb_vals + (255 - rgb_vals) * amount)
  grDevices::rgb(
    lighter_vals[1],
    lighter_vals[2],
    lighter_vals[3],
    maxColorValue = 255
  )
}

flow_colors <- setNames(
  vapply(
    fibro_colors[intersect(names(fibro_colors), fibro_subtypes)],
    lighten_color,
    FUN.VALUE = character(1),
    amount = 0.45
  ),
  paste0("flow_", intersect(names(fibro_colors), fibro_subtypes))
)

legend_breaks <- c(fibro_subtypes, macro_subtypes)
combined_colors <- c(
  flow_colors,
  fibro_colors[intersect(names(fibro_colors), fibro_subtypes)],
  celltype_colors[intersect(names(celltype_colors), macro_subtypes)]
)
legend_labels <- c(
  paste0("Fibro: ", fibro_subtypes),
  paste0("Macro: ", macro_subtypes)
)

sankey_df <- pair_df %>%
  filter(day %in% sankey_day_labels) %>%
  filter(prob_sum > 0) %>%
  group_by(day) %>%
  mutate(
    prob_ratio = prob_sum / sum(prob_sum, na.rm = TRUE)
  ) %>%
  ungroup() %>%
  mutate(
    day = factor(day, levels = sankey_day_labels),
    source = factor(source, levels = fibro_subtypes),
    target = factor(target, levels = macro_subtypes),
    flow_group = paste0("flow_", as.character(source)),
    alluvium_id = dplyr::row_number()
  )

if (nrow(sankey_df) == 0) {
  stop("No fibroblast-to-macrophage communication passed the current filter, so the sankey plot cannot be drawn.")
}

sankey_lodes <- ggalluvial::to_lodes_form(
  data = sankey_df,
  axes = c("source", "target"),
  key = "x",
  value = "stratum",
  id = "alluvium_id"
) %>%
  mutate(
    x = factor(x, levels = c("source", "target")),
    stratum = factor(stratum, levels = c(fibro_subtypes, macro_subtypes)),
    node_group = dplyr::case_when(
      x == "source" ~ as.character(stratum),
      x == "target" ~ as.character(stratum),
      TRUE ~ NA_character_
    )
  )

p_Fig5A_sankey <- ggplot(
  sankey_lodes,
  aes(
    x = x,
    stratum = stratum,
    alluvium = alluvium_id,
    y = prob_ratio
  )
) +
  ggalluvial::geom_alluvium(
    aes(fill = flow_group),
    width = 0.22,
    alpha = 0.8,
    knot.pos = 0.35
  ) +
  ggalluvial::geom_stratum(
    data = dplyr::filter(sankey_lodes, x == "source"),
    aes(fill = node_group),
    width = 0.22,
    color = "grey55",
    linewidth = 0.3
  ) +
  ggalluvial::geom_stratum(
    data = dplyr::filter(sankey_lodes, x == "target"),
    aes(fill = node_group),
    width = 0.22,
    color = "grey55",
    linewidth = 0.3
  ) +
  facet_wrap(~day, nrow = 1) +
  scale_x_discrete(
    limits = c("source", "target"),
    labels = c("Fibroblast", "Macrophage"),
    expand = c(0.08, 0.08)
  ) +
  scale_y_continuous(
    labels = scales::percent_format(accuracy = 1),
    expand = c(0, 0)
  ) +
  scale_fill_manual(
    values = combined_colors,
    breaks = legend_breaks,
    labels = legend_labels,
    drop = FALSE,
    name = "Cell subtype"
  ) +
  guides(fill = guide_legend(override.aes = list(alpha = 1))) +
  labs(
    x = NULL,
    y = "Relative communication probability",
    title = "Fibroblast-to-macrophage communication Sankey across infection"
  ) +
  theme_classic(base_size = 13) +
  theme(
    axis.line.x = element_blank(),
    axis.ticks.x = element_blank(),
    axis.text.x = element_text(size = 11, face = "bold"),
    axis.text.y = element_text(size = 10),
    strip.text = element_text(size = 11, face = "bold"),
    legend.position = "right",
    legend.title = element_text(size = 10),
    legend.text = element_text(size = 9),
    legend.key.height = grid::unit(0.45, "cm"),
    legend.key.width = grid::unit(0.45, "cm")
  )

ggsave(
  filename = "Figure5A.Fibro_to_Macro.Sankey.d0_d1_d3_d5.legend.pdf",
  plot = p_Fig5A_sankey,
  width = 13,
  height = 4.5
)



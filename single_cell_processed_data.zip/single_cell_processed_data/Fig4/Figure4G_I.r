library(CellChat)
library(dplyr)
library(tidyr)
library(ggplot2)
library(forcats)
library(stringr)
library(scales)

cellchat_d0 <- readRDS("./day 0_CellChat.rds")
cellchat_d1 <- readRDS("./day 1_CellChat.rds")
cellchat_d3 <- readRDS("./day 3_CellChat.rds")
cellchat_d5 <- readRDS("./day 5_CellChat.rds")

cellchat_d0 <- updateCellChat(cellchat_d0)
cellchat_d1 <- updateCellChat(cellchat_d1)
cellchat_d3 <- updateCellChat(cellchat_d3)
cellchat_d5 <- updateCellChat(cellchat_d5)

cellchat_sub_list <- list(d0 = cellchat_d0, d1 = cellchat_d1,d3 = cellchat_d3, d5 = cellchat_d5)
cellchat <- mergeCellChat(cellchat_sub_list, add.names = names(cellchat_sub_list))
cellchat

day_levels <- c("d0", "d1", "d3", "d5")
day_labels <- c("day 0", "day 1", "day 3", "day 5")


#### 1.Define a general function--------------------------------------------------------
extract_selected_pairs_comm <- function(cellchat_list, pair_tbl, days_use, p_thresh = 0.05) {
  res <- bind_rows(
    lapply(days_use, function(day) {
      df <- subsetCommunication(
        object = cellchat_list[[day]],
        sources.use = unique(pair_tbl$source),
        targets.use = unique(pair_tbl$target),
        thresh = p_thresh
      )
      
      if (is.null(df) || nrow(df) == 0) return(NULL)
      
      if (!"interaction_name_2" %in% colnames(df)) {
        df$interaction_name_2 <- df$interaction_name
      }
      
      df$day <- day
      df
    })
  )
  
  if (is.null(res) || nrow(res) == 0) return(NULL)
  
  res <- res %>%
    inner_join(pair_tbl, by = c("source", "target")) %>%
    mutate(
      day = factor(day, levels = day_levels, labels = day_labels),
      pair = paste(source, "->", target)
    )
  
  return(res)
}

# 2.Define the general function: Create "heat map of variations"
make_lr_delta_heatmap <- function(
    comm_df,
    ref_days,  # reference
    cmp_days,  
    top_n_per_pair = 10,
    metric = c("delta", "log2FC"),
    title_text = NULL,
    pseudocount = 1e-4,
    output_prefix = NULL
) {
  metric <- match.arg(metric)
  
  df_sum <- comm_df %>%
    group_by(pair, interaction_name_2, day) %>%
    summarise(prob_sum = sum(prob, na.rm = TRUE), .groups = "drop")
  
  df_ref <- df_sum %>%
    filter(day %in% ref_days) %>%
    group_by(pair, interaction_name_2) %>%
    summarise(ref_prob = mean(prob_sum, na.rm = TRUE), .groups = "drop")
  
  df_cmp <- df_sum %>%
    filter(day %in% cmp_days) %>%
    group_by(pair, interaction_name_2) %>%
    summarise(cmp_prob = mean(prob_sum, na.rm = TRUE), .groups = "drop")
  
  df_merge <- full_join(df_ref, df_cmp, by = c("pair", "interaction_name_2"))
  df_merge$ref_prob[is.na(df_merge$ref_prob)] <- 0
  df_merge$cmp_prob[is.na(df_merge$cmp_prob)] <- 0

  df_merge <- df_merge %>%
    mutate(
      delta = cmp_prob - ref_prob,
      log2FC = log2((cmp_prob + pseudocount) / (ref_prob + pseudocount))
    )
  
  top_df <- df_merge %>%
    group_by(pair) %>%
    # slice_max(order_by = abs(.data[[metric]]), n = top_n_per_pair, with_ties = FALSE) %>%  # 绝对值最大，而不是变化最大
    slice_max(order_by = .data[[metric]], n = top_n_per_pair, with_ties = FALSE) %>%
    ungroup()
  
  plot_df <- top_df %>%
    select(pair, interaction_name_2, value = all_of(metric)) %>%
    distinct() %>%
    pivot_wider(names_from = pair, values_from = value, values_fill = 0)
  
  mat <- as.data.frame(plot_df)
  rownames(mat) <- mat$interaction_name_2
  mat$interaction_name_2 <- NULL
  mat <- as.matrix(mat)
  
  mat_scaled <- t(scale(t(mat)))
  mat_scaled[is.na(mat_scaled)] <- 0
  
  pheatmap(
    mat,
    scale = "row",  # 改为按行标准化
    cluster_rows = TRUE,
    cluster_cols = FALSE,
    border_color = NA,
    color = colorRampPalette(c("#2166AC", "white", "#B2182B"))(100),
    fontsize_row = 9,
    fontsize_col = 10,angle_col = 45,
    main = title_text
  )
  
  invisible(df_merge)
}


#### 2.Draw the early extracted LR ------------------------------------------------------
early_pair_tbl <- tibble::tribble(
  ~source,   ~target,
  "Fibroblast1",  "Mac_Irf7",
  "Fibroblast2",  "Mono_Ccr2",
  "Fibroblast2",  "Mac_Irf7",
  "Fibroblast1",  "Mono_Ccr2"
)

late_pair_tbl <- tibble::tribble(
  ~source,   ~target,
  "Trophocyte1",  "Mac_Klf2",
  "Trophocyte1",  "Mono_Lcn2",
  "Fibroblast1",  "Mac_Klf2",
  "Fibroblast1",  "Mono_Lcn2",
  "Fibroblast2",  "Mac_Klf2",
  "Fibroblast2",  "Mono_Lcn2"
)

if (!run_requested_only) {
  pdf("scale.row.Figure4G_Early_log2FC_heatmap.pdf", width = 5, height = 4.5)
  
  make_lr_delta_heatmap(
    comm_df = comm_early,
    ref_days = "day 0",
    cmp_days = "day 1",
    top_n_per_pair = 6,
    metric = "log2FC", output_prefix = 'Early',
    title_text = "Early Fibro-to-Macro LR changes (log2FC, day 1 vs day 0)"
  )
  
  dev.off()
}

pdf("scale.row.Figure4I_Late_log2FC_heatmap.pdf", width = 5, height = 4.5)

make_lr_delta_heatmap(
  comm_df = comm_late,
  ref_days = "day 0",
  cmp_days = "day 5",
  top_n_per_pair = 6,
  metric = "log2FC", output_prefix = 'Late',
  title_text = "Late Fibro-to-Macro LR changes (log2FC, day 5 vs day 0)"
)

dev.off()

library(ggpubr)
library(ggplot2)
library(cowplot)

Fibro2 <- subset(FFib,ident = 'Fibroblast2')
Idents(Fibro2)<-'day'
Fibro2.d01 <- subset(Fibro2,ident = c('day 0','day 1'))
plot_data <- FetchData(Fibro2.d01, vars = c('Cd44' ,"day"))
plot_data <- FetchData(DCC01, vars = c('Lgals9' ,"day"))
"day0" = "#1f77b4",  # 蓝色填充
"day1" = "#ff7f0e",  # 橙色填充
"day3" = "#d62728",  # 红色填充
"day5" = "#2ca02c",  # 绿色填充
"day7" = "#9467bd"   # 紫色填充

# p<-ggplot(plot_data, aes(x = day, y = Cd44, fill = day)) +
#   geom_violin(scale = "width", adjust = 1, trim = TRUE, alpha = 0.8) + # 添加了你需要的透明度
#   geom_boxplot(width = 0.1, color = "black", outlier.shape = NA, 
#                position = position_dodge(0.9)) + # 在小提琴内部添加窄箱线图，更专业
#   scale_fill_manual(values = c("day 0" = "#1f77b4", "day 1" = "#ff7f0e")) +
#   theme_classic() +
#   # 添加显著性检验：比较同一细胞群内的 day0 和 day1
#   stat_compare_means(aes(group = day), 
#                      label = "p.signif",        # 显示星号 (ns, *, **, ***)
#                      method = "wilcox.test",     # 单细胞常用的秩和检验
#                      label.y = max(plot_data$Cd44) * 1.1) + # 动态调整标签高度
#   theme(axis.text.x = element_text(angle = 45, hjust = 1)) +
#   labs(title = "Cd44: day0 vs day1", y = "Expression Level", x = "Cell Type") + ggtitle ('Fibroblast2')
# p
# ggsave(p,file = 'Fibro2_Cd44.pdf',width = 4,height = 4)


p <- ggplot(plot_data, aes(x = day, y = Cd44, fill = day)) +
  geom_violin(
    width = 0.9,
    scale = "width",
    trim = FALSE,
    color = "black",
    linewidth = 0.4,
    alpha = 0.85
  ) +
  geom_boxplot(
    width = 0.12,
    outlier.shape = NA,
    color = "black",
    fill = "white",
    linewidth = 0.4
  ) +
  geom_jitter(
    width = 0.12,
    size = 0.5,
    alpha = 0.5,
    color = "black"
  ) +
  stat_summary(
    fun = median,
    geom = "point",
    shape = 21,
    size = 2,
    fill = "white",
    color = "black",
    stroke = 0.4
  ) +
  stat_compare_means(
    comparisons = list(c("day 0", "day 1")),
    method = "wilcox.test",
    label = "p.signif",
    size = 5
  ) +
  scale_fill_manual(values = c("day 0" = "#4C78A8", "day 1" = "#F58518")) +
  scale_y_continuous(expand = expansion(mult = c(0.02, 0.12))) +
  labs(
    title = "Fibroblast2",
    x = "Day",
    y = expression(italic("Cd44") ~ "expression")
  ) +
  theme_classic(base_size = 13) +
  theme(
    plot.title = element_text(hjust = 0.5, face = "bold", size = 14),
    axis.title.x = element_text(face = "bold", size = 12),
    axis.title.y = element_text(face = "bold", size = 12),
    axis.text.x = element_text(size = 11, color = "black"),
    axis.text.y = element_text(size = 11, color = "black"),
    legend.position = "none"
  )
p


b <- ggplot(plot_data, aes(x = day, y = Lgals9, fill = day)) +
  geom_violin(
    width = 0.9,
    scale = "width",
    trim = FALSE,
    color = "black",
    linewidth = 0.4,
    alpha = 0.85
  ) +
  geom_boxplot(
    width = 0.12,
    outlier.shape = NA,
    color = "black",
    fill = "white",
    linewidth = 0.4
  ) +
  geom_jitter(
    width = 0.12,
    size = 0.5,
    alpha = 0.5,
    color = "black"
  ) +
  stat_summary(
    fun = median,
    geom = "point",
    shape = 21,
    size = 2,
    fill = "white",
    color = "black",
    stroke = 0.4
  ) +
  stat_compare_means(
    comparisons = list(c("day 0", "day 1")),
    method = "wilcox.test",
    label = "p.signif",
    size = 5
  ) +
  scale_fill_manual(values = c("day 0" = "#4C78A8", "day 1" = "#F58518")) +
  scale_y_continuous(expand = expansion(mult = c(0.02, 0.12))) +
  labs(
    title = "CC1",
    x = "Day",
    y = expression(italic("Lgals9") ~ "expression")
  ) +
  theme_classic(base_size = 13) +
  theme(
    plot.title = element_text(hjust = 0.5, face = "bold", size = 14),
    axis.title.x = element_text(face = "bold", size = 12),
    axis.title.y = element_text(face = "bold", size = 12),
    axis.text.x = element_text(size = 11, color = "black"),
    axis.text.y = element_text(size = 11, color = "black"),
    legend.position = "none"
  )
b
b+p
ggsave(b+p,file = 'vlnplot_CC1_Fibro2.pdf',height = 5,width = 7)


DCC <- readRDS("./DCC.rds")
fibroblast <- readRDS("./fibroblast.rds")

Fibro2 <- subset(fibroblast,ident = 'Fibroblast2')
Idents(Fibro2)<-'day'
Fibro2.d01 <- subset(Fibro2,ident = c('day 0','day 1'))
# plot_data <- FetchData(Fibro2.d01, vars = c('Cd44' ,"day"))
Idents(DCC)<-'day'
DCC01 <- subset(DCC,ident = c('day 0','day 1'))


DotPlot(Fibro2.d01,features = c('Cd44','Cd74','Cd36','Cd47'))

p<-DotPlot(
  Fibro2.d01,
  features = c("Cd44", "Cd74", "Cd36", "Cd47"),
  cols = c("#FEE8A8", "#A50026"),
  dot.scale = 6
) + ggtitle('Fibroblast2')+
  coord_flip() +
  theme_classic()

b<-DotPlot(
  DCC01,
  features = c("Lgals9", "Mif", "Thbs4"),
  cols = c("#FEE8A8", "#A50026"),
  dot.scale = 6
)  + ggtitle('CC1')+
  coord_flip() +
  theme_classic()
b+p
ggsave(b+p,file = 'Fibro2_d01_receptor.pdf',width = 8,height = 3)

library(patchwork)
p_combine <- p + b +
  plot_layout(ncol = 2, guides = "collect") &
  theme(legend.position = "right")

p_combine


#### CC_1 / DCC -> Fibroblast functional stacked plots

suppressPackageStartupMessages({
  library(dplyr)
  library(ggplot2)
  library(tidyr)
})

major_dir <- "./cellchat大类"
output_dir <- getwd()

major_source <- "CC_1"
major_source_label <- "CC1"
major_target <- "Fibroblast"
sub_source <- "DCC"
sub_source_label <- "CC1/DCC"
sub_targets_all <- c(
  "Fibroblast1", "Fibroblast2", "Fibroblast3", "Myfibroblast",
  "Pericyte", "Telocyte", "Trophocyte1", "Trophocyte2"
)
core_fib_targets <- c("Fibroblast1", "Fibroblast2", "Fibroblast3", "Myfibroblast")
day_levels <- c("d0", "d1")
focus_category <- "Inflammation / immune modulation"
ecm_category <- "ECM / adhesion / remodeling"
growth_category <- "Growth / repair / regeneration"
share_pdf_width <- 3.5

stack_order <- c(
  "Inflammation / immune modulation",
  "Growth / repair / regeneration",
  "ECM / adhesion / remodeling",
  "Migration / guidance / positioning",
  "Others"
)

legend_order <- stack_order

category_colors <- c(
  "Inflammation / immune modulation" = "#d73027",
  "Growth / repair / regeneration" = "#4575b4",
  "ECM / adhesion / remodeling" = "#91bfdb",
  "Migration / guidance / positioning" = "#fdae61",
  "Others" = "#d9d9d9"
)

core_fib_colors <- c(
  "Fibroblast1" = "#f94144",
  "Fibroblast2" = "#f78c6b",
  "Fibroblast3" = "#ffd166",
  "Myfibroblast" = "#83d483"
)

all_fib_colors <- c(
  "Fibroblast1" = "#f94144",
  "Fibroblast2" = "#f78c6b",
  "Fibroblast3" = "#ffd166",
  "Myfibroblast" = "#83d483",
  "Pericyte" = "#06d6a0",
  "Telocyte" = "#0cb0a9",
  "Trophocyte1" = "#118ab2",
  "Trophocyte2" = "#073b4c"
)
lr_list <- list(

  "Inflammation / immune modulation" = c(
    "Mif  - Ackr3",
    "Gas6  - Axl",
    "Lgals9  - Cd44",
    "Lamb3  - Cd44",
    "Lamc2  - Cd44",
    "Thbs4  - Cd47",
    
    "Mif  - (Cd74+Cd44)",
    "Ccl8  - Ackr4",
    "Nampt  - (Itga5+Itgb1)",
    "Tac1  - Tacr1",
    "Thbs1  - Cd36",
    "Thbs4  - Cd36",
    "Thbs1  - Cd47",
    "Nectin3  - Pvr",
    "Thbs4  - (Itgav+Itgb3)"
  ),

  "Growth / repair / regeneration" = c(
    "Thbs4  - Sdc4",
    "Lamb3  - Dag1",
    "Lamc2  - Dag1",
    "Lamb3  - (Itga1+Itgb1)",
    "Lamc2  - (Itga1+Itgb1)",
    "Thbs4  - Sdc1",
    "Lamb3  - (Itga2+Itgb1)",
    "Lamc2  - (Itga2+Itgb1)",
    "Lamb3  - (Itga9+Itgb1)",
    "Lamc2  - (Itga9+Itgb1)"，
     "Bmp2  - (Bmpr1a+Bmpr2)",
  ),

  "ECM / adhesion / remodeling" = c(
    "Tgfa  - Egfr",
    "Areg  - Egfr",
    "Hbegf  - Egfr",
    "Pdgfa  - Pdgfra",
    "Pdgfa  - Pdgfrb",
    "Ihh  - Ptch1",
    "Bmp2  - (Bmpr1a+Acvr2a)",
    "Bmp2  - (Bmpr1a+Acvr2b)",
    "Tgfa  - (Egfr+Erbb2)",
    "Areg  - (Egfr+Erbb2)",
    "Hbegf  - (Egfr+Erbb2)"，
    "F11r  - Jam2",
    "F11r  - Jam3",
    "Agrn  - Dag1"
  ),

  "Others" = c(
    "Edn1  - Ednra",
    "Edn1  - Ednrb",
    "Pyy  - Npy1r",
    "Sema4a  - Plxnb2",
    "Sema4g  - Plxnb2",
    "Sema3c  - (Nrp1+Nrp2)",
    "Sema3c  - Plxnd1",
    "Cdh1  - (Itga1+Itgb1)",
    "Efna1  - Epha3",
    "Efnb1  - Ephb3",
    "Efnb2  - Ephb3" 
  )
)

lr_class <- tibble::enframe(lr_list, name = "category", value = "LR_pair") %>%
  tidyr::unnest(cols = "LR_pair") %>%
  dplyr::select(LR_pair, category)

read_lr <- function(path) {
  df <- read.csv(path, check.names = FALSE, stringsAsFactors = FALSE)
  bad_names <- is.na(names(df)) | names(df) == ""

  if (any(bad_names)) {
    names(df)[bad_names] <- paste0("unnamed_", seq_len(sum(bad_names)))
  }

  df %>%
    mutate(prob = as.numeric(prob))
}

annotate_category <- function(df) {
  df %>%
    left_join(lr_class, by = c("interaction_name_2" = "LR_pair")) %>%
    mutate(
      category = ifelse(is.na(category), "Others", category),
      category = factor(category, levels = stack_order)
    )
}

make_subtype_category_summary <- function(summary_df, category_name) {
  summary_df %>%
    filter(category == category_name) %>%
    select(target, day, category, prob_sum) %>%
    complete(target = sub_targets_all, day = day_levels, fill = list(prob_sum = 0)) %>%
    mutate(
      target = factor(target, levels = sub_targets_all),
      day = factor(day, levels = day_levels),
      category = category_name
    )
}

make_subtype_category_share <- function(category_summary_df) {
  category_summary_df %>%
    group_by(day) %>%
    mutate(
      day_total = sum(prob_sum, na.rm = TRUE),
      prob_share = dplyr::if_else(day_total > 0, prob_sum / day_total, 0)
    ) %>%
    ungroup()
}

theme_fig3 <- function() {
  theme_bw(base_size = 11) +
    theme(
      panel.grid = element_blank(),
      panel.border = element_rect(color = "black", fill = NA, linewidth = 0.5),
      axis.text = element_text(color = "black"),
      axis.title.y = element_text(size = 10),
      plot.title = element_text(size = 12, face = "bold", hjust = 0.5),
      strip.background = element_rect(fill = "#f2f2f2", color = "black", linewidth = 0.4),
      strip.text = element_text(size = 8, face = "bold"),
      legend.title = element_blank(),
      legend.text = element_text(size = 8),
      legend.key.height = grid::unit(0.45, "cm")
    )
}

save_pdf_safe <- function(filename, plot, width, height) {
  tryCatch(
    {
      ggsave(
        filename = filename,
        plot = plot,
        width = width,
        height = height
      )
      invisible(filename)
    },
    error = function(e) {
      alt_filename <- file.path(
        dirname(filename),
        paste0(
          tools::file_path_sans_ext(basename(filename)),
          "_",
          format(Sys.time(), "%Y%m%d_%H%M%S"),
          ".pdf"
        )
      )

      message(
        "Could not overwrite ", basename(filename),
        "; saved to ", basename(alt_filename), " instead."
      )

      ggsave(
        filename = alt_filename,
        plot = plot,
        width = width,
        height = height
      )
      invisible(alt_filename)
    }
  )
}

major_d0 <- read_lr(file.path(major_dir, "d0_net_lr.csv")) %>%
  filter(source == major_source, target == major_target) %>%
  mutate(day = "d0")

major_d1 <- read_lr(file.path(major_dir, "d1_net_lr.csv")) %>%
  filter(source == major_source, target == major_target) %>%
  mutate(day = "d1")

sub_d0 <- read_lr(file.path(sub_dir, "day 0_net_lr.csv")) %>%
  filter(source == sub_source, target %in% sub_targets_all) %>%
  mutate(day = "d0")

sub_d1 <- read_lr(file.path(sub_dir, "day 1_net_lr.csv")) %>%
  filter(source == sub_source, target %in% sub_targets_all) %>%
  mutate(day = "d1")

major_anno <- bind_rows(major_d0, major_d1) %>%
  annotate_category()

sub_anno <- bind_rows(sub_d0, sub_d1) %>%
  annotate_category()

major_summary <- major_anno %>%
  group_by(day, category) %>%
  summarise(prob_sum = sum(prob, na.rm = TRUE), .groups = "drop") %>%
  complete(day = day_levels, category = stack_order, fill = list(prob_sum = 0)) %>%
  mutate(
    day = factor(day, levels = day_levels),
    category = factor(category, levels = stack_order)
  )

sub_summary <- sub_anno %>%
  group_by(target, day, category) %>%
  summarise(prob_sum = sum(prob, na.rm = TRUE), .groups = "drop") %>%
  complete(target = sub_targets_all, day = day_levels, category = stack_order, fill = list(prob_sum = 0)) %>%
  mutate(
    target = factor(target, levels = sub_targets_all),
    day = factor(day, levels = day_levels),
    category = factor(category, levels = stack_order)
  )

sub_core_summary <- sub_summary %>%
  filter(target %in% core_fib_targets) %>%
  mutate(target = factor(as.character(target), levels = core_fib_targets))

sub_main_inflammation_summary <- make_subtype_category_summary(sub_summary, focus_category)
sub_main_inflammation_share <- make_subtype_category_share(sub_main_inflammation_summary)

sub_main_ecm_summary <- make_subtype_category_summary(sub_summary, ecm_category)
sub_main_ecm_share <- make_subtype_category_share(sub_main_ecm_summary)

sub_main_growth_summary <- make_subtype_category_summary(sub_summary, growth_category)
sub_main_growth_share <- make_subtype_category_share(sub_main_growth_summary)

major_plot_df <- major_summary %>%
  group_by(category) %>%
  filter(any(prob_sum > 0)) %>%
  ungroup()

sub_plot_df <- sub_summary %>%
  group_by(category) %>%
  filter(any(prob_sum > 0)) %>%
  ungroup()

unmatched_lr <- bind_rows(
  major_anno %>%
    filter(category == "Others") %>%
    mutate(data_level = "major"),
  sub_anno %>%
    filter(category == "Others") %>%
    mutate(data_level = "subtype")
) %>%
  distinct(data_level, day, source, target, interaction_name_2) %>%
  arrange(data_level, day, source, target, interaction_name_2)

write.csv(
  major_summary,
  file.path(output_dir, "Fig3C_CC1_to_Fibroblast_function_prob_summary.csv"),
  row.names = FALSE
)
write.csv(
  sub_summary,
  file.path(output_dir, "Fig3D_DCC_to_Fibroblast_subtype_function_prob_summary.csv"),
  row.names = FALSE
)
write.csv(
  sub_core_summary,
  file.path(output_dir, "Fig3D_core_fibroblast_subtype_function_prob_summary.csv"),
  row.names = FALSE
)
write.csv(
  sub_main_inflammation_summary,
  file.path(output_dir, "Fig3D_core_fibroblast_inflammation_prob_summary.csv"),
  row.names = FALSE
)
write.csv(
  sub_main_inflammation_share,
  file.path(output_dir, "Fig3D_core_fibroblast_inflammation_share_summary.csv"),
  row.names = FALSE
)
write.csv(
  sub_main_ecm_share,
  file.path(output_dir, "Fig3D_fibroblast_ecm_share_summary.csv"),
  row.names = FALSE
)
write.csv(
  sub_main_growth_share,
  file.path(output_dir, "Fig3D_fibroblast_growth_share_summary.csv"),
  row.names = FALSE
)
write.csv(
  unmatched_lr,
  file.path(output_dir, "Fig3CD_LR_pairs_assigned_to_Others.csv"),
  row.names = FALSE
)

p_major <- ggplot(major_plot_df, aes(x = day, y = prob_sum, fill = category)) +
  geom_col(width = 0.6, color = "black", linewidth = 0.25) +
  scale_fill_manual(values = category_colors, breaks = legend_order) +
  scale_y_continuous(
    labels = scales::label_scientific(digits = 2),
    expand = expansion(mult = c(0, 0.05))
  ) +
  labs(
    title = paste0(major_source_label, " -> ", major_target),
    x = NULL,
    y = "Communication probability (sum)"
  ) +
  theme_fig3() +
  theme(
    axis.title.x = element_blank(),
    legend.position = "right"
  )

p_sub <- ggplot(sub_plot_df, aes(x = day, y = prob_sum, fill = category)) +
  geom_col(width = 0.65, color = "black", linewidth = 0.2) +
  facet_wrap(~target, nrow = 1) +
  scale_fill_manual(values = category_colors, breaks = legend_order) +
  scale_y_continuous(
    labels = scales::label_scientific(digits = 2),
    expand = expansion(mult = c(0, 0.05))
  ) +
  labs(
    title = paste0(sub_source_label, " -> sub_Fibroblast"),
    x = "Day",
    y = "Communication probability (sum)"
  ) +
  theme_fig3() +
  theme(
    axis.title.x = element_text(size = 10),
    panel.spacing.x = grid::unit(0.12, "lines"),
    strip.text = element_text(size = 7.5),
    legend.position = "right"
  )

p_sub_main <- ggplot(sub_main_inflammation_summary, aes(x = day, y = prob_sum, fill = target)) +
  geom_col(width = 0.6, color = "black", linewidth = 0.25) +
  scale_fill_manual(values = all_fib_colors, breaks = sub_targets_all) +
  scale_y_continuous(
    labels = scales::label_scientific(digits = 2),
    expand = expansion(mult = c(0, 0.05))
  ) +
  labs(
    title = "Inflammatory CC1/DCC -> Fibroblast subtypes",
    x = NULL,
    y = "Communication probability (sum)"
  ) +
  theme_fig3() +
  theme(
    axis.title.x = element_blank(),
    legend.position = "right"
  )

p_sub_main_share <- ggplot(sub_main_inflammation_share, aes(x = day, y = prob_share, fill = target)) +
  geom_col(width = 0.6, color = "black", linewidth = 0.25) +
  scale_fill_manual(values = all_fib_colors, breaks = sub_targets_all) +
  scale_y_continuous(
    labels = scales::percent_format(accuracy = 1),
    expand = expansion(mult = c(0, 0.02))
  ) +
  labs(
    title = "Inflammatory recipient composition",
    x = NULL,
    y = "Share within each day"
  ) +
  theme_fig3() +
  theme(
    axis.title.x = element_blank(),
    legend.position = "right"
  )

p_sub_ecm_share <- ggplot(sub_main_ecm_share, aes(x = day, y = prob_share, fill = target)) +
  geom_col(width = 0.6, color = "black", linewidth = 0.25) +
  scale_fill_manual(values = all_fib_colors, breaks = sub_targets_all) +
  scale_y_continuous(
    labels = scales::percent_format(accuracy = 1),
    expand = expansion(mult = c(0, 0.02))
  ) +
  labs(
    title = "ECM recipient composition",
    x = NULL,
    y = "Share within each day"
  ) +
  theme_fig3() +
  theme(
    axis.title.x = element_blank(),
    legend.position = "right"
  )

p_sub_growth_share <- ggplot(sub_main_growth_share, aes(x = day, y = prob_share, fill = target)) +
  geom_col(width = 0.6, color = "black", linewidth = 0.25) +
  scale_fill_manual(values = all_fib_colors, breaks = sub_targets_all) +
  scale_y_continuous(
    labels = scales::percent_format(accuracy = 1),
    expand = expansion(mult = c(0, 0.02))
  ) +
  labs(
    title = "Growth / repair recipient composition",
    x = NULL,
    y = "Share within each day"
  ) +
  theme_fig3() +
  theme(
    axis.title.x = element_blank(),
    legend.position = "right"
  )

p_combined_share <- p_major + p_sub_main_share + patchwork::plot_layout(widths = c(1, 1.25))

save_pdf_safe(
    filename = file.path(output_dir, "Fig3CD_main_combined_function_share.pdf"),
    plot = p_combined_share,
    width = 7.8,
    height = 3.3
  )

library(Seurat)
library(ggplot2)
library(dplyr)
library(tidyr)
library(corrplot)

cc1 <- readRDS("DCC.rds")
fibroblast <- readRDS("Fibroblast.rds")

inflammatory_genes <- c('Ifi44','Irf7','Cxcl9','Ly6e','Il1b')

lgals9_expr <- FetchData(cc1, vars = c("Lgals9", "day"))
lgals9_expr$cell_id <- rownames(lgals9_expr)

available_genes <- inflammatory_genes[inflammatory_genes %in% rownames(fibroblast)]
missing_genes <- setdiff(inflammatory_genes, available_genes)

inflam_expr <- FetchData(fibroblast, vars = c(available_genes, "day"))
inflam_expr$cell_id <- rownames(inflam_expr)

common_cells <- intersect(lgals9_expr$cell_id, inflam_expr$cell_id)

if(length(common_cells) == 0) {
   lgals9_mean <- lgals9_expr %>%
    group_by(day) %>%
    summarise(Lgals9_mean = mean(Lgals9, na.rm = TRUE)) %>%
    ungroup()
   inflam_mean <- inflam_expr %>%
    group_by(day) %>%
    summarise(across(all_of(available_genes), ~mean(., na.rm = TRUE), .names = "{.col}_mean")) %>%
    ungroup()
   combined_data <- inner_join(lgals9_mean, inflam_mean, by = "day")

  correlation_results_sample <- data.frame(
    gene = available_genes,
    correlation = NA,
    pvalue = NA
  )
  
  for(i in 1:length(available_genes)) {
    gene <- available_genes[i]
    gene_col <- paste0(gene, "_mean")
    cor_test <- cor.test(combined_data$Lgals9_mean, combined_data[[gene_col]], method = "pearson")
    correlation_results_sample$correlation[i] <- cor_test$estimate
    correlation_results_sample$pvalue[i] <- cor_test$p.value
  }
  
  correlation_results_sample$significant <- ifelse(correlation_results_sample$pvalue < 0.05, "Yes", "No")
  all_correlations <- correlation_results_sample

  sample_level_data <- combined_data
  use_sample_level <- TRUE
  
} else {
  use_sample_level <- FALSE

  lgals9_data <- lgals9_expr[lgals9_expr$cell_id %in% common_cells, ]
  inflam_data <- inflam_expr[inflam_expr$cell_id %in% common_cells, ]
  
  days <- unique(lgals9_data$day)
  correlation_results <- list()
  
  for(d in days) {

    lgals9_day <- lgals9_data[lgals9_data$day == d, ]
    inflam_day <- inflam_data[inflam_data$day == d, ]

    common_cells_day <- intersect(lgals9_day$cell_id, inflam_day$cell_id)
    lgals9_day <- lgals9_day[match(common_cells_day, lgals9_day$cell_id), ]
    inflam_day <- inflam_day[match(common_cells_day, inflam_day$cell_id), ]

    cor_matrix <- data.frame(
      gene = available_genes,
      correlation = NA,
      pvalue = NA,
      day = d
    )
    
    for(i in 1:length(available_genes)) {
      gene <- available_genes[i]
      cor_test <- cor.test(lgals9_day$Lgals9, inflam_day[[gene]], method = "pearson")
      cor_matrix$correlation[i] <- cor_test$estimate
      cor_matrix$pvalue[i] <- cor_test$p.value
    }
    
    correlation_results[[as.character(d)]] <- cor_matrix
  }

  all_correlations <- do.call(rbind, correlation_results)
  all_correlations$significant <- ifelse(all_correlations$pvalue < 0.05, "Yes", "No")
}



  gene_mean_cols <- paste0(available_genes, "_mean")
  sample_level_data$inflammatory_mean <- rowMeans(sample_level_data[, gene_mean_cols], na.rm = TRUE)

  geneset_cor <- cor.test(sample_level_data$Lgals9_mean, sample_level_data$inflammatory_mean, method = "pearson")
  geneset_cor_val <- round(geneset_cor$estimate, 3)
  
  p_geneset <- ggplot(sample_level_data, aes(x = Lgals9_mean, y = inflammatory_mean)) +
    geom_point(size = 6, color = "steelblue", alpha = 0.7) +
    geom_smooth(method = "lm", se = TRUE, color = "red", linetype = "dashed", linewidth = 1.5) +
    geom_text(aes(label = day), vjust = -1.5, size = 5, fontface = "bold") +
    theme_bw(base_size = 14) +
    theme(panel.grid.major = element_line(color = "gray90"),
          panel.grid.minor = element_blank(),
          plot.title = element_text(hjust = 0.5, face = "bold", size = 16),
          plot.subtitle = element_text(hjust = 0.5, size = 12)) +
    labs(title = "Lgals9 vs Inflammatory Gene Set Mean Expression",
         subtitle = paste0("Genes: ", paste(available_genes, collapse = ", "), 
                          "\nr = ", geneset_cor_val, ", p = ", geneset_p_val),
         x = "Lgals9 Mean Expression (CC1)",
         y = "Inflammatory Gene Set Mean Expression (Fibroblast)") +
    annotate("text", x = min(sample_level_data$Lgals9_mean), 
             y = max(sample_level_data$inflammatory_mean),
             label = paste0("n = ", nrow(sample_level_data), " time points"),
             hjust = 0, vjust = 1, size = 4, color = "gray30")
  
  ggsave("scatter_plot_geneset_mean_ggplot.pdf", p_geneset, width = 12, height = 10)
  
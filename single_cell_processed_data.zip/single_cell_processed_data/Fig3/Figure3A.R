library(CellChat)
library(ggplot2)
library(pheatmap)
library(RColorBrewer)

cellchat_d0 <- readRDS("./cellchat_d0.rds")
cellchat_d1 <- readRDS("./cellchat_d1.rds")
cellchat_d3 <- readRDS("/cellchat_d3.rds")
cellchat_d5 <- readRDS("./cellchat_d5.rds")
cellchat_d7 <- readRDS("./cellchat_d7.rds")

object.list <- list(d0 = cellchat_d0, d1 = cellchat_d1,d3 = cellchat_d3, d5 = cellchat_d5,d7 = cellchat_d7)
cellchat <- mergeCellChat(object.list, add.names = names(object.list))
cellchat

cellchat_list <- list(
  d0 = cellchat_d0,
  d1 = cellchat_d1,
  d3 = cellchat_d3,
  d5 = cellchat_d5,
  d7 = cellchat_d7
)

receiver_cell <- "Fibroblast"
drop_self <- TRUE

mat<-cellchat_d0@net$weight
colnames(mat)

extract_incoming_to_receiver <- function(cellchat_obj, receiver, slot_name = "weight") {
  mat <- cellchat_obj@net[[slot_name]]
  
  if (!(receiver %in% colnames(mat))) {
    stop(paste0("Cannot find receiver '", receiver, "' in net$", slot_name))
  }
  
  incoming <- mat[, receiver, drop = FALSE]
  incoming <- as.numeric(incoming[, 1]) 
  names(incoming) <- rownames(mat)
  return(incoming)
}

incoming_list <- lapply(cellchat_list, extract_incoming_to_receiver, receiver = receiver_cell, slot_name = "weight")
all_senders <- unique(unlist(lapply(incoming_list, names)))

incoming_mat <- sapply(incoming_list, function(x) {
  out <- setNames(rep(0, length(all_senders)), all_senders)
  out[names(x)] <- x
  out
})

incoming_mat <- as.matrix(incoming_mat)

if (drop_self && receiver_cell %in% rownames(incoming_mat)) {
  incoming_mat <- incoming_mat[rownames(incoming_mat) != receiver_cell, , drop = FALSE]
}

# 按总强度排序——按每个 sender 在所有时间点上的总和排序
incoming_mat <- incoming_mat[order(rowSums(incoming_mat), decreasing = TRUE), ]

# 热图
pdf('to_Fibroblast.pdf',width = 5,height = 4)
pheatmap(
  incoming_mat,
  scale = "column",
  color = colorRampPalette(c("#2166AC", "white", "#B2182B"))(100),
  cluster_rows = FALSE,
  cluster_cols = FALSE,
  border_color = NA,
  fontsize_row = 10,
  fontsize_col = 12,
  angle_col = 0,
  main = "Relative incoming communication to Fibroblast within each day"
)
dev.off()

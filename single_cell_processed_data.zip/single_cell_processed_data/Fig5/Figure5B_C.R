library(dplyr)
library(tidyr)
library(ggplot2)
library(purrr)
library(forcats)
library(CellChat)

setwd('G:/课题二 成纤维细胞相关/Results/Public data/Result/UC/2.cellchat/合并Fibroblast')


# 1.读入数据
cellchat_Healthy_CTRL <- readRDS("./Healthy_CellChat.rds")
cellchat_Self_CTRL <- readRDS("./Uninflamed_CellChat.rds")
cellchat_UC <- readRDS("./Inflamed_CellChat.rds")

object.list <- list(Healthy = cellchat_Healthy_CTRL,
                    Uninflamed = cellchat_Self_CTRL, 
                    Inflamed = cellchat_UC)
cellchat <- mergeCellChat(object.list, add.names = names(object.list))
cellchat

#### 2.提取数据 ####
# A.weight
weight_d0<-cellchat_Healthy_CTRL@net$weight
weight_d1<-cellchat_UC@net$weight
weight_d3<-cellchat_Self_CTRL@net$weight

weight_list<-list(weight_d0,weight_d1,weight_d3)
names(weight_list)<-c("Healthy_CTRL","UC","Self_CTRL")

# # B.number
# weight_d0<-cellchat_Healthy_CTRL@net$count
# weight_d1<-cellchat_UC@net$count
# weight_d3<-cellchat_Self_CTRL@net$count


# C.可视化
# 行：发送方
# 列：接收方
# ✅  1.计算
calc_strength <- function(weight_mat) {
  diag(weight_mat) <- 0  # 去掉 self–self
  rowSums(weight_mat, na.rm = TRUE)
}

# ✅  2.整理成一个 tidy data.frame
outgoing_df <- do.call(rbind, lapply(names(weight_list), function(cond) {
  w <- weight_list[[cond]]
  data.frame(
    celltype = rownames(w),
    strength = calc_strength(w),
    condition = cond,
    row.names = NULL
  )
}))

# ✅  3.如果你想按「强度排序」再画
# 设定绘图顺序
palette_celltype <-  c(
  'Epithelial' = "#1F77B4",  # Epithelial - 深蓝
  'T_cells' = "#D62728",  # T_cells - 鲜红
  'B_cells' = "#17BECF",  # B_cells - 绿色
  'Plasma' = "#9467BD",  # Plasma - 紫色
  'Macrophage' = "#FF7F0E",  # Macrophage - 橙色
  'Mast_cells' = "#E377C2",  # Mast_cells - 洋红
  'Fibroblast' = "#8C564B",  # Fibroblast - 深棕
  #'Fibroblast_SPP1' = "#2CA02C",  # Fibroblast_SPP1 - 青蓝
  'Endothelial' = "#BCBD22"   # Endothelial - 黄绿
)

outgoing_df$celltype <- factor(outgoing_df$celltype, levels = names(palette_celltype))
conditions <- levels(factor(outgoing_df$condition, levels = c("Healthy_CTRL","UC","Self_CTRL")))

#### 2.可视化UC前后，传入Fibroblast的信号强度变化---------------------------------------------------------------------------------
cellchat
object.list

receiver_cell <- "Fibroblast"
drop_self <- TRUE 

# Define function: Extract "all incoming signals that are directed to a certain receiver"
extract_incoming_to_receiver <- function(cellchat_obj, receiver, slot_name = "weight") {
  mat <- cellchat_obj@net[[slot_name]]
  
  if (!(receiver %in% colnames(mat))) {
    stop(paste0("Cannot find receiver '", receiver, "' in net$", slot_name))
  }
  
  incoming <- mat[, receiver, drop = FALSE] 
  incoming <- as.numeric(incoming[, 1])  
  names(incoming) <- rownames(mat)  
  return(incoming)
}

# Batch extraction of incoming signals at all time points; a list will be obtained, showing the communication intensity between all cells and Fibroblast at specific time points.
incoming_list <- lapply(object.list, extract_incoming_to_receiver, receiver = receiver_cell, slot_name = "weight")
all_senders <- unique(unlist(lapply(incoming_list, names)))

incoming_mat <- sapply(incoming_list, function(x) {
  out <- setNames(rep(0, length(all_senders)), all_senders)
  out[names(x)] <- x
  out
})

incoming_mat <- as.matrix(incoming_mat)

if (drop_self && receiver_cell %in% rownames(incoming_mat)) {
  incoming_mat <- incoming_mat[rownames(incoming_mat) != receiver_cell, , drop = FALSE]
}

incoming_mat <- incoming_mat[order(rowSums(incoming_mat), decreasing = TRUE), ]

library(pheatmap)
pdf('rename_不同天_to_Fibroblast强度变化.pdf',width = 4,height = 3.3)
pheatmap(
  incoming_mat,
  scale = "column",
  color = colorRampPalette(c("#2166AC", "white", "#B2182B"))(100),
  cluster_rows = FALSE,
  cluster_cols = FALSE,
  border_color = NA,
  fontsize_row = 10,
  fontsize_col = 12,
  angle_col = 0,
  main = "Relative incoming communication to Fibroblast within each day"
)
dev.off()


#### 3.Determine whether the signals emitted by Fibroblast are the strongest ones directed towards Macrophage after the inflammation.---------------------------------------------------------------------------------

get_fibro_outgoing_prop <- function(weight_mat, sender = "Fibroblast") {
  v <- weight_mat[sender, ]   
  v <- v[names(v) != sender] 
  
  total <- sum(v)
  if (total == 0) {
    return(rep(NA, length(v)))
  }
  
  prop <- v / total 
  return(prop)
}

cellchat_Healthy_CTRL <- readRDS("./Healthy_CellChat.rds")
cellchat_Self_CTRL <- readRDS("./Uninflamed_CellChat.rds")
cellchat_UC <- readRDS("./Inflamed_CellChat.rds")

cellchat_d0 <- cellchat_Healthy_CTRL
cellchat_d1<-cellchat_Self_CTRL
cellchat_d3<-cellchat_UC

weight_d0<-cellchat_d0@net$weight
weight_d1<-cellchat_d1@net$weight
weight_d3<-cellchat_d3@net$weight

prop_d0 <- get_fibro_outgoing_prop(weight_d0)
prop_d1 <- get_fibro_outgoing_prop(weight_d1)
prop_d3 <- get_fibro_outgoing_prop(weight_d3)

df_prop <- data.frame(
  celltype = names(prop_d0),
  d0 = prop_d0,
  d1 = prop_d1,
  d3 = prop_d3,
  row.names = NULL
)

df_diff <- df_prop %>%
  mutate(
    d1_vs_d0 = d1 - d0,
    d3_vs_d0 = d3 - d0
  )
df_diff

colnames(df_diff)
df_diff_long <- df_diff %>%
  dplyr::select(celltype, d1_vs_d0, d3_vs_d0) %>%
  tidyr::pivot_longer(
    cols = -celltype, 
    names_to = "day", 
    values_to = "diff" 
  )

df_diff_long$day <- factor(
  df_diff_long$day,
  levels = c("d1_vs_d0", "d3_vs_d0"),
  labels = c("day 1 - day 0", "day 3 - day 0")
)

df_diff_long

cell_order <- df_diff_long %>%
  group_by(celltype) %>%
  summarise(max_abs_diff = max(abs(diff), na.rm = TRUE), .groups = "drop") %>%
  arrange(desc(max_abs_diff)) %>%
  pull(celltype)

df_diff_long$celltype <- factor(df_diff_long$celltype, levels = cell_order)

# 4)绘制并列柱形图
day_colors <- c(
  "day 1 - day 0" = "#ffca3a",
  "day 3 - day 0" = "#8ac926"
)

p_diff <- ggplot(df_diff_long, aes(x = celltype, y = diff, fill = day)) +
  geom_col(
    position = position_dodge(width = 0.8),
    width = 0.7,
    color = "black",
    linewidth = 0.15
  ) +
  geom_hline(yintercept = 0, linetype = "dashed", color = "black", linewidth = 0.4) +
  scale_fill_manual(values = day_colors) +
  theme_classic(base_size = 13) +
  labs(
    x = NULL,
    y = "Change in proportion of outgoing communication\n(relative to day 0)",
    fill = "Day",
    title = "Redistribution of Fibroblast outgoing communication"
  ) +
  theme(
    axis.text.x = element_text(angle = 35, hjust = 1, size = 10),
    axis.text.y = element_text(size = 11),
    axis.title.y = element_text(size = 12),
    legend.title = element_text(size = 11),
    legend.text = element_text(size = 10)
  )

p_diff
ggsave(p_diff,file = 'Fibroblast_outgoing_compare_with_d0.pdf',width = 5.5,height = 3.5)






















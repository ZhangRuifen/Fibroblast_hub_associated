suppressPackageStartupMessages({
  library(dplyr)
  library(ggplot2)
  library(ggpubr)
  library(Seurat)
  library(tidyr)
  library(UCell)
  library(AnnotationDbi)
  library(org.Hs.eg.db)
})

setwd("G:/课题二 成纤维细胞相关/Result_new/Fig5/Fig5A")
output_dir <- file.path(getwd(), "output")
if (!dir.exists(output_dir)) {
  dir.create(output_dir, recursive = TRUE)
}

Fibro <- readRDS("./raw.Fibroblast.rds")

go_terms <- c(
  acute_phase_response = "GO:0006953",
  acute_inflammatory_response = "GO:0002526",
  regulation_of_inflammatory_response = "GO:0050727"
)

gene_list <- lapply(go_terms, function(go_id) {
  genes <- AnnotationDbi::select(
    org.Hs.eg.db,
    keys = go_id,
    columns = "SYMBOL",
    keytype = "GOALL"
  )
  genes <- unique(genes$SYMBOL)
  genes[!is.na(genes) & nzchar(genes)]
})

inflammation_genes <- c(
  "IFNG", "IFNGR1", "IFNGR2", "IL10", "IL12A", "IL12B", "IL12RB1",
  "IL12RB2", "IL13", "IL17A", "IL17F", "IL18", "IL18R1", "IL18RAP",
  "IL1A", "IL1B", "IL2", "IL21", "IL21R", "IL22", "IL23A", "IL23R",
  "IL2RG", "IL4", "IL4R", "IL5", "IL6", "JUN", "NFKB1", "RELA", "RORA",
  "RORC", "S100A8", "S100A9", "STAT1", "STAT3", "STAT4", "STAT6",
  "TGFB1", "TGFB2", "TGFB3", "TNF"
)
gene_list$inflammation_gene <- inflammation_genes

signature_labels <- c(
  acute_phase_response = "Acute phase\nresponse",
  acute_inflammatory_response = "Acute inflammatory\nresponse",
  regulation_of_inflammatory_response = "Regulation of\ninflammatory response",
  inflammation_gene = "Inflammation\ngene set"
)

comparisons <- list(c("Healthy", "Uninflamed"), c("Healthy", "Inflamed"))
group_levels <- c("Healthy", "Uninflamed", "Inflamed")
group_colors <- c(
  Healthy = "#4DBBD5",
  Uninflamed = "#00A087",
  Inflamed = "#E64B35"
)

prepare_score_data <- function(object, score_cols, method_name) {
  score_data <- FetchData(object, vars = c("Healthy", score_cols))
  colnames(score_data) <- c("Healthy", names(signature_labels))
  score_data %>%
    mutate(Healthy = factor(Healthy, levels = group_levels)) %>%
    pivot_longer(
      cols = all_of(names(signature_labels)),
      names_to = "signature",
      values_to = "score"
    ) %>%
    mutate(
      method = method_name,
      signature = factor(signature, levels = names(signature_labels), labels = signature_labels)
    )
}

sample_plot_points <- function(plot_df, max_cells_per_group = 180) {
  set.seed(20260509)
  plot_df %>%
    group_by(across(any_of(c("method", "signature", "Healthy")))) %>%
    group_modify(~ {
      if (nrow(.x) > max_cells_per_group) {
        slice_sample(.x, n = max_cells_per_group)
      } else {
        .x
      }
    }) %>%
    ungroup()
}

plot_inflammation_scores <- function(plot_df, title_text, y_label, show_points = TRUE) {
  score_plot <- ggplot(plot_df, aes(x = Healthy, y = score, fill = Healthy, color = Healthy)) +
    geom_boxplot(width = 0.56, outlier.shape = NA, linewidth = 0.45, alpha = 0.72)

  if (show_points) {
    score_plot <- score_plot +
      geom_jitter(data = sample_plot_points(plot_df), width = 0.12, size = 0.24, alpha = 0.30, stroke = 0)
  }

  score_plot +
    stat_compare_means(
      method = "wilcox.test",
      label = "p.signif",
      comparisons = comparisons,
      hide.ns = TRUE,
      size = 3,
      bracket.size = 0.32,
      tip.length = 0.01
    ) +
    scale_fill_manual(values = group_colors) +
    scale_color_manual(values = group_colors) +
    facet_wrap(~signature, scales = "free_y", ncol = 4) +
    labs(title = title_text, x = NULL, y = y_label) +
    theme_classic(base_size = 8, base_family = "Arial") +
    theme(
      legend.position = "none",
      plot.title = element_text(size = 10, face = "bold", hjust = 0.5, margin = margin(b = 8)),
      axis.text.x = element_text(size = 7, angle = 35, hjust = 1, color = "black"),
      axis.text.y = element_text(size = 7, color = "black"),
      axis.title.y = element_text(size = 8, color = "black", margin = margin(r = 5)),
      axis.line = element_line(color = "black", linewidth = 0.35),
      axis.ticks = element_line(color = "black", linewidth = 0.3),
      axis.ticks.length = unit(1.6, "mm"),
      strip.background = element_blank(),
      strip.text = element_text(size = 8, face = "bold", color = "black"),
      panel.spacing.x = unit(5, "mm"),
      panel.spacing.y = unit(4, "mm"),
      plot.margin = margin(5, 6, 5, 6)
    )
}

Fibro_addmodule <- AddModuleScore(object = Fibro, features = gene_list, name = names(gene_list))
addmodule_score_cols <- paste0(names(gene_list), seq_along(gene_list))
addmodule_df <- prepare_score_data(Fibro_addmodule, addmodule_score_cols, "AddModuleScore")

Fibro_ucell <- UCell::AddModuleScore_UCell(Fibro, features = gene_list, name = "_UCell")
ucell_score_cols <- paste0(names(gene_list), "_UCell")
ucell_df <- prepare_score_data(Fibro_ucell, ucell_score_cols, "UCell")

addmodule_plot <- plot_inflammation_scores(
  addmodule_df,
  "Inflammation-related signature scores by AddModuleScore",
  "AddModuleScore"
)
ucell_plot <- plot_inflammation_scores(
  ucell_df,
  "Inflammation-related signature scores by UCell",
  "UCell score"
)
addmodule_plot_no_points <- plot_inflammation_scores(
  addmodule_df,
  "Inflammation-related signature scores by AddModuleScore",
  "AddModuleScore",
  show_points = FALSE
)
ucell_plot_no_points <- plot_inflammation_scores(
  ucell_df,
  "Inflammation-related signature scores by UCell",
  "UCell score",
  show_points = FALSE
)

combined_df <- bind_rows(addmodule_df, ucell_df) %>%
  mutate(method = factor(method, levels = c("AddModuleScore", "UCell")))
combined_plot <- ggplot(combined_df, aes(x = Healthy, y = score, fill = Healthy, color = Healthy)) +
  geom_boxplot(width = 0.56, outlier.shape = NA, linewidth = 0.42, alpha = 0.72) +
  geom_jitter(data = sample_plot_points(combined_df), width = 0.12, size = 0.22, alpha = 0.28, stroke = 0) +
  scale_fill_manual(values = group_colors) +
  scale_color_manual(values = group_colors) +
  facet_grid(method ~ signature, scales = "free_y") +
  labs(title = "Inflammation-related signature scores", x = NULL, y = "Score") +
  theme_classic(base_size = 8, base_family = "Arial") +
  theme(
    legend.position = "none",
    plot.title = element_text(size = 10, face = "bold", hjust = 0.5, margin = margin(b = 8)),
    axis.text.x = element_text(size = 7, angle = 35, hjust = 1, color = "black"),
    axis.text.y = element_text(size = 7, color = "black"),
    axis.title.y = element_text(size = 8, color = "black", margin = margin(r = 5)),
    axis.line = element_line(color = "black", linewidth = 0.35),
    axis.ticks = element_line(color = "black", linewidth = 0.3),
    axis.ticks.length = unit(1.6, "mm"),
    strip.background = element_blank(),
    strip.text = element_text(size = 8, face = "bold", color = "black"),
    panel.spacing.x = unit(5, "mm"),
    panel.spacing.y = unit(4, "mm"),
    plot.margin = margin(5, 6, 5, 6)
  )
combined_plot_no_points <- ggplot(combined_df, aes(x = Healthy, y = score, fill = Healthy, color = Healthy)) +
  geom_boxplot(width = 0.56, outlier.shape = NA, linewidth = 0.42, alpha = 0.72) +
  scale_fill_manual(values = group_colors) +
  scale_color_manual(values = group_colors) +
  facet_grid(method ~ signature, scales = "free_y") +
  labs(title = "Inflammation-related signature scores", x = NULL, y = "Score") +
  theme_classic(base_size = 8, base_family = "Arial") +
  theme(
    legend.position = "none",
    plot.title = element_text(size = 10, face = "bold", hjust = 0.5, margin = margin(b = 8)),
    axis.text.x = element_text(size = 7, angle = 35, hjust = 1, color = "black"),
    axis.text.y = element_text(size = 7, color = "black"),
    axis.title.y = element_text(size = 8, color = "black", margin = margin(r = 5)),
    axis.line = element_line(color = "black", linewidth = 0.35),
    axis.ticks = element_line(color = "black", linewidth = 0.3),
    axis.ticks.length = unit(1.6, "mm"),
    strip.background = element_blank(),
    strip.text = element_text(size = 8, face = "bold", color = "black"),
    panel.spacing.x = unit(5, "mm"),
    panel.spacing.y = unit(4, "mm"),
    plot.margin = margin(5, 6, 5, 6)
  )

ggsave(file.path(output_dir, "inflammation_AddModuleScore_Nature.pdf"), addmodule_plot, width = 10.5, height = 3.6, units = "in", device = cairo_pdf)
ggsave(file.path(output_dir, "inflammation_UCell_Nature.pdf"), ucell_plot, width = 10.5, height = 3.6, units = "in", device = cairo_pdf)
ggsave(file.path(output_dir, "inflammation_scores_combined_Nature.pdf"), combined_plot, width = 10.8, height = 5.4, units = "in", device = cairo_pdf)
ggsave(file.path(output_dir, "inflammation_AddModuleScore_Nature_no_points.pdf"), addmodule_plot_no_points, width = 10.5, height = 3.6, units = "in", device = cairo_pdf)
ggsave(file.path(output_dir, "inflammation_UCell_Nature_no_points.pdf"), ucell_plot_no_points, width = 10.5, height = 3.6, units = "in", device = cairo_pdf)
ggsave(file.path(output_dir, "inflammation_scores_combined_Nature_no_points.pdf"), combined_plot_no_points, width = 10.8, height = 5.4, units = "in", device = cairo_pdf)

saveRDS(Fibro_ucell, file.path(output_dir, "Fibroblast_UCell_scored.rds"))

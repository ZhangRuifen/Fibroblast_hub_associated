#!/usr/bin/env Rscript

suppressPackageStartupMessages({
  library(Seurat)
  library(Matrix)
  library(dplyr)
  library(ggplot2)
  library(pheatmap)
  library(grid)
})

get_script_dir <- function() {
  file_arg <- grep("^--file=", commandArgs(FALSE), value = TRUE)
  if (length(file_arg) > 0) {
    return(dirname(normalizePath(sub("^--file=", "", file_arg[1]), winslash = "/", mustWork = FALSE)))
  }
  normalizePath(getwd(), winslash = "/", mustWork = FALSE)
}

base_dir <- get_script_dir()
args <- commandArgs(trailingOnly = TRUE)

get_arg_value <- function(prefix, default = NA_character_) {
  hit <- grep(paste0("^", prefix), args, value = TRUE)
  if (length(hit) == 0) {
    return(default)
  }
  sub(paste0("^", prefix), "", hit[1])
}

top_marker_n <- suppressWarnings(as.integer(get_arg_value("--top-marker-n=", "100")))
if (is.na(top_marker_n) || top_marker_n <= 0) {
  stop("--top-marker-n must be a positive integer.")
}

human_rds <- file.path(base_dir, "Human_Fibro.rds")
mouse_rds <- file.path(base_dir, "Mouse_Fibro.rds")
human_marker_csv <- file.path(base_dir, "Human.Fibro_subcelltype.csv")
mouse_marker_csv <- file.path(base_dir, "mouse.Fibro_subcelltype.csv")

target_mouse_clusters <- c("Fibroblast2", "Trophocyte1")
human_group_col <- "subcelltype"
mouse_group_col <- "subCellType"
padj_threshold <- 0.05
logfc_threshold <- 1

out_dir_arg <- get_arg_value("--out-dir=")
if (!is.na(out_dir_arg) && out_dir_arg != "") {
  out_dir <- if (grepl("^[A-Za-z]:|^/|^\\\\", out_dir_arg)) out_dir_arg else file.path(base_dir, out_dir_arg)
} else if (top_marker_n == 100) {
  out_dir <- file.path(base_dir, "homology_redefined_strict_padj0.05_log2FC1")
} else {
  out_dir <- file.path(base_dir, paste0("homology_redefined_strict_padj0.05_log2FC1_top", top_marker_n))
}

dir.create(out_dir, showWarnings = FALSE, recursive = TRUE)

required_marker_cols <- c("avg_log2FC", "pct.1", "pct.2", "p_val_adj", "cluster", "gene")

repair_empty_names <- function(x) {
  empty_names <- is.na(names(x)) | names(x) == ""
  names(x)[empty_names] <- paste0("unused_col_", seq_len(sum(empty_names)))
  x
}

check_marker_input <- function(x, file) {
  missing_cols <- setdiff(required_marker_cols, colnames(x))
  if (length(missing_cols) > 0) {
    stop(file, " is missing required columns: ", paste(missing_cols, collapse = ", "))
  }
}

normalize_gene <- function(x) {
  toupper(trimws(as.character(x)))
}

is_non_specific_gene <- function(x) {
  grepl("^MT-", x) |
    grepl("^RPL[0-9A-Z]", x) |
    grepl("^RPS[0-9A-Z]", x)
}

scale01 <- function(x) {
  if (all(is.na(x)) || length(unique(x[!is.na(x)])) <= 1) {
    return(rep(0, length(x)))
  }
  (x - min(x, na.rm = TRUE)) / (max(x, na.rm = TRUE) - min(x, na.rm = TRUE))
}

cosine_similarity <- function(x, y) {
  denom <- sqrt(sum(x^2)) * sqrt(sum(y^2))
  if (denom == 0) {
    return(0)
  }
  sum(x * y) / denom
}

safe_cor <- function(x, y, method) {
  value <- suppressWarnings(cor(x, y, method = method))
  ifelse(is.na(value), 0, value)
}

get_layer_matrix <- function(obj, assay = "RNA", layer = "data") {
  tryCatch(
    GetAssayData(obj, assay = assay, layer = layer),
    error = function(e) GetAssayData(obj, assay = assay, slot = layer)
  )
}

make_feature_map <- function(features) {
  data.frame(
    feature = features,
    gene_norm = normalize_gene(features),
    stringsAsFactors = FALSE
  ) %>%
    filter(
      !is.na(.data$gene_norm),
      .data$gene_norm != "",
      !is_non_specific_gene(.data$gene_norm)
    ) %>%
    distinct(.data$gene_norm, .keep_all = TRUE)
}

average_by_group <- function(mat, groups) {
  keep <- !is.na(groups) & groups != ""
  mat <- mat[, keep, drop = FALSE]
  groups <- droplevels(factor(groups[keep]))
  design <- sparse.model.matrix(~ 0 + groups)
  colnames(design) <- levels(groups)
  sums <- mat %*% design
  counts <- as.numeric(table(groups))
  avg <- t(t(sums) / counts)
  as.matrix(avg)
}

zscore_rows <- function(mat) {
  z <- t(scale(t(mat)))
  z[is.na(z)] <- 0
  z
}

score_gene_set <- function(mat, features) {
  features <- intersect(features, rownames(mat))
  if (length(features) == 0) {
    return(rep(NA_real_, ncol(mat)))
  }
  dense <- as.matrix(mat[features, , drop = FALSE])
  scaled <- t(scale(t(dense)))
  scaled[is.na(scaled)] <- 0
  colMeans(scaled)
}

prepare_markers <- function(x, species) {
  check_marker_input(x, species)

  x %>%
    mutate(
      species = species,
      cluster = as.character(.data$cluster),
      gene = as.character(.data$gene),
      gene_norm = normalize_gene(.data$gene),
      avg_log2FC = suppressWarnings(as.numeric(.data$avg_log2FC)),
      pct.1 = suppressWarnings(as.numeric(.data$pct.1)),
      pct.2 = suppressWarnings(as.numeric(.data$pct.2)),
      p_val_adj = suppressWarnings(as.numeric(.data$p_val_adj)),
      delta_pct = pmax(.data$pct.1 - .data$pct.2, 0),
      neg_log10_padj = pmin(-log10(pmax(.data$p_val_adj, 1e-300)), 50),
      marker_score = .data$avg_log2FC * (0.25 + .data$delta_pct) *
        (1 + .data$neg_log10_padj / 50)
    ) %>%
    filter(
      !is.na(.data$gene_norm),
      .data$gene_norm != "",
      !is_non_specific_gene(.data$gene_norm),
      !is.na(.data$avg_log2FC),
      !is.na(.data$p_val_adj),
      .data$avg_log2FC > logfc_threshold,
      .data$p_val_adj < padj_threshold,
      .data$pct.1 > .data$pct.2
    ) %>%
    group_by(.data$species, .data$cluster, .data$gene_norm) %>%
    summarise(
      gene = .data$gene[which.max(.data$marker_score)],
      avg_log2FC = max(.data$avg_log2FC, na.rm = TRUE),
      pct.1 = max(.data$pct.1, na.rm = TRUE),
      pct.2 = min(.data$pct.2, na.rm = TRUE),
      delta_pct = max(.data$delta_pct, na.rm = TRUE),
      p_val_adj = min(.data$p_val_adj, na.rm = TRUE),
      marker_score = max(.data$marker_score, na.rm = TRUE),
      .groups = "drop"
    )
}

top_markers <- function(markers, n = top_marker_n) {
  markers %>%
    arrange(.data$cluster, desc(.data$marker_score)) %>%
    group_by(.data$cluster) %>%
    mutate(marker_rank = row_number()) %>%
    filter(.data$marker_rank <= n) %>%
    ungroup()
}

message("Reading input RDS files...")
human <- readRDS(human_rds)
mouse <- readRDS(mouse_rds)
DefaultAssay(human) <- "RNA"
DefaultAssay(mouse) <- "RNA"

if (!human_group_col %in% colnames(human@meta.data)) {
  stop("Human metadata column not found: ", human_group_col)
}
if (!mouse_group_col %in% colnames(mouse@meta.data)) {
  stop("Mouse metadata column not found: ", mouse_group_col)
}

human_groups <- as.character(human[[human_group_col]][, 1])
mouse_groups <- as.character(mouse[[mouse_group_col]][, 1])
missing_targets <- setdiff(target_mouse_clusters, unique(mouse_groups))
if (length(missing_targets) > 0) {
  stop("Target mouse subtypes not found: ", paste(missing_targets, collapse = ", "))
}

human_data <- get_layer_matrix(human, "RNA", "data")
mouse_data <- get_layer_matrix(mouse, "RNA", "data")

human_map <- make_feature_map(rownames(human_data))
mouse_map <- make_feature_map(rownames(mouse_data))
common_genes <- sort(intersect(human_map$gene_norm, mouse_map$gene_norm))
if (length(common_genes) < 500) {
  stop("Too few shared genes after symbol normalization: ", length(common_genes))
}

human_features <- human_map$feature[match(common_genes, human_map$gene_norm)]
mouse_features <- mouse_map$feature[match(common_genes, mouse_map$gene_norm)]
human_common <- human_data[human_features, , drop = FALSE]
mouse_common <- mouse_data[mouse_features, , drop = FALSE]
rownames(human_common) <- common_genes
rownames(mouse_common) <- common_genes

human_avg <- average_by_group(human_common, human_groups)
mouse_avg <- average_by_group(mouse_common, mouse_groups)
human_z <- zscore_rows(human_avg)
mouse_z <- zscore_rows(mouse_avg)
human_subtypes <- colnames(human_z)
mouse_subtypes <- colnames(mouse_z)

message("Scoring pseudobulk expression similarity...")
pseudobulk_scores <- expand.grid(
  mouse_subcelltype = mouse_subtypes,
  human_subcelltype = human_subtypes,
  stringsAsFactors = FALSE
) %>%
  rowwise() %>%
  mutate(
    pearson = safe_cor(human_z[, .data$human_subcelltype], mouse_z[, .data$mouse_subcelltype], "pearson"),
    spearman = safe_cor(human_z[, .data$human_subcelltype], mouse_z[, .data$mouse_subcelltype], "spearman"),
    cosine = cosine_similarity(human_z[, .data$human_subcelltype], mouse_z[, .data$mouse_subcelltype])
  ) %>%
  ungroup() %>%
  group_by(.data$mouse_subcelltype) %>%
  mutate(
    pearson_scaled = scale01(.data$pearson),
    spearman_scaled = scale01(.data$spearman),
    cosine_scaled = scale01(.data$cosine),
    pseudobulk_score = rowMeans(cbind(.data$pearson_scaled, .data$spearman_scaled, .data$cosine_scaled)),
    pseudobulk_rank = rank(-.data$pseudobulk_score, ties.method = "min")
  ) %>%
  ungroup() %>%
  arrange(.data$mouse_subcelltype, .data$pseudobulk_rank, desc(.data$pseudobulk_score))

message("Reading and filtering marker CSV files with p_val_adj < ", padj_threshold, " and avg_log2FC > ", logfc_threshold, "...")
human_marker_raw <- repair_empty_names(read.csv(human_marker_csv, check.names = FALSE))
mouse_marker_raw <- repair_empty_names(read.csv(mouse_marker_csv, check.names = FALSE))
human_markers <- prepare_markers(human_marker_raw, "human")
mouse_markers <- prepare_markers(mouse_marker_raw, "mouse")

if (nrow(human_markers) == 0 || nrow(mouse_markers) == 0) {
  stop("No markers remain after strict filtering.")
}

strict_marker_counts <- bind_rows(
  human_markers %>% count(.data$species, .data$cluster, name = "strict_marker_n"),
  mouse_markers %>% count(.data$species, .data$cluster, name = "strict_marker_n")
)

marker_gene_universe <- sort(intersect(unique(human_markers$gene_norm), unique(mouse_markers$gene_norm)))
if (length(marker_gene_universe) == 0) {
  stop("No shared strict marker genes between human and mouse marker CSV files.")
}

human_top <- top_markers(filter(human_markers, .data$gene_norm %in% marker_gene_universe), top_marker_n)
mouse_top_for_overlap <- top_markers(filter(mouse_markers, .data$gene_norm %in% marker_gene_universe), top_marker_n)
mouse_top_for_module <- top_markers(mouse_markers, top_marker_n)

message("Scoring strict marker overlap...")
marker_scores <- expand.grid(
  mouse_subcelltype = sort(unique(mouse_markers$cluster)),
  human_subcelltype = sort(unique(human_markers$cluster)),
  stringsAsFactors = FALSE
) %>%
  rowwise() %>%
  mutate(
    overlap_count = length(intersect(
      human_top$gene_norm[human_top$cluster == .data$human_subcelltype],
      mouse_top_for_overlap$gene_norm[mouse_top_for_overlap$cluster == .data$mouse_subcelltype]
    )),
    human_top_n = sum(human_top$cluster == .data$human_subcelltype),
    mouse_top_n = sum(mouse_top_for_overlap$cluster == .data$mouse_subcelltype),
    jaccard = {
      h <- human_top$gene_norm[human_top$cluster == .data$human_subcelltype]
      m <- mouse_top_for_overlap$gene_norm[mouse_top_for_overlap$cluster == .data$mouse_subcelltype]
      union_n <- length(union(h, m))
      ifelse(union_n == 0, 0, length(intersect(h, m)) / union_n)
    },
    overlap_p = phyper(
      .data$overlap_count - 1,
      .data$human_top_n,
      length(marker_gene_universe) - .data$human_top_n,
      .data$mouse_top_n,
      lower.tail = FALSE
    ),
    overlap_log10p = -log10(pmax(.data$overlap_p, 1e-300))
  ) %>%
  ungroup() %>%
  group_by(.data$mouse_subcelltype) %>%
  mutate(
    jaccard_scaled = scale01(.data$jaccard),
    overlap_scaled = scale01(.data$overlap_log10p),
    marker_overlap_score = rowMeans(cbind(.data$jaccard_scaled, .data$overlap_scaled), na.rm = TRUE),
    marker_overlap_rank = rank(-.data$marker_overlap_score, ties.method = "min")
  ) %>%
  ungroup()

message("Scoring strict mouse target marker modules in human cells...")
target_markers <- mouse_top_for_module %>%
  filter(.data$cluster %in% target_mouse_clusters) %>%
  transmute(
    mouse_subcelltype = .data$cluster,
    mouse_gene = .data$gene,
    gene_norm = .data$gene_norm,
    avg_log2FC = .data$avg_log2FC,
    pct.1 = .data$pct.1,
    pct.2 = .data$pct.2,
    delta_pct = .data$delta_pct,
    p_val_adj = .data$p_val_adj,
    marker_score = .data$marker_score,
    marker_rank = .data$marker_rank
  )

missing_target_markers <- setdiff(target_mouse_clusters, unique(target_markers$mouse_subcelltype))
if (length(missing_target_markers) > 0) {
  stop("No strict CSV markers remain for target mouse subtype(s): ", paste(missing_target_markers, collapse = ", "))
}

human_score_features <- target_markers %>%
  inner_join(human_map, by = "gene_norm") %>%
  group_by(.data$mouse_subcelltype) %>%
  summarise(
    human_features = list(unique(.data$feature)),
    shared_marker_count = length(unique(.data$feature)),
    shared_marker_genes = paste(unique(.data$gene_norm), collapse = ";"),
    .groups = "drop"
  )

missing_target_features <- setdiff(target_mouse_clusters, human_score_features$mouse_subcelltype)
if (length(missing_target_features) > 0) {
  stop("No human features found for strict target marker module(s): ", paste(missing_target_features, collapse = ", "))
}

human_meta <- human@meta.data[colnames(human_data), , drop = FALSE] %>%
  mutate(
    cell = rownames(.),
    human_subcelltype = as.character(.data[[human_group_col]])
  )

for (i in seq_len(nrow(human_score_features))) {
  target <- human_score_features$mouse_subcelltype[i]
  features <- human_score_features$human_features[[i]]
  score_col <- paste0("score_", target)
  human_meta[[score_col]] <- score_gene_set(human_data, features)
}

module_score_summary <- lapply(target_mouse_clusters, function(target) {
  score_col <- paste0("score_", target)
  human_meta %>%
    group_by(.data$human_subcelltype) %>%
    summarise(
      mean_score = mean(.data[[score_col]], na.rm = TRUE),
      median_score = median(.data[[score_col]], na.rm = TRUE),
      cell_count = n(),
      .groups = "drop"
    ) %>%
    mutate(mouse_subcelltype = target) %>%
    group_by(.data$mouse_subcelltype) %>%
    mutate(
      mean_score_scaled = scale01(.data$mean_score),
      module_rank = rank(-.data$mean_score, ties.method = "min")
    ) %>%
    ungroup()
}) %>%
  bind_rows()

target_rankings <- pseudobulk_scores %>%
  filter(.data$mouse_subcelltype %in% target_mouse_clusters) %>%
  left_join(
    module_score_summary %>%
      select(mouse_subcelltype, human_subcelltype, mean_score, mean_score_scaled, module_rank),
    by = c("mouse_subcelltype", "human_subcelltype")
  ) %>%
  left_join(
    marker_scores %>%
      select(mouse_subcelltype, human_subcelltype, overlap_count, jaccard,
             overlap_p, marker_overlap_score, marker_overlap_rank),
    by = c("mouse_subcelltype", "human_subcelltype")
  ) %>%
  group_by(.data$mouse_subcelltype) %>%
  mutate(
    final_score = rowMeans(cbind(.data$pseudobulk_score, .data$mean_score_scaled,
                                 .data$marker_overlap_score), na.rm = TRUE),
    final_rank = rank(-.data$final_score, ties.method = "min")
  ) %>%
  ungroup() %>%
  arrange(.data$mouse_subcelltype, .data$final_rank, desc(.data$final_score))

best_matches <- target_rankings %>%
  filter(.data$final_rank == 1) %>%
  arrange(match(.data$mouse_subcelltype, target_mouse_clusters))

message("Writing result tables...")
write.csv(pseudobulk_scores, file.path(out_dir, "all_pseudobulk_similarity_scores.csv"), row.names = FALSE)
write.csv(marker_scores, file.path(out_dir, "all_strict_csv_marker_overlap_scores.csv"), row.names = FALSE)
write.csv(module_score_summary, file.path(out_dir, "human_module_score_summary_by_subcelltype.csv"), row.names = FALSE)
write.csv(target_markers, file.path(out_dir, "strict_mouse_target_markers_from_csv.csv"), row.names = FALSE)
write.csv(human_markers, file.path(out_dir, "strict_human_markers_used.csv"), row.names = FALSE)
write.csv(mouse_markers, file.path(out_dir, "strict_mouse_markers_used.csv"), row.names = FALSE)
write.csv(strict_marker_counts, file.path(out_dir, "strict_marker_counts_by_subtype.csv"), row.names = FALSE)
write.csv(
  human_score_features %>% select(mouse_subcelltype, shared_marker_count, shared_marker_genes),
  file.path(out_dir, "shared_target_marker_genes_used_for_human_scoring.csv"),
  row.names = FALSE
)
write.csv(target_rankings, file.path(out_dir, "target_mouse_to_human_homology_rankings.csv"), row.names = FALSE)
write.csv(best_matches, file.path(out_dir, "best_human_matches_for_mouse_targets.csv"), row.names = FALSE)

summary_lines <- c(
  "Cross-species homology for current human fibroblast subtypes using strict marker filters",
  paste0("Run time: ", format(Sys.time(), "%Y-%m-%d %H:%M:%S")),
  "",
  "Inputs:",
  paste0("- Human RDS: ", basename(human_rds), " grouped by ", human_group_col),
  paste0("- Mouse RDS: ", basename(mouse_rds), " grouped by ", mouse_group_col),
  paste0("- Human marker CSV: ", basename(human_marker_csv)),
  paste0("- Mouse marker CSV: ", basename(mouse_marker_csv)),
  "",
  "Strict marker filter:",
  paste0("- p_val_adj < ", padj_threshold),
  paste0("- avg_log2FC > ", logfc_threshold),
  "- pct.1 > pct.2",
  "- mitochondrial and ribosomal genes removed",
  "",
  "Method:",
  "1. Mapped human/mouse genes offline by upper-casing symbols and removing mitochondrial/ribosomal genes.",
  "2. Computed RDS pseudobulk average expression per subtype and scored Pearson/Spearman/cosine similarity.",
  "3. Used strict mouse target markers from the marker CSV to score marker modules in human cells.",
  "4. Compared strict human/mouse marker CSV top genes by Jaccard overlap and hypergeometric enrichment.",
  "5. Averaged pseudobulk_score, mean_score_scaled, and marker_overlap_score into final_score.",
  "",
  paste0("Shared genes for pseudobulk: ", length(common_genes)),
  paste0("Shared strict marker genes for CSV overlap: ", length(marker_gene_universe)),
  paste0("Top strict marker genes per subtype: ", top_marker_n),
  "",
  "Strict marker counts by subtype:"
)

for (i in seq_len(nrow(strict_marker_counts))) {
  row <- strict_marker_counts[i, ]
  summary_lines <- c(summary_lines, paste0("- ", row$species, " ", row$cluster, ": ", row$strict_marker_n))
}

summary_lines <- c(summary_lines, "", "Best matches:")
for (i in seq_len(nrow(best_matches))) {
  row <- best_matches[i, ]
  summary_lines <- c(
    summary_lines,
    paste0(
      "- ", row$mouse_subcelltype, " -> ", row$human_subcelltype,
      " | final_score=", sprintf("%.3f", row$final_score),
      ", pseudobulk_score=", sprintf("%.3f", row$pseudobulk_score),
      ", module_mean=", sprintf("%.3f", row$mean_score),
      ", marker_overlap_score=", sprintf("%.3f", row$marker_overlap_score),
      ", ranks(pseudobulk/module/marker)=",
      row$pseudobulk_rank, "/", row$module_rank, "/", row$marker_overlap_rank
    )
  )
}

writeLines(summary_lines, file.path(out_dir, "homology_summary.txt"))

message("Writing PDF summary...")
pdf_file <- file.path(out_dir, "strict_redefined_fibroblast_homology_results.pdf")
pdf(pdf_file, width = 16, height = 10, onefile = TRUE)

grid.newpage()
grid.text(
  paste(summary_lines, collapse = "\n"),
  x = unit(0.03, "npc"), y = unit(0.97, "npc"),
  just = c("left", "top"),
  gp = gpar(fontsize = 9.5, fontfamily = "sans")
)

pseudobulk_mat <- matrix(
  NA_real_,
  nrow = length(mouse_subtypes),
  ncol = length(human_subtypes),
  dimnames = list(mouse_subtypes, human_subtypes)
)
for (i in seq_len(nrow(pseudobulk_scores))) {
  pseudobulk_mat[pseudobulk_scores$mouse_subcelltype[i], pseudobulk_scores$human_subcelltype[i]] <-
    pseudobulk_scores$pseudobulk_score[i]
}

pheatmap(
  pseudobulk_mat,
  cluster_rows = FALSE,
  cluster_cols = FALSE,
  display_numbers = TRUE,
  number_format = "%.2f",
  fontsize = 8,
  fontsize_number = 7,
  angle_col = 45,
  main = "Pseudobulk expression similarity: mouse vs human fibroblast subtypes"
)

final_plot <- target_rankings %>%
  mutate(
    human_subcelltype = reorder(.data$human_subcelltype, .data$final_score),
    best = .data$final_rank == 1
  )

print(
  ggplot(final_plot, aes(x = .data$human_subcelltype, y = .data$final_score, fill = .data$best)) +
    geom_col(width = 0.8) +
    geom_text(aes(label = sprintf("%.2f", .data$final_score)), hjust = -0.05, size = 3) +
    coord_flip() +
    facet_wrap(~ mouse_subcelltype, scales = "free_y") +
    scale_fill_manual(values = c(`TRUE` = "#D55E00", `FALSE` = "#4C78A8"), guide = "none") +
    labs(
      title = "Final homology ranking with strict marker filters",
      x = "Human fibroblast subtype",
      y = "Final score"
    ) +
    ylim(0, max(final_plot$final_score, na.rm = TRUE) * 1.12) +
    theme_bw(base_size = 11) +
    theme(strip.text = element_text(face = "bold"))
)

metric_long <- bind_rows(
  target_rankings %>% transmute(mouse_subcelltype, human_subcelltype, final_rank, metric = "RDS pseudobulk", score = pseudobulk_score),
  target_rankings %>% transmute(mouse_subcelltype, human_subcelltype, final_rank, metric = "Strict mouse marker module", score = mean_score_scaled),
  target_rankings %>% transmute(mouse_subcelltype, human_subcelltype, final_rank, metric = "Strict CSV marker overlap", score = marker_overlap_score)
)
metric_long$metric <- factor(metric_long$metric, levels = c("RDS pseudobulk", "Strict mouse marker module", "Strict CSV marker overlap"))

print(
  ggplot(metric_long, aes(x = .data$metric, y = reorder(.data$human_subcelltype, .data$final_rank), fill = .data$score)) +
    geom_tile(color = "white") +
    geom_text(aes(label = sprintf("%.2f", .data$score)), size = 3) +
    facet_wrap(~ mouse_subcelltype, scales = "free_y") +
    scale_fill_gradient(low = "white", high = "#1B7837", limits = c(0, 1), na.value = "grey90") +
    labs(
      title = "Evidence components for target mouse subtype matching",
      x = NULL,
      y = "Human fibroblast subtype",
      fill = "Score"
    ) +
    theme_bw(base_size = 11) +
    theme(axis.text.x = element_text(angle = 30, hjust = 1), strip.text = element_text(face = "bold"))
)

score_long <- bind_rows(lapply(target_mouse_clusters, function(target) {
  score_col <- paste0("score_", target)
  human_meta %>%
    select(human_subcelltype, score = all_of(score_col)) %>%
    mutate(mouse_subcelltype = target)
}))

print(
  ggplot(score_long, aes(x = reorder(.data$human_subcelltype, .data$score, median), y = .data$score)) +
    geom_violin(fill = "#A6CEE3", color = "grey30", linewidth = 0.2, scale = "width") +
    geom_boxplot(width = 0.12, outlier.size = 0.1, fill = "white") +
    coord_flip() +
    facet_wrap(~ mouse_subcelltype, scales = "free_y") +
    labs(
      title = "Human cell-level scores for strict mouse target marker modules",
      x = "Human fibroblast subtype",
      y = "Mean z-scored marker expression"
    ) +
    theme_bw(base_size = 10) +
    theme(strip.text = element_text(face = "bold"))
)

score_cols <- paste0("score_", target_mouse_clusters)
if ("umap" %in% names(human@reductions)) {
  umap <- as.data.frame(Embeddings(human, "umap"))
  colnames(umap)[1:2] <- c("UMAP_1", "UMAP_2")
  umap$cell <- rownames(umap)
  umap <- left_join(umap, human_meta %>% select(cell, human_subcelltype, all_of(score_cols)), by = "cell")

  print(
    ggplot(umap, aes(x = .data$UMAP_1, y = .data$UMAP_2, color = .data$human_subcelltype)) +
      geom_point(size = 0.12, alpha = 0.6) +
      guides(color = guide_legend(override.aes = list(size = 3, alpha = 1))) +
      labs(title = "Human UMAP by fibroblast subtype", color = "Human subtype") +
      theme_void(base_size = 11) +
      theme(legend.position = "right")
  )

  for (target in target_mouse_clusters) {
    score_col <- paste0("score_", target)
    print(
      ggplot(umap, aes(x = .data$UMAP_1, y = .data$UMAP_2, color = .data[[score_col]])) +
        geom_point(size = 0.12, alpha = 0.75) +
        scale_color_gradientn(colors = c("#313695", "#FFFFBF", "#A50026")) +
        labs(title = paste0("Human UMAP: strict mouse ", target, " marker module score"), color = "Score") +
        theme_void(base_size = 11) +
        theme(legend.position = "right")
    )
  }
}

dev.off()

message("Homology analysis complete.")
message("Output directory: ", normalizePath(out_dir, winslash = "/", mustWork = FALSE))
message("PDF: ", normalizePath(pdf_file, winslash = "/", mustWork = FALSE))
message("Best matches:")
for (i in seq_len(nrow(best_matches))) {
  message(best_matches$mouse_subcelltype[i], " -> ", best_matches$human_subcelltype[i],
          " (final_score=", sprintf("%.3f", best_matches$final_score[i]), ")")
}



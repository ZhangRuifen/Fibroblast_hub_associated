#### 20260401 统计fibroblast向CC1,CC2,Macrophage发出了什么信号？ ####

library(CellChat)
library(dplyr)
library(tidyr)
library(ggplot2)
library(pheatmap)
library(stringr)
library(forcats)
library(scales)

cellchat_Healthy_CTRL <- readRDS("./Healthy_CellChat.rds")
cellchat_Self_CTRL <- readRDS("./Uninflamed_CellChat.rds")
cellchat_UC <- readRDS("./Inflamed_CellChat.rds")

object.list <- list(Healthy = cellchat_Healthy_CTRL,
                    Uninflamed = cellchat_Self_CTRL, 
                    Inflamed = cellchat_UC)
cellchat <- mergeCellChat(object.list, add.names = names(object.list))
cellchat


# Step 1：读入数据
cellchat_d0 <- cellchat_Healthy_CTRL
cellchat_d1 <- cellchat_Self_CTRL
cellchat_d3 <- cellchat_UC


# population = TRUE
cellchat_list <- list(
  d0 = cellchat_d0,
  d1 = cellchat_d1,
  d3 = cellchat_d3
)


cell_colors_fill <- c(
  "day 0" = "#ff595e",
  "day 1" = "#ffca3a",
  "day 3" = "#8ac926")


levels(cellchat_d0@idents)

extract_outgoing_from_sender <- function(cellchat_obj, day, sender = "Fibroblast",
                                         targets = c("Epithelial", "Macrophage", "Mast_cells"),
                                         p_thresh = 0.05) {
  df <- subsetCommunication(
    object = cellchat_obj,
    sources.use = sender,
    targets.use = targets,
    thresh = p_thresh
  )
  
  if (is.null(df) || nrow(df) == 0) {
    return(data.frame(
      source = character(),
      target = character(),
      ligand = character(),
      receptor = character(),
      interaction_name = character(),
      interaction_name_2 = character(),
      pathway_name = character(),
      prob = numeric(),
      pval = numeric(),
      day = character(),
      stringsAsFactors = FALSE
    ))
  }
  
  df$day <- day
  return(df)
}

comm_out_all <- bind_rows(
  lapply(names(cellchat_list), function(day) {
    extract_outgoing_from_sender(
      cellchat_obj = cellchat_list[[day]],
      day = day,
      sender = "Fibroblast",
      targets = c("Epithelial", "Macrophage", "Mast_cells"),
      p_thresh = 0.05
    )
  })
)
unique(comm_out_all$target)

comm_out_all$day <- factor(
  comm_out_all$day,
  levels = c("d0", "d1", "d3"),
  labels = c("day 0", "day 1", "day 3")
)

colnames(comm_out_all)
head(comm_out_all[, c("source", "target", "interaction_name_2", "pathway_name", "prob", "day")])



pathway_all_df <- comm_out_all %>%
  group_by(target, day, pathway_name) %>%
  summarise(prob_sum = sum(prob, na.rm = TRUE), .groups = "drop")

unique(pathway_all_df$pathway_name)

pathways_for_heatmap <- c(
  # Matrix / adhesion / remodeling
  'COLLAGEN','FN1','LAMININ','CD99',
  
  # Inflammation / chemotaxis / immune activation
  "MIF", "CSF",  "CXCL",
  
  # Growth / repair / trophic support
  'MK','PTN','GAS','APP'
)

# 2.3 筛选这些pathway, 转成热图矩阵pathway_heat_df <- pathway_all_df %>%
  filter(pathway_name %in% pathways_for_heatmap)

pathway_heat_mat_df <- pathway_heat_df %>%
  mutate(col_id = paste(target, day, sep = "_")) %>%
  dplyr::select(pathway_name, col_id, prob_sum) %>%
  pivot_wider(names_from = col_id, values_from = prob_sum, values_fill = 0)

pathway_heat_mat <- as.data.frame(pathway_heat_mat_df)
rownames(pathway_heat_mat) <- pathway_heat_mat$pathway_name
pathway_heat_mat$pathway_name <- NULL
pathway_heat_mat <- as.matrix(pathway_heat_mat)

colnames(pathway_heat_mat)
desired_cols_all <- c("Epithelial_day 0", "Epithelial_day 1", "Epithelial_day 3", 
                      "Macrophage_day 0", "Macrophage_day 1", "Macrophage_day 3",
                      "Mast_cells_day 0", "Mast_cells_day 1", "Mast_cells_day 3")
desired_cols_all <- desired_cols_all[desired_cols_all %in% colnames(pathway_heat_mat)]
pathway_heat_mat <- pathway_heat_mat[, desired_cols_all, drop = FALSE]


pathway_order <- c(
  # Matrix / adhesion / remodeling
  'COLLAGEN','FN1','LAMININ','CD99',
  # Growth / repair / trophic support
  'MK','PTN','GAS','APP',
  # Inflammation / chemotaxis / immune activation
  "MIF", "CSF",  "CXCL"
)

pathway_order <- pathway_order[pathway_order %in% rownames(pathway_heat_mat)]
pathway_heat_mat <- pathway_heat_mat[pathway_order, , drop = FALSE]

annotation_col <- data.frame(
  Target = c(
    rep("Epithelial", 3),
    rep("Macrophage", 3),
    rep("Mast_cells", 3)
  ),
  Day = rep(c("day 0", "day 1", "day 3"), 3)
)

rownames(annotation_col) <- colnames(pathway_heat_mat)

annotation_colors <- list(
  Target = c(
    "Epithelial" = "#FF7F00", 
    "Mast_cells" = "#FB9A99", 
    "Macrophage" = "#6A3D9A"
  ),
  Day = c(
    "day 0" = "#ff595e",
    "day 1" = "#ffca3a",
    "day 3" = "#8ac926"
  )
)

# 2.7 画热图
p<-pheatmap(
  pathway_heat_mat,
  scale = "row",
  cluster_rows = FALSE,
  cluster_cols = FALSE,
  annotation_col = annotation_col,
  annotation_colors = annotation_colors,
  border_color = NA,
  color = colorRampPalette(c("#2166AC", "white", "#B2182B"))(100),
  fontsize_row = 11,
  fontsize_col = 9,
  angle_col = 45,
  main = "Fibroblast outgoing signaling"
)
p
dev.off()

ggsave(p,file = 'Heatmap_传入.scale.pdf',width = 5.5,height = 4)






#!/usr/bin/env Rscript

suppressPackageStartupMessages({
  library(Seurat)
  library(dplyr)
  library(ggplot2)
  library(grid)
})

get_script_dir <- function() {
  file_arg <- grep("^--file=", commandArgs(FALSE), value = TRUE)
  if (length(file_arg) > 0) {
    return(dirname(normalizePath(sub("^--file=", "", file_arg[1]), winslash = "/", mustWork = FALSE)))
  }
  normalizePath(getwd(), winslash = "/", mustWork = FALSE)
}

base_dir <- get_script_dir()
input_dir <- file.path(base_dir, "specific_homolog_vlnplots_corrected_Fibroblast2_S3LRRC15_Trophocyte1_S1CXCL12")
out_dir <- file.path(base_dir, "specific_homolog_vlnplots_corrected_with_significance")
dir.create(out_dir, showWarnings = FALSE, recursive = TRUE)

human_rds <- file.path(base_dir, "Human_Fibro.rds")
mouse_rds <- file.path(base_dir, "Mouse_Fibro.rds")
selected_marker_file <- file.path(input_dir, "selected_specific_homolog_markers_for_vlnplot.csv")

mouse_group_col <- "subCellType"
human_group_col <- "subcelltype"

mouse_cols <- c(
  "Fibroblast1"  = "#f9a3a1",
  "Fibroblast2"  = "#fac8b2",
  "Fibroblast3"  = "#ffe6a6",
  "Myfibroblast" = "#b9e8c0",
  "Pericyte"     = "#92ead2",
  "Telocyte"     = "#91d9d7",
  "Trophocyte1"  = "#9dcbe1",
  "Trophocyte2"  = "#7a99b3"
)

human_order <- c(
  "S1_ADAMDEC1", "S3_LRRC15", "S1_CCL8", "S2_F3", "S4_IL13RA2",
  "Myofibroblast", "S2_FRZB", "S4_CCL19", "S1_CXCL12", "S3_MMP3",
  "S1_SLC51B", "S4_CD74", "S4_AREG"
)
human_npg_palette <- c(
  "#E64B35FF", "#4DBBD5FF", "#00A087FF", "#3C5488FF", "#F39B7FFF",
  "#8491B4FF", "#91D1C2FF", "#DC0000FF", "#7E6148FF", "#B09C85FF",
  "#A6CEE3", "#1F78B4", "#B2DF8A"
)
human_cols <- setNames(human_npg_palette[seq_along(human_order)], human_order)

check_file <- function(path) {
  if (!file.exists(path)) {
    stop("Missing required file: ", path)
  }
}

for (path in c(human_rds, mouse_rds, selected_marker_file)) {
  check_file(path)
}

get_layer_matrix <- function(obj, assay = "RNA", layer = "data") {
  tryCatch(
    GetAssayData(obj, assay = assay, layer = layer),
    error = function(e) GetAssayData(obj, assay = assay, slot = layer)
  )
}

p_to_label <- function(p) {
  ifelse(is.na(p), "NA",
    ifelse(p < 0.0001, "****",
      ifelse(p < 0.001, "***",
        ifelse(p < 0.01, "**",
          ifelse(p < 0.05, "*", "ns")
        )
      )
    )
  )
}

make_plot_data <- function(obj, group_col, selected_df, feature_col, target_group, palette_order) {
  mat <- get_layer_matrix(obj, "RNA", "data")
  groups_raw <- as.character(obj[[group_col]][, 1])
  present_levels <- intersect(palette_order, unique(groups_raw))
  missing_levels <- setdiff(sort(unique(groups_raw)), present_levels)
  group_levels <- c(target_group, setdiff(c(present_levels, missing_levels), target_group))
  groups <- factor(groups_raw, levels = group_levels)

  bind_rows(lapply(selected_df[[feature_col]], function(feature) {
    data.frame(
      group = groups,
      expression = as.numeric(mat[feature, ]),
      feature = feature,
      stringsAsFactors = FALSE
    )
  }))
}

calc_significance <- function(plot_df, target_group) {
  bind_rows(lapply(unique(plot_df$feature), function(feature_name) {
    one <- plot_df %>% filter(.data$feature == feature_name)
    target_values <- one$expression[one$group == target_group]
    other_groups <- setdiff(levels(one$group), target_group)

    raw <- bind_rows(lapply(other_groups, function(group_name) {
      other_values <- one$expression[one$group == group_name]
      p <- tryCatch(
        suppressWarnings(wilcox.test(target_values, other_values)$p.value),
        error = function(e) NA_real_
      )
      data.frame(
        feature = feature_name,
        comparison = paste0(target_group, " vs ", group_name),
        target_group = target_group,
        other_group = group_name,
        p_value = p,
        stringsAsFactors = FALSE
      )
    }))

    raw$p_adj <- p.adjust(raw$p_value, method = "BH")
    raw$significance <- p_to_label(raw$p_adj)
    raw
  }))
}

make_annotation_df <- function(plot_df, sig_df, target_group) {
  max_df <- plot_df %>%
    group_by(.data$feature) %>%
    summarise(y_base = max(.data$expression, na.rm = TRUE), .groups = "drop")

  step_df <- plot_df %>%
    group_by(.data$feature) %>%
    summarise(y_step = max((max(.data$expression, na.rm = TRUE) - min(.data$expression, na.rm = TRUE)) * 0.08, 0.08), .groups = "drop")

  sig_df %>%
    left_join(max_df, by = "feature") %>%
    left_join(step_df, by = "feature") %>%
    group_by(.data$feature) %>%
    mutate(
      label_y = .data$y_base + .data$y_step * row_number(),
      label_x = as.numeric(factor(.data$other_group, levels = levels(plot_df$group)))
    ) %>%
    ungroup() %>%
    filter(.data$significance != "ns")
}

plot_vln_with_significance <- function(plot_df, sig_df, palette, target_group, title, ncol = 3) {
  annotation_df <- make_annotation_df(plot_df, sig_df, target_group)
  palette <- palette[levels(plot_df$group)]
  missing_cols <- is.na(palette)
  if (any(missing_cols)) {
    palette[missing_cols] <- "#BDBDBD"
  }

  ggplot(plot_df, aes(x = .data$group, y = .data$expression, fill = .data$group)) +
    geom_violin(scale = "width", trim = TRUE, linewidth = 0.15) +
    geom_boxplot(width = 0.08, outlier.size = 0.05, linewidth = 0.15, fill = "white") +
    geom_text(
      data = annotation_df,
      aes(x = .data$label_x, y = .data$label_y, label = .data$significance),
      inherit.aes = FALSE,
      size = 2.8,
      color = "black"
    ) +
    facet_wrap(~ feature, scales = "free_y", ncol = ncol) +
    scale_fill_manual(values = palette, guide = "none") +
    labs(
      title = title,
      subtitle = paste0("Wilcoxon test: ", target_group, " vs each other subtype; BH-adjusted p-values shown as stars"),
      x = NULL,
      y = "Normalized expression"
    ) +
    theme_bw(base_size = 9) +
    theme(
      axis.text.x = element_text(angle = 50, hjust = 1, size = 6.5),
      strip.text = element_text(face = "bold.italic"),
      plot.title = element_text(face = "bold", hjust = 0.5),
      plot.subtitle = element_text(hjust = 0.5, size = 8)
    )
}

write_title_page <- function(summary_lines) {
  grid.newpage()
  grid.text(
    paste(summary_lines, collapse = "\n"),
    x = unit(0.03, "npc"), y = unit(0.97, "npc"),
    just = c("left", "top"),
    gp = gpar(fontsize = 10.5, fontfamily = "sans")
  )
}

message("Reading objects and selected markers...")
human <- readRDS(human_rds)
mouse <- readRDS(mouse_rds)
DefaultAssay(human) <- "RNA"
DefaultAssay(mouse) <- "RNA"
selected_genes <- read.csv(selected_marker_file, check.names = FALSE)

pairs <- selected_genes %>%
  distinct(.data$mouse_subcelltype, .data$human_subcelltype, .data$pair_label) %>%
  arrange(.data$mouse_subcelltype)

all_sig <- list()

pdf_file <- file.path(out_dir, "specific_homolog_marker_vlnplots_with_significance.pdf")
pdf(pdf_file, width = 16, height = 10, onefile = TRUE)

for (i in seq_len(nrow(pairs))) {
  pair_selected <- selected_genes %>%
    filter(.data$mouse_subcelltype == pairs$mouse_subcelltype[i], .data$human_subcelltype == pairs$human_subcelltype[i]) %>%
    arrange(.data$selected_rank)

  summary_lines <- c(summary_lines, paste0("- ", pairs$pair_label[i], ": ", paste(pair_selected$gene_norm, collapse = ", ")))

  mouse_plot_df <- make_plot_data(mouse, mouse_group_col, pair_selected, "mouse_feature", pairs$mouse_subcelltype[i], names(mouse_cols))
  mouse_sig <- calc_significance(mouse_plot_df, pairs$mouse_subcelltype[i]) %>%
    mutate(species = "mouse", pair_label = pairs$pair_label[i], gene_norm = .data$feature)
  all_sig[[paste0(pairs$pair_label[i], "__mouse")]] <- mouse_sig

  human_plot_df <- make_plot_data(human, human_group_col, pair_selected, "human_feature", pairs$human_subcelltype[i], names(human_cols))
  human_sig <- calc_significance(human_plot_df, pairs$human_subcelltype[i]) %>%
    mutate(species = "human", pair_label = pairs$pair_label[i], gene_norm = .data$feature)
  all_sig[[paste0(pairs$pair_label[i], "__human")]] <- human_sig

  print(plot_vln_with_significance(
    mouse_plot_df,
    mouse_sig,
    mouse_cols,
    pairs$mouse_subcelltype[i],
    paste0("Mouse ", pairs$mouse_subcelltype[i], ": specific homolog markers"),
    ncol = 3
  ))

  print(plot_vln_with_significance(
    human_plot_df,
    human_sig,
    human_cols,
    pairs$human_subcelltype[i],
    paste0("Human ", pairs$human_subcelltype[i], ": specific homolog markers"),
    ncol = 3
  ))
}

dev.off()

